# Prerequisite: Azure VNet Flow Logs (Schema v4) for Databricks Bandwidth Monitoring

This document describes the Azure networking prerequisite required by the **Azure Databricks Network Bandwidth Monitor** Databricks Asset Bundle (DAB) and explains how the solution consumes those logs without adding load to your workspace VNet.

> **Note for Cloud Operations Teams:** Before this bundle is deployed, provision the following prerequisites through your organization's standard infrastructure-as-code and security workflows:
> - An Azure Network Watcher **VNet Flow Log (Version 2 / record schema v4)** on the Databricks VNet or its classic compute subnets, delivering to an **ADLS Gen2 storage account**.
> - **Network access from Databricks serverless compute** to that storage account (Serverless Network Connectivity Configuration firewall rules or private endpoints when the account restricts public network access).
> - A **Unity Catalog External Location or Volume** that grants the pipeline identity `READ FILES` on the `insights-logs-flowlogflowevent` container.
>
> [Section 3](#3-what-cloud-ops-needs-to-provide) maps each prerequisite to its bundle variable.

---

## 1. Why VNet Flow Logs (Schema v4) Are Required

When a classic compute job in Azure Databricks saturates shared network paths (such as ExpressRoute gateways, central firewalls/NVAs, NAT gateways, or shared storage endpoints) and causes concurrent Lakeflow jobs to fail, platform teams need to identify which job is driving the traffic in near-real-time.

Host-level virtual machine metrics (such as Azure Monitor `Network In Total` / `Network Out Total` or Databricks `system.compute.node_timeline` byte counters) only measure **aggregate NIC throughput** with no source or destination IP dimensions. Because Apache Spark performs heavy node-to-node data movement during normal query execution, aggregate NIC metrics cannot distinguish between:

1. **Intra-Cluster Spark Shuffle (Ignore):** High-volume `Worker <-> Worker` and `Driver <-> Worker` transfers that stay entirely inside the Databricks classic compute subnets (`host` / `container` subnets).
2. **Data Source Ingress & Egress (Monitor):** High-volume reads or writes crossing out of the Databricks classic compute subnets—whether targeting **internal ADLS Gen2 Private Endpoints** (hosted in a Private Endpoint subnet within the same VNet or peered VNet) or **external 3rd-party / on-premises endpoints**.

**Azure Network Watcher VNet Flow Logs (Version 2 / Record Schema v4)** record 5-tuple connection flows alongside directional byte deltas (`B` Beginning, `C` Continuing, and `E` Ending states) for every NIC in the VNet. By evaluating the source and destination IPs of each tuple against your **Databricks classic compute subnet CIDRs**:

- Flows where **both** endpoints reside inside the configured Databricks classic compute subnets are classified as **intra-cluster traffic (Spark shuffle)** and excluded.
- Flows where one endpoint is a Databricks classic compute node and the peer IP is outside the compute subnets—including **internal Private Endpoints (e.g., ADLS Gen2)** and **external 3rd-party or on-premises endpoints**—are captured, normalized relative to the cluster node (bytes sent vs. bytes received), and attributed to the active Databricks cluster and Lakeflow job run.

---

## 2. Why Serverless Spark Declarative Pipelines (Zero VNet Bandwidth Overhead)

The ingestion and attribution pipeline in this bundle is built as a **Lakeflow Spark Declarative Pipeline (SDP)** running on **Databricks Serverless Compute**:

```mermaid
flowchart LR
    subgraph CustomerVNet [Customer Injected VNet]
        ComputeSubnets["Databricks Classic Compute Subnets<br/>(Public/Host & Private/Container)"]
        PESubnet["Private Endpoint Subnet<br/>(Internal ADLS Gen2, etc.)"]
    end

    External["External 3rd-Party / On-Premises Endpoints"]

    subgraph AzureMonitoring [Azure Prerequisite]
        NW["Azure Network Watcher<br/>VNet Flow Logs (Schema v4)"]
        FlowStorage["ADLS Gen2 Storage Account<br/>Container: insights-logs-flowlogflowevent"]
    end

    subgraph DatabricksServerless [Databricks Serverless Compute Plane]
        SDP["Lakeflow Spark Declarative Pipeline<br/>(Auto Loader -> flow_events_clean -> flow_event_deltas -> job_bandwidth_5m)"]
    end

    ComputeSubnets <-->|"Intra-Cluster Shuffle (Excluded)"| ComputeSubnets
    ComputeSubnets <-->|"Monitored Internal Data IO"| PESubnet
    ComputeSubnets <-->|"Monitored External Data IO"| External
    CustomerVNet -->|"1-Min Flow Log Flush"| NW
    NW -->|"Delivers JSON Blobs"| FlowStorage
    FlowStorage -->|"Read via Unity Catalog + Serverless NCC<br/>(Zero Customer VNet Traffic)"| SDP
```

- **No Self-Induced Bandwidth Contention:** Because Databricks Serverless compute runs in the Databricks-managed compute plane and connects to the flow-log storage account via **Serverless Network Connectivity Configurations (NCC)** and Unity Catalog, reading and processing the flow logs generates **zero network traffic inside your classic compute VNet**.
- **Incremental Streaming Ingestion:** Spark Auto Loader (`cloudFiles`) incrementally processes newly delivered flow-log JSON files as they land in the `insights-logs-flowlogflowevent` container.

---

## 3. What Cloud Ops Needs to Provide

Before running the pipeline in a target environment, ensure the following prerequisites are in place and pass their identifiers as bundle variables:

| Requirement | Description | Bundle Variable |
| :--- | :--- | :--- |
| **VNet Flow Log (Schema v4)** | An active Azure Network Watcher VNet Flow Log targeting the Databricks VNet (or classic compute subnets), configured to write to an ADLS Gen2 storage account (`insights-logs-flowlogflowevent`). Traffic Analytics is **not** required. | N/A (Upstream Azure setup) |
| **Unity Catalog Storage Access** | A Unity Catalog External Location or Volume granting the pipeline identity `READ FILES` access to the `insights-logs-flowlogflowevent` container (recommended with Serverless NCC Private Link). If the container also receives flow logs of other networks, point `flow_log_source_path` at the folder of the Databricks VNet's flow log. Azure writes each flow log to its own folder, for example `flowLogResourceID=/<SUBSCRIPTION-ID>_NETWORKWATCHERRG/NETWORKWATCHER_<REGION>_<FLOW-LOG-NAME>/` (upper-cased) for a flow log in the default Network Watcher resource group. | `flow_log_source_path` |
| **Flow-Log Target Resource IDs *(Recommended)*** | The Azure resource ID of the Databricks VNet, or of its classic compute subnets, that the flow log targets (`az network vnet show -g <rg> -n <vnet> --query id -o tsv`). Records of every other flow-log target are ignored, so traffic from other networks, including networks with overlapping address ranges, is never attributed to Databricks. | `flow_log_target_resource_ids` |
| **First Date to Ingest *(Recommended)*** | When the flow log already holds older data, the date from which the monitor reads it. Older flow-log files are skipped instead of backfilled on the first deployment. | `flow_log_start_after` |
| **Classic Compute Subnet CIDRs** | The exact CIDR blocks of the Databricks-delegated classic compute subnets (`public`/host and `private`/container subnets). Do **not** pass the entire VNet `/16` if Private Endpoints reside in another subnet of the same VNet, so that Private Endpoint traffic is measured rather than excluded as shuffle. | `compute_subnet_cidrs` |
| **Private Endpoint Subnet CIDRs *(Optional)*** | Optional CIDR blocks of Private Endpoint or internal data-source subnets to tag `traffic_scope = 'PRIVATE_ENDPOINT'`. If omitted, the pipeline defaults to RFC 1918 private address ranges (`10.0.0.0/8,172.16.0.0/12,192.168.0.0/16`). | `private_endpoint_cidrs` |
| **Target Unity Catalog & Schema** | The Unity Catalog name and schema where the monitor creates its tables, views, and metric view. | `catalog`, `schema` |
