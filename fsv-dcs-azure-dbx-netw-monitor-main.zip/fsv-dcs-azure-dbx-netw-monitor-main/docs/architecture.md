# Architecture and System Design

## 1. Purpose and Design Principles

The **Azure Databricks Network Bandwidth Monitor** identifies classic compute clusters and Lakeflow job runs that consume excessive network bandwidth across a customer's injected Azure Virtual Network (VNet). When a runaway or data-intensive Spark workload saturates shared network paths—such as ExpressRoute circuits, central firewalls/NVAs, NAT gateways, or shared storage account limits—concurrent jobs in the workspace can fail.

This solution is architected around four core principles:

1. **Databricks-Native Execution via DABs and Serverless SDP:**
   - The entire ingestion, deduplication, attribution, semantic layer, dashboarding, and alerting stack is packaged as a **Databricks Asset Bundle (DAB)** (`databricks.yml`) and runs on **Databricks Serverless compute** using **Lakeflow Spark Declarative Pipelines (SDP)** and **Lakeflow Jobs**.
   - No custom Azure Functions, external databases, or local polling daemons are required.
2. **Zero Self-Induced VNet Bandwidth Overhead:**
   - Because the SDP pipeline and orchestration tasks run on Databricks Serverless compute, they read VNet Flow Log files from Azure Data Lake Storage Gen2 (ADLS Gen2) via Unity Catalog and **Serverless Network Connectivity Configurations (NCC)**.
   - Monitoring queries and flow-log reads never traverse the customer's classic compute VNet subnets.
3. **Strict Separation of Intra-Cluster Shuffle vs. Data Source Traffic:**
   - Host-level NIC counters (such as Azure Monitor `Network In Total` / `Network Out Total` or `system.compute.node_timeline`) lack source and destination IP dimensions and therefore mix internal Spark shuffle (`Worker <-> Worker`) with external storage traffic.
   - This monitor evaluates 5-tuple **Azure Network Watcher VNet Flow Logs (Schema v4)** against the configured **classic compute subnet CIDRs** (`compute_subnet_cidrs`) to exclude intra-cluster shuffle while capturing traffic to and from **both** internal ADLS Private Endpoints and external 3rd-party or on-premises endpoints.
4. **Idempotent Handling of Azure `PT1H.json` Overwrites via Auto CDC:**
   - Azure Network Watcher writes hourly flow-log blobs (`PT1H.json`) and overwrites each file every minute as new flow intervals arrive.
   - The SDP pipeline pairs Spark Auto Loader (`cloudFiles.allowOverwrites = "true"`) with **SDP Auto CDC (`dlt.create_auto_cdc_flow`, SCD Type 1)** so repeated file revisions and continuing-to-ending (`C` -> `E`) state updates are merged idempotently without double counting.

---

## 2. Network Boundary and Traffic Classification

### Subnet Boundary Model

In an enterprise VNet-injected Azure Databricks deployment, the VNet address space is divided into distinct subnets:

- **Databricks Classic Compute Subnets (`compute_subnet_cidrs`):** The `public` (host) and `private` (container) subnets delegated to `Microsoft.Databricks/workspaces` where classic driver and worker VMs run.
- **Private Endpoint Subnets (`private_endpoint_cidrs` — Optional):** One or more subnets hosting Azure Private Endpoints for internal services (for example, ADLS Gen2 storage accounts, Azure SQL, or Key Vault). If `private_endpoint_cidrs` is explicitly configured, those CIDRs are honored; if omitted/empty, the pipeline automatically falls back to standard RFC 1918 private address ranges (`10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`).
- **External / Public Networks:** Any IP address outside the above subnets.

```mermaid
flowchart TB
    subgraph CustomerVNet ["Customer Injected VNet (e.g., 10.0.0.0/16)"]
        subgraph ComputeBoundary ["Configured compute_subnet_cidrs (Shuffle Exclusion Boundary)"]
            Driver["Classic Driver Node<br/>Host NIC IP + Container IP"]
            Worker1["Classic Worker Node 1<br/>Host NIC IP + Container IP"]
            Worker2["Classic Worker Node 2<br/>Host NIC IP + Container IP"]
            Driver <-->|"Excluded: Intra-Cluster Shuffle"| Worker1
            Worker1 <-->|"Excluded: Intra-Cluster Shuffle"| Worker2
        end

        subgraph PESubnet ["Private Endpoint Subnet (e.g., 10.0.128.0/18)"]
            ADLS_PE["Internal ADLS Gen2<br/>Private Endpoint"]
        end
    end

    External["External 3rd-Party / On-Premises Endpoints"]

    ComputeBoundary <==>|"MONITORED (Scope: PRIVATE_ENDPOINT)"| ADLS_PE
    ComputeBoundary <==>|"MONITORED (Scope: EXTERNAL)"| External
```

### Endpoint Classification Rules

Every VNet Flow Log v4 tuple provides 13 comma-separated fields: `(timestamp, src_ip, dest_ip, src_port, dest_port, protocol, direction, state, encryption, packets_out, bytes_out, packets_in, bytes_in)`. The encryption field is not numeric (for example `NX`) and is not used:

1. **Intra-Cluster Traffic (Excluded):**
   - If **both** `src_ip` and `dest_ip` fall inside `compute_subnet_cidrs`, the tuple represents node-to-node communication inside the classic compute subnets (Spark shuffle, broadcast exchange, or driver-worker RPC) and is **dropped immediately** in the streaming view.
2. **Monitored Non-Shuffle Traffic (Retained):**
   - If **exactly one** endpoint falls inside `compute_subnet_cidrs` and the remote peer IP falls outside `compute_subnet_cidrs`:
     - The endpoint inside `compute_subnet_cidrs` is normalized as `local_node_ip`.
     - The endpoint outside `compute_subnet_cidrs` is normalized as `remote_peer_ip`.
     - If `remote_peer_ip` falls within optional `private_endpoint_cidrs` (or, when `private_endpoint_cidrs` is omitted, within RFC 1918 private address ranges `10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`), `traffic_scope` is tagged as `PRIVATE_ENDPOINT`; otherwise `EXTERNAL`.
   - **Counted once, at the compute node's NIC:** a flow between two flow-logged NICs (for example a cluster node and a VM in another subnet) is recorded at both of them. A tuple is kept only where the compute node observed it, so outbound (`O`) with the node as source or inbound (`I`) with the node as destination; the peer's copy is dropped instead of double-counted.
   - **Only the configured flow-log targets:** when `flow_log_target_resource_ids` is set, records whose `targetResourceID` is not the Databricks VNet (or one of its subnets) are ignored, so other networks that share the storage path, including networks with overlapping address ranges, are never counted.
3. **Directional Byte Normalization:**
   - Connection initiation direction (`I` vs. `O`) does not determine byte transfer direction (for example, an outbound `HTTPS GET` request initiates an `O` flow whose response payload arrives in the reverse byte counter).
   - When `src_ip == local_node_ip`: `bytes_sent = forward_bytes` (the 11th tuple field, bytes from source to destination) and `bytes_received = reverse_bytes` (the 13th field, bytes from destination to source).
   - When `dest_ip == local_node_ip`: `bytes_sent = reverse_bytes` (13th field) and `bytes_received = forward_bytes` (11th field).
4. **Flow States & Re-created Flows:**
   - Beginning (`B`) tuples contain no byte counters and are not summed.
   - Continuing (`C`) and Ending (`E`) tuples carry the counters since the flow's previous report, so they are summed as deltas. A `C` revised to `E` at the same timestamp (a rewritten `PT1H.json`) is counted once by the Auto CDC merge.
   - **Re-created flows:** Azure sometimes ends a flow and starts it again in the same millisecond, reporting an `E` and a `B` tuple with the same timestamp, endpoints, ports, protocol, and direction. The flow's counters do not reset: its next `C` or `E` report repeats that `E`'s counters plus whatever is new. `raw_flow_tuples_stream` marks such `E` tuples (`is_recreated`, matched against the `B` tuples of the same `flowTuples` array), and `flow_event_deltas` subtracts the re-created `E`'s raw counters from the flow's next report, provided both of that report's counters are at least the `E`'s. Without this, those bytes would be counted twice.
   - Each report's bytes are allocated to the 5-minute tumbling window (`[window_start, window_end)`) of its timestamp.

---

## 3. End-to-End Workflow Architecture

The bundle deploys a multi-task **Lakeflow Job (`network_monitor_job`)** alongside a **Serverless Spark Declarative Pipeline (`network_monitor_sdp`)**, an **AI/BI Lakeview Dashboard**, a **Unity Catalog Metric View**, a **Genie Space**, and a **Databricks SQL Alert**.

```mermaid
flowchart LR
    subgraph Sources ["Telemetry & Metadata Sources"]
        ADLS["ADLS Gen2 Flow Logs<br/>(or UC Volume in int-test)"]
        DBX_API["Databricks REST APIs<br/>(Clusters & Active Runs)"]
    end

    subgraph Job ["Lakeflow Job: network_monitor_job"]
        Task1["Task 1:<br/>snapshot_cluster_nodes<br/>• Prepares tables & applies retention<br/>• Appends live node sightings"]
        Task0["int-test only:<br/>generate_synthetic_telemetry"]

        subgraph SDP ["Task 2: network_monitor_sdp (Serverless SDP)"]
            ViewRaw["@dlt.view:<br/>raw_flow_tuples_stream<br/>(Auto Loader allowOverwrites=true)"]
            AutoCDC["dlt.create_auto_cdc_flow<br/>(SCD Type 1 on event_time, event_id)"]
            SilverTbl["Streaming Table:<br/>flow_events_clean"]
            DeltasMV["Materialized View:<br/>flow_event_deltas<br/>(re-created flows' repeats removed)"]
            OwnersTbl["@dlt.table:<br/>cluster_node_runs<br/>(resolved tenure + run windows)"]
            GoldMV["Materialized View:<br/>job_bandwidth_5m<br/>(rolling lookback_hours)"]
            ViewRaw --> AutoCDC --> SilverTbl --> DeltasMV --> GoldMV
            OwnersTbl --> GoldMV
        end

        Task3["Task 3:<br/>publish_semantic_layer<br/>• Ensures job_exceptions table<br/>• Creates UC Metric View"]
        Task4["Task 4:<br/>record_new_breaches"]
        Task5["Task 5:<br/>notify_new_breaches<br/>(SQL alert task)"]
        Task6["Task 6:<br/>mark_breaches_notified"]
        Task1 -.->|"int-test"| Task0
        Task4 --> Task5 --> Task6
    end

    subgraph Consumers ["Analytics & Alerting Layer (DAB Managed)"]
        SnapTbl["Delta Table (Job Maintained):<br/>live_cluster_node_snapshots"]
        ExemptTbl["Delta Table (Admin Editable):<br/>job_exceptions"]
        BreachTbl["Delta Table (Job Maintained):<br/>breach_notifications"]
        MetricView["UC Metric View:<br/>job_bandwidth_metrics_v"]
        Genie["Databricks Genie Space<br/>(resources.genie_spaces)"]
        Dashboard["AI/BI Lakeview Dashboard<br/>(resources.dashboards)"]
        SQLAlert["Databricks SQL Alert<br/>(resources.alerts, schedule paused)"]
    end

    Task0 -.->|"Writes synthetic PT1H.json & staging"| ADLS
    ADLS -->|"Read via Serverless NCC"| ViewRaw
    DBX_API -->|"Polled once per run"| Task1
    Task1 -->|"Sightings"| SnapTbl
    Task1 -.->|"Ensures"| ExemptTbl
    SnapTbl -->|"Read by SDP"| OwnersTbl
    ExemptTbl -->|"Read by SDP"| GoldMV
    GoldMV --> Task3
    Task3 --> MetricView
    GoldMV & MetricView --> Genie & Dashboard
    DeltasMV -->|"Peer byte totals"| Genie & Dashboard
    GoldMV -->|"New breaches"| Task4
    Task4 -->|"Pending rows"| BreachTbl
    Task5 -->|"Evaluates & emails"| SQLAlert
    BreachTbl --> SQLAlert
    Task6 -->|"Sets notified_at"| BreachTbl
```

### Task Responsibilities & Table Ownership

| Task / Component | Compute Type | Responsibility & Managed Objects |
| :--- | :--- | :--- |
| **`snapshot_cluster_nodes`** | Serverless Job Task | Runs first on every cycle. Creates the schema, `job_exceptions`, and `live_cluster_node_snapshots` if needed, applies retention (flow events older than `retention_days`, sightings older than `lookback_hours` + 24 hours), verifies that the run-as identity is a workspace admin, and appends the dual-IP sightings of every active cluster from the Clusters and Jobs APIs. With `is_int_test == "true"` it only prepares tables and applies retention. |
| **`generate_synthetic_telemetry`** *(active when `is_int_test == "true"`)* | Serverless Job Task | Writes realistic Azure VNet Flow Log v4 `PT1H.json` files (including simulated 1-minute overwrites, intra-cluster shuffle, Private Endpoint reads, external downloads, shared-cluster runs, and exempt jobs) into a managed UC Volume, and seeds synthetic cluster/run staging and `job_exceptions`. |
| **`network_monitor_sdp`** | Serverless SDP (`photon: true`) | Runs after `snapshot_cluster_nodes` even if it failed (`run_if: ALL_DONE`), so ingestion and alerting continue. Automatically creates and manages **all 4 pipeline tables** in `${catalog}.${schema}`:<br/>1. `flow_events_clean` (Streaming Table via Auto CDC SCD Type 1 from `raw_flow_tuples_stream`, keyed on `(event_time, event_id)` and clustered by `event_time`).<br/>2. `flow_event_deltas` (Materialized View of the last `lookback_hours` of flow events with the counters a re-created flow's next report repeats removed).<br/>3. `cluster_node_runs` (Materialized View resolving the persisted sightings, or synthetic staging when `is_int_test == "true"`, within `lookback_hours` into non-overlapping node-tenure and job-run windows; it makes no API calls).<br/>4. `job_bandwidth_5m` (Materialized View joining the 5-minute windows of `flow_event_deltas` with `cluster_node_runs` and `job_exceptions`, clustered by `window_start`). |
| **`publish_semantic_layer`** | Serverless Job Task | Ensures the external operator-editable `${catalog}.${schema}.job_exceptions` Delta table exists (`CREATE TABLE IF NOT EXISTS`—kept outside SDP ownership so admins can freely `INSERT`/`UPDATE`/`DELETE` exemptions in SQL) and executes `CREATE OR REPLACE VIEW ... WITH METRICS LANGUAGE YAML` for `job_bandwidth_metrics_v`. |
| **`record_new_breaches`** | Serverless Job Task | Runs after the pipeline refresh (in parallel with `publish_semantic_layer`) and `MERGE`s breaching `job_bandwidth_5m` windows it has not seen before into `${catalog}.${schema}.breach_notifications` as pending rows. |
| **`notify_new_breaches`** | SQL Alert Task (`alert_task`, Public Preview) | Evaluates `network_monitor_breach_alert` against the pending rows and emails the configured recipients. |
| **`mark_breaches_notified`** | Serverless Job Task | Stamps `notified_at` on exactly the breaches the alert reported (at most 100 per run, oldest detections first), so each breach is emailed once and any overflow is emailed by the next run. |
| **Genie Space, Lakeview Dashboard & SQL Alert** | Native DAB Resources (`warehouse_id`) | Provisioned declaratively via `resources.genie_spaces`, `resources.dashboards`, and `resources.alerts` (Databricks CLI `>= 1.3.0` / `>= 1.20.0`). The alert's own schedule stays paused because `network_monitor_job` evaluates it. |

---

## 4. Why Ownership Comes from Live API Snapshots (Not UC System Tables)

Databricks Unity Catalog system tables (`system.compute.node_timeline` and `system.lakeflow.job_task_run_timeline`) provide governed historical records, but four constraints rule them out as the source of IP-to-job ownership for real-time Azure Databricks network monitoring:

1. **Emission Lag and Hourly Slicing:** `job_task_run_timeline` slices long runs at clock-hour boundaries and emits rows after completion or slice closure with a 5-to-15 minute ingestion delay.
2. **Short-Lived Node Cutoff:** Nodes running for less than 10 minutes may not appear in `system.compute.node_timeline`.
3. **Azure VM Instance IDs vs. IPv4 Addresses:** On Azure Databricks, `system.compute.node_timeline.instance_id` records an Azure VM UUID rather than a private IPv4 address, and `clusters.get` clears `private_ip` / `host_private_ip` once an ephemeral job cluster terminates.
4. **Host NIC vs. Container IP Aliasing:** In VNet-injected workspaces with container services/isolation, a classic VM has both a **VM Host NIC IP** (in the public/host subnet, which appears in Azure VNet Flow Logs for off-VNet traffic) and a **Spark Container IP** (in the private/container subnet).

Ownership therefore comes from the live Databricks APIs, which report both IPs of every running node:
- At the start of every run, `snapshot_cluster_nodes` polls the Clusters API (active clusters only, filtered server-side) and the Jobs API (active runs) once, and appends **both** `host_private_ip` and `private_ip` of every active driver and worker node, with their cluster and job runs, to `${catalog}.${schema}.live_cluster_node_snapshots` (`source = 'LIVE_API'`).
- `@dlt.table("cluster_node_runs")` reads only those persisted sightings within `lookback_hours` and makes no API calls itself, so historical 5-minute windows remain attributed to their job after ephemeral job clusters terminate.
- **Failures are loud.** The APIs return only the clusters and runs the caller may view, so `snapshot_cluster_nodes` refuses to run unless the run-as identity is a workspace admin. API, permission, and table errors fail the task instead of silently leaving traffic `UNATTRIBUTED`. The pipeline still refreshes (`run_if: ALL_DONE`), so ingestion and breach alerting continue, while the failed run emails the alert recipients.
- **Boot traffic counts.** A node's VM downloads the Databricks Runtime image and libraries before the API reports the node started. Its sightings therefore start 5 minutes before the reported start, never before its cluster's start, so that traffic counts toward the job.
- **Limits.** A cluster that starts and terminates between two snapshots (in under about 5 minutes) is never sighted, so its traffic is reported as `UNATTRIBUTED`. The monitor attributes clusters of the workspace it runs in; flow logs from other workspaces' clusters also show as `UNATTRIBUTED`.

### Resolving Sightings into Ownership Windows (Azure IP Reuse)

Azure assigns a freed private IP to the next VM created in the subnet, so with frequent job clusters the same IP can belong to several clusters within minutes. Ownership windows are therefore built from sightings. Each node IP's tenure runs from the node's boot start to its last sighting plus a 5-minute grace. The owners of an IP are taken in the order they were first sighted: a tenure never starts before the previous owner's last sighting, and its grace ends early where the next cluster's tenure on the same IP begins. Run windows follow the same rule within the tenure and also end where a later run on the node begins. As a result, one VM's traffic is never counted for two clusters, and sequential jobs on an all-purpose cluster are not misreported as `SHARED`. The full rules are in [data-model.md](data-model.md) (Section 2.2).

---

## 5. Bounded Refresh Cost and Retention

Each 5-minute refresh does the same amount of work whether the monitor has run for a day or a year:

- **Rolling re-attribution window:** `job_bandwidth_5m` and `cluster_node_runs` recompute only the last `lookback_hours` (default 24, aligned to the clock hour so the oldest 5-minute window is complete). Older windows age out of `job_bandwidth_5m`; every breach detected while it was in the window stays in `breach_notifications`.
- **File pruning:** `flow_events_clean` is liquid-clustered on `event_time`, and its Auto CDC merge keys on `(event_time, event_id)`, so each micro-batch merge touches only the recent files that re-read `PT1H.json` tuples can match. `job_bandwidth_5m` is clustered on `window_start`.
- **Retention (applied by `snapshot_cluster_nodes`):** `flow_events_clean` keeps `retention_days` of flow events (default 30), and `live_cluster_node_snapshots` keeps `lookback_hours` plus 24 hours of sightings.
- **One filtered API poll:** the Clusters API is queried once per cycle and filtered server-side to active clusters, rather than paging through every cluster terminated in the last 30 days.
