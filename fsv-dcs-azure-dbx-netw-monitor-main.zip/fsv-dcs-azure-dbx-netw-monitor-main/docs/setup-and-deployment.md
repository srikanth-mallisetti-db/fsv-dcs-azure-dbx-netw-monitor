# Local Setup and One-Shot Bundle Deployment Guide (Windows PowerShell & macOS/POSIX)

Run every command from the repository root. **Windows PowerShell** is presented first as the primary enterprise operator workflow, followed immediately by **macOS / POSIX (`zsh` / `bash`)** equivalents in each section.

Any developer or automation agent only needs to run **four sequential steps**:
1. **Virtual Environment & Dependencies Setup** (`venv` + `pip install -r requirements-dev.txt`)
2. **Static Type & Lint Checks** (`mypy` + `ruff check` + `ruff format --check`, with `tests/` excluded)
3. **Unit & Contract Tests with Coverage** (`pytest --cov=network_monitor`)
4. **One-Shot JSON Deployment** (`python scripts/deploy.py --config <config.json>`, supporting `int-test`, `dev`, and `prod` targets)

---

## Prerequisites: Python 3.14, the Databricks CLI, and the Workspace

Local tooling requires:
- **Python 3.14** with `venv` and `pip` (3.12 also works); the commands below use `py -3.14` (Windows) or `python3.14`. The job tasks run on Python 3.11 (serverless environment version 2), and `ruff` and `mypy` check the code against that version, so syntax or standard-library APIs the runtime lacks fail the checks rather than the job.
- **Native Go-based Databricks CLI `>= 1.20.0`** (ensure the executable on `PATH` is the current Go CLI, not the legacy Python `databricks-cli` package).

The target Azure Databricks workspace needs:
- **Unity Catalog** and **serverless compute** for jobs and Lakeflow Spark Declarative Pipelines: the job's tasks and the pipeline run serverless.
- A **Pro or Serverless SQL warehouse** for `warehouse_id`. The Genie space requires one, and the dashboard and the breach alert run on it too.
- The Lakeflow Jobs **SQL alert task** (Public Preview), which emails the breaches.

The `int-test` target needs nothing more: it generates synthetic flow logs in a managed volume. `dev` and `prod` also need Azure VNet flow logs that Unity Catalog can read (see [the VNet flow logs prerequisite](vnet-flow-logs-prerequisite.md)).

### Windows PowerShell

Install an organization-approved Python 3.14 distribution from the [Python Windows downloads](https://www.python.org/downloads/windows/) page (including the `py` launcher) and the native CLI using the [Databricks CLI installation guide](https://learn.microsoft.com/en-us/azure/databricks/dev-tools/cli/install). Verify in PowerShell:

```powershell
py -3.14 --version
Get-Command databricks | Select-Object Source
databricks --version
```

### macOS / Linux (`zsh` / `bash`)

Install Python 3.14 and the Databricks CLI (for example via Homebrew `brew install python@3.14 databricks/tap/databricks`), then verify:

```bash
python3.14 --version
which databricks
databricks --version
```

---

## Step 1: Create the Virtual Environment & Install Dependencies

Point pip at a project-local configuration, then create the virtual environment with Python 3.14 and install the pinned development dependencies from `requirements-dev.txt`. Invoking the virtual environment's Python directly avoids Windows PowerShell `ExecutionPolicy` script-activation errors.

`pip.local.ini`, copied from `pip.ini.example`, sets:
- `index-url`: your organization's approved package index, or `https://pypi.org/simple` when PyPI is reachable directly.
- `user = false`: a machine-level pip setting cannot force a `--user` install into the virtual environment (pip would fail with "User site-packages are not visible in this virtualenv"). `--no-user` on each install is a second guard.

`pip.local.ini` is git-ignored; never commit credentials. `PIP_CONFIG_FILE` applies to the current shell only, so set it again in a new window before installing packages.

### Windows PowerShell

```powershell
Copy-Item pip.ini.example pip.local.ini
notepad pip.local.ini   # set index-url to your approved package index
$env:PIP_CONFIG_FILE = Join-Path (Get-Location) 'pip.local.ini'
$env:PYTHONUTF8 = '1'

# Start from a clean virtual environment (for example after using another Python or pipenv)
if (Test-Path .venv) { Remove-Item -Recurse -Force .venv }
py -3.14 -m venv .venv
$FsvPython = Join-Path (Get-Location) '.venv\Scripts\python.exe'
& $FsvPython -m pip install --no-user --upgrade pip
& $FsvPython -m pip install --no-user -r requirements-dev.txt
& $FsvPython -m pip check
```

### macOS / Linux (`zsh` / `bash`)

```bash
cp pip.ini.example pip.local.ini   # then set index-url to your approved package index
export PIP_CONFIG_FILE="$PWD/pip.local.ini"
export PYTHONUTF8=1

rm -rf .venv
python3.14 -m venv .venv
.venv/bin/python -m pip install --no-user --upgrade pip
.venv/bin/python -m pip install --no-user -r requirements-dev.txt
.venv/bin/python -m pip check
```

---

## Step 2: Run Static Type Checking & Linting (`tests/` Excluded)

`pyproject.toml` configures `mypy` and `ruff` to check `src/` and `scripts/` while excluding `tests/`.

### Windows PowerShell

```powershell
$FsvPython = Join-Path (Get-Location) '.venv\Scripts\python.exe'
& $FsvPython -m mypy src scripts
& $FsvPython -m ruff check src scripts
& $FsvPython -m ruff format --check src scripts
```

### macOS / Linux (`zsh` / `bash`)

```bash
.venv/bin/mypy src scripts
.venv/bin/ruff check src scripts
.venv/bin/ruff format --check src scripts
```

---

## Step 3: Run Unit & Contract Tests with Coverage

`pyproject.toml` configures `pytest` to automatically report statement coverage across `src/network_monitor` (`--cov=network_monitor --cov-report=term-missing`).

### Windows PowerShell

```powershell
$FsvPython = Join-Path (Get-Location) '.venv\Scripts\python.exe'
& $FsvPython -m pytest
```

### macOS / Linux (`zsh` / `bash`)

```bash
.venv/bin/pytest
```

---

## Step 4: Authenticate CLI Profile & Run One-Shot JSON Deployment (`scripts/deploy.py`)

### 4.1 Authenticate an Explicit Databricks Workspace Profile

Always authenticate using an explicit named **workspace profile** (never rely on an implicit `DEFAULT` profile).

**Windows PowerShell:**
```powershell
$FsvProfile = Read-Host 'Databricks workspace profile name'
$FsvWorkspaceHost = Read-Host 'Azure Databricks workspace URL (e.g. https://adb-xxxx.xx.azuredatabricks.net)'
databricks auth login --host $FsvWorkspaceHost --profile $FsvProfile
databricks current-user me --profile $FsvProfile
```

**macOS / Linux (`zsh` / `bash`):**
```bash
read -r -p "Databricks workspace profile name: " FSV_PROFILE
read -r -p "Azure Databricks workspace URL: " FSV_WORKSPACE_HOST
databricks auth login --host "$FSV_WORKSPACE_HOST" --profile "$FSV_PROFILE"
databricks current-user me --profile "$FSV_PROFILE"
```

### 4.2 Deployment JSON Configuration Parameters

The `scripts/deploy.py` orchestrator accepts a single JSON file containing both **orchestration settings** and **bundle variables**. Three ready-to-copy templates are provided in `configs/`:
- `configs/deploy.int-test.example.json` (self-contained integration test target)
- `configs/deploy.dev.example.json` (development target)
- `configs/deploy.prod.example.json` (production target)

> **Git Hygiene:** Any file matching `*.local.json` (such as `configs/deploy.dev.local.json`) is automatically ignored by `.gitignore` so workspace-specific IDs and storage paths are never committed.

| JSON Field | Location | Required? | Description | Default |
| :--- | :--- | :--- | :--- | :--- |
| `profile` | Top-level | **Yes** | Authenticated Databricks CLI profile name | N/A |
| `target` | Top-level | **Yes** | Bundle target to deploy: `"int-test"`, `"dev"`, or `"prod"` | `"dev"` |
| `workspace_host` | Top-level | Optional | Workspace URL for operator reference/documentation | `null` |
| `ensure_schema` | Top-level | Optional | When `true`, ensures `${catalog}.${schema}` exists prior to deploying `dev` or `prod` (never with `--validate-only`) | `true` (`dev`/`prod`), `false` (`int-test`) |
| `run_initial_job` | Top-level | Optional | When `true`, runs `network_monitor_job` once after deploying. The first deployment to a new schema runs it regardless, to bootstrap the Genie Space (see Section 4.3) | `true` |
| `full_refresh` | Top-level | Optional | When `true`, resets and recomputes the pipeline tables after deploying (`databricks bundle run network_monitor_sdp --full-refresh-all`) and re-ingests every flow log still in storage (from `flow_log_start_after`, when set). Required after changing `compute_subnet_cidrs`, `private_endpoint_cidrs`, or `flow_log_target_resource_ids`, because flow events are classified at ingestion, and after upgrading to a version that changes how flow events are keyed or stored (for example, the version that reads the flow-log GUID from `flowLogGUID` and adds `is_recreated`) | `false` |
| `catalog` | `bundle_vars` | **Yes** | Target Unity Catalog for all tables, views, and volumes | `main` |
| `schema` | `bundle_vars` | Optional | Target schema (`network_monitor` in `dev`/`prod`; `dev_<user>_network_monitor_int_test` in `int-test`) | `network_monitor` |
| `warehouse_id` | `bundle_vars` | **Yes** | SQL Warehouse ID for the Lakeview Dashboard, Genie Space, and SQL Alert | N/A |
| `compute_subnet_cidrs` | `bundle_vars` | **Yes** (`dev`/`prod`) | Comma-separated classic compute subnet CIDRs (flows with both IPs inside are excluded as shuffle) | `10.0.0.0/18,10.0.64.0/18` (`int-test`) |
| `private_endpoint_cidrs` | `bundle_vars` | Optional | Optional comma-separated Private Endpoint subnet CIDRs to tag `traffic_scope = 'PRIVATE_ENDPOINT'` (falls back to RFC 1918 private ranges when omitted) | `""` |
| `flow_log_source_path` | `bundle_vars` | **Yes** (`dev`/`prod`) | UC Volume or External Location path where VNet Flow Log v4 `PT1H.json` files land. Prefer the folder of the Databricks VNet's flow log over the container root when the container also receives other flow logs. Azure writes each flow log to its own folder, for example `flowLogResourceID=/<SUBSCRIPTION-ID>_NETWORKWATCHERRG/NETWORKWATCHER_<REGION>_<FLOW-LOG-NAME>/` (upper-cased) for a flow log in the default Network Watcher resource group | Managed Volume in `int-test` |
| `flow_log_target_resource_ids` | `bundle_vars` | Recommended (`dev`/`prod`) | Comma-separated Azure resource IDs of the flow-log targets to count: the Databricks VNet, or its subnets (`az network vnet show -g <rg> -n <vnet> --query id -o tsv`). Records of any other flow log under `flow_log_source_path` are ignored, so other networks' traffic, including networks with overlapping address ranges, is never counted. Empty counts every record | `""` (synthetic VNet in `int-test`) |
| `flow_log_start_after` | `bundle_vars` | Recommended (`dev`/`prod` go-live) | ISO 8601 date or date-time, UTC unless it carries an offset (for example `2026-11-01` or `2026-11-01T00:00:00Z`). Flow-log files last modified before it are never read, so the first deployment does not backfill the flow logs already in storage. Azure keeps appending to each hourly `PT1H.json` blob, so the hour that contains this time (and possibly the hour before) is still read in full. Changing it later affects only files not read yet, unless you also run a full refresh. Empty reads every file | `""` |
| `bandwidth_threshold_mbps` | `bundle_vars` | Optional | 5-minute average bandwidth threshold (in decimal Mbps) for breach alerting | `100.0` (`1.0` in `int-test`) |
| `lookback_hours` | `bundle_vars` | Optional | Rolling window (whole hours) that every refresh re-attributes in `job_bandwidth_5m` and `cluster_node_runs`; node sightings are kept one day longer | `24` |
| `retention_days` | `bundle_vars` | Optional | Days of flow events kept in `flow_events_clean` (whole days) | `30` |
| `schedule_pause_status` | `bundle_vars` | Optional | Controls whether the 5-minute Quartz cron schedule (`0 */5 * * * ?`) is `PAUSED` or `UNPAUSED`. One run at a time: a run that takes longer than 5 minutes skips the next trigger instead of queueing it | `"PAUSED"` (`"UNPAUSED"` in `prod`) |
| `alert_email_recipients` | `bundle_vars` | **Yes**, unless `alert_notification_destination_ids` is set (all targets) | Email addresses of **Databricks workspace users** who receive breach alert emails (JSON list or comma-separated string) | `[]` |
| `alert_notification_destination_ids` | `bundle_vars` | **Yes**, unless `alert_email_recipients` is set (all targets) | IDs of **Email notification destinations** (created by a workspace admin) for distribution lists or other non-user addresses (JSON list or comma-separated string) | `[]` |

#### Breach Alert Recipients

Every target requires at least one alert recipient. Use `alert_email_recipients` for individual Databricks workspace users. A distribution list or shared mailbox is not a workspace user: have a workspace admin create an **Email notification destination** for it in the workspace admin settings and pass the destination ID in `alert_notification_destination_ids`.

`network_monitor_job` evaluates the breach alert after every refresh through its `notify_new_breaches` task, a Lakeflow Jobs **SQL alert task** (`alert_task`), which is a Public Preview feature and must be available in the target workspace. Each newly detected breach is emailed once (see the [SQL Alert specification](data-model.md)).

The same recipients are also notified when a `network_monitor_job` run fails (skipped and canceled runs excluded), because a failed run means attribution or alerting is degraded.

Both recipient fields populate four complex bundle variables with the same recipients:
- `alert_subscriptions`: the alert's own subscriptions, used when it is evaluated manually.
- `alert_task_subscribers`: the job alert task's subscribers, which receive the 5-minute notifications.
- `job_failure_emails` and `job_failure_destinations`: the job's failure notifications.

The Databricks CLI cannot read complex variables from `BUNDLE_VAR_*` environment variables, so `scripts/deploy.py` merges them into `.databricks/bundle/<target>/variable-overrides.json` (git-ignored, other variables in the file are preserved) before validating. If you run `databricks bundle` commands directly, provide that file yourself, for example:

```json
{
  "alert_subscriptions": [
    {"user_email": "first.last@your-company.com"},
    {"destination_id": "<email-notification-destination-id>"}
  ],
  "alert_task_subscribers": [
    {"user_name": "first.last@your-company.com"},
    {"destination_id": "<email-notification-destination-id>"}
  ],
  "job_failure_emails": ["first.last@your-company.com"],
  "job_failure_destinations": [{"id": "<email-notification-destination-id>"}]
}
```

#### Required Permissions and Scope

`network_monitor_job` and `network_monitor_sdp` run as the identity that deploys the bundle. Deploy `prod` with a CLI profile authenticated as a **service principal** (OAuth machine-to-machine): the `prod` target pins a single deployment folder under that principal (`/Workspace/Users/<principal>/.bundle/<bundle>/prod`), and the principal owns and runs the job and pipeline. That identity needs:

| Scope | Requirement | Why |
| :--- | :--- | :--- |
| **Workspace** | Workspace admin (`dev` and `prod`) | The Clusters and Jobs APIs return only the clusters and job runs the caller may view. `snapshot_cluster_nodes` fails the run, rather than silently reporting their traffic as `UNATTRIBUTED`, when the identity is not an admin. `int-test` attributes synthetic ownership and does not call these APIs. |
| **Unity Catalog: target catalog and schema** | `USE CATALOG` and `CREATE SCHEMA` on the catalog (`int-test` always creates its own schema; `dev` and `prod` create theirs when `ensure_schema` is `true`), `USE SCHEMA`, `CREATE TABLE`, `CREATE MATERIALIZED VIEW` (plus `CREATE VOLUME` for `int-test`), and ownership or `MODIFY` and `SELECT` on the monitor tables | The pipeline creates its streaming table and materialized views; the job tasks create and maintain `job_exceptions`, `live_cluster_node_snapshots`, and `breach_notifications`, apply retention deletes, and create the metric view. |
| **Unity Catalog: flow-log storage** | `READ FILES` on the External Location or Volume behind `flow_log_source_path` | Auto Loader reads the VNet Flow Log blobs. |
| **SQL warehouse** | `CAN USE` on `warehouse_id` | The SQL alert task, the alert, the dashboard, and the Genie space run their queries on it. |

Operators who maintain exemptions need `MODIFY` on `job_exceptions`. Email notification destinations for distribution lists are created by a workspace admin.

One deployment attributes the classic compute of the workspace it runs in. Flow-log traffic from another workspace's clusters is reported as `UNATTRIBUTED`. A cluster that starts and terminates between two 5-minute snapshots is never sighted, and its traffic is also `UNATTRIBUTED`. A job cluster's boot traffic (the Databricks Runtime image and library downloads before its nodes report started) counts toward its job run.

### 4.3 One-Shot Deployment Commands (`int-test`, `dev`, and `prod`)

What `scripts/deploy.py` executes automatically:
1. Validates all CIDR blocks, flow-log target IDs, the flow-log start time, numeric thresholds, and alert recipients locally before calling the Databricks CLI.
2. Injects `BUNDLE_VAR_*` via process environment variables (preventing CLI `--var` comma splitting on `compute_subnet_cidrs`).
3. Verifies CLI authentication (`databricks current-user me`) and creates the target UC schema if needed (`ensure_schema: true`; skipped with `--validate-only`, which changes nothing in the workspace).
4. Writes the alert and job-failure recipients (`alert_subscriptions`, `alert_task_subscribers`, `job_failure_emails`, and `job_failure_destinations`) to `.databricks/bundle/<target>/variable-overrides.json`.
5. Runs `databricks bundle validate -t <target>` and `databricks bundle deploy -t <target>`. With `full_refresh: true` (or `--full-refresh`), it then runs the job tasks that prepare the pipeline's input tables (`--only snapshot_cluster_nodes`, plus `generate_synthetic_telemetry` in `int-test`) and resets the pipeline with `databricks bundle run network_monitor_sdp --full-refresh-all`.
6. **Cold-Schema Genie Space Bootstrap:** On a brand-new schema, the tables and views the Genie Space reads (`breach_notifications`, `flow_event_deltas`, `flow_events_clean`, `job_bandwidth_5m`, `job_bandwidth_metrics_v`, `job_exceptions`) do not exist yet, so the first deploy fails on the Genie Space (the Genie API reports this as HTTP 403 `PERMISSION_DENIED`, listing each table that does not exist). When a deploy fails on the Genie Space, `scripts/deploy.py` runs `databricks bundle run network_monitor_job -t <target>` to create and populate them and then re-runs `databricks bundle deploy -t <target>`, so the Genie Space is provisioned in a single command. If that does not fix the failure, for example because it was a permission error rather than a cold schema, the error shows the first deploy's output as well.
7. Prints the complete `databricks bundle summary -t <target>` output with direct workspace URLs.

#### Target A: Self-Contained Integration Test (`int-test`)

**Windows PowerShell:**
```powershell
$FsvPython = Join-Path (Get-Location) '.venv\Scripts\python.exe'
Copy-Item configs\deploy.int-test.example.json configs\deploy.int-test.local.json
# Edit configs\deploy.int-test.local.json with your profile, catalog, warehouse_id, and alert_email_recipients
& $FsvPython scripts\deploy.py --config configs\deploy.int-test.local.json
```

**macOS / Linux (`zsh` / `bash`):**
```bash
cp configs/deploy.int-test.example.json configs/deploy.int-test.local.json
# Edit configs/deploy.int-test.local.json with your profile, catalog, warehouse_id, and alert_email_recipients
.venv/bin/python scripts/deploy.py --config configs/deploy.int-test.local.json
```

#### Target B: Development & Production (`dev` and `prod`)

**Windows PowerShell:**
```powershell
$FsvPython = Join-Path (Get-Location) '.venv\Scripts\python.exe'
Copy-Item configs\deploy.dev.example.json configs\deploy.dev.local.json
# Edit configs\deploy.dev.local.json with your profile, catalog, warehouse_id, compute_subnet_cidrs, flow_log_source_path, flow_log_target_resource_ids, flow_log_start_after, and alert recipients
& $FsvPython scripts\deploy.py --config configs\deploy.dev.local.json
```

**macOS / Linux (`zsh` / `bash`):**
```bash
cp configs/deploy.dev.example.json configs/deploy.dev.local.json
# Edit configs/deploy.dev.local.json with your profile, catalog, warehouse_id, compute_subnet_cidrs, flow_log_source_path, flow_log_target_resource_ids, flow_log_start_after, and alert recipients
.venv/bin/python scripts/deploy.py --config configs/deploy.dev.local.json
```

*(Optional flags: pass `--validate-only` to validate the bundle without changing the workspace (it only writes the local `variable-overrides.json`), `--skip-job-run` to skip running `network_monitor_job`, `--full-refresh` to reset and recompute the pipeline tables (re-ingesting every flow log still in storage, from `flow_log_start_after` when set), `--destroy` to remove the deployment (see Section 4.4), or `--dry-run` to print the planned CLI commands without executing them (the result reports `"status": "dry_run"`).)*

### 4.4 Remove a Deployment

`--destroy` removes everything the bundle deployed for the config's target. Use the same JSON config: the CLI needs its variables to load the bundle, so a bare `databricks bundle destroy` fails (`dashboard warehouse_id is required`). It removes:
- the job, the pipeline with its streaming table and materialized views, the dashboard, the breach alert, and the Genie space;
- for `int-test`, also its schema, with every table in it, and the synthetic flow-log volume.

In `dev` and `prod` the schema is not part of the bundle, so the tables the job tasks created (`job_exceptions`, `breach_notifications`, `live_cluster_node_snapshots`) and the metric view `job_bandwidth_metrics_v` remain.

**Windows PowerShell:**
```powershell
$FsvPython = Join-Path (Get-Location) '.venv\Scripts\python.exe'
& $FsvPython scripts\deploy.py --config configs\deploy.int-test.local.json --destroy
```

**macOS / Linux (`zsh` / `bash`):**
```bash
.venv/bin/python scripts/deploy.py --config configs/deploy.int-test.local.json --destroy
```
