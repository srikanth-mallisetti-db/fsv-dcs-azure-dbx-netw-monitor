# Data Model, Semantic Layer, Dashboard, and Alert Specification

## 1. Schema Overview

All persisted tables, streaming tables, materialized views, and metric views live in a single target Unity Catalog namespace (`${catalog}.${schema}`):

- **`dev` / `prod` targets:** `${catalog}.network_monitor` (or custom configured schema).
- **`int-test` target:** `${catalog}.dev_<user>_network_monitor_int_test` (isolated per-user schema + managed UC Volume `synthetic_flow_logs`).

Instead of a redundant 3-layer Medallion design that writes raw unparsed JSON to a Bronze Delta table before exploding it into Silver, the **Lakeflow Spark Declarative Pipeline (`network_monitor_sdp`)** directly creates and manages the 4 core telemetry/attribution tables (`flow_events_clean`, `flow_event_deltas`, `cluster_node_runs`, and `job_bandwidth_5m`), while `job_exceptions` (operator-editable) and `breach_notifications` (job-maintained) are Delta tables kept outside SDP ownership:

1. **`raw_flow_tuples_stream` (`@dlt.view` — SDP Ephemeral View):** Auto Loader stream that reads `PT1H.json` flow-log blobs (`cloudFiles.allowOverwrites = "true"`; with `flow_log_start_after` set, `modifiedAfter` skips files last modified before it), explodes the nested `records[].flowRecords.flows[].flowGroups[].flowTuples[]` array in-flight, marks re-created flows' `E` tuples (`is_recreated`, see Section 2.5), drops `B` (Beginning) records, intra-cluster Spark shuffle (`Compute Subnet <-> Compute Subnet`), the second copy of flows observed at a non-compute NIC, and records of flow-log targets outside `flow_log_target_resource_ids`, and computes a deterministic `event_id` and `sequence_key`.
2. **`flow_events_clean` (SDP Streaming Table via Auto CDC SCD Type 1):** Created and managed automatically by SDP (`dlt.create_streaming_table(cluster_by=["event_time"])` + `dlt.create_auto_cdc_flow(keys=["event_time", "event_id"], stored_as_scd_type=1)`). Flow events older than `retention_days` (default 30) are deleted by `snapshot_cluster_nodes`.
3. **`flow_event_deltas` (`@dlt.table` — SDP Materialized View):** Created and managed automatically by SDP. The last `lookback_hours` of `flow_events_clean` with the counters a re-created flow's next report repeats removed (see Section 2.5); sum flow-level bytes here rather than in `flow_events_clean`.
4. **`cluster_node_runs` (`@dlt.table` — SDP Managed Table):** Created and managed automatically by SDP. Resolves the live Clusters and Jobs API sightings (`host_private_ip` and container `private_ip`) that `snapshot_cluster_nodes` persists in `live_cluster_node_snapshots`, or synthetic staging records when `is_int_test == "true"`, from the last `lookback_hours` into non-overlapping node-tenure and job-run windows (see Section 2.2). It makes no API calls itself.
5. **`job_exceptions` (External Admin-Editable Delta Table):** Created via `CREATE TABLE IF NOT EXISTS` outside SDP ownership so platform administrators can freely `INSERT`, `UPDATE`, or `DELETE` exempt `(workspace_id, job_id)` entries using standard SQL without SDP locking or overwriting manual edits.
6. **`job_bandwidth_5m` (`@dlt.table` — SDP Materialized View):** Created and managed automatically by SDP. Aggregates `flow_event_deltas` into 5-minute tumbling windows and joins with `dlt.read("cluster_node_runs")` and `spark.read.table("${catalog}.${schema}.job_exceptions")`.
7. **`job_bandwidth_metrics_v` (Unity Catalog Metric View):** Created/updated by `publish_semantic_layer` (`CREATE OR REPLACE VIEW ... WITH METRICS LANGUAGE YAML`) over `job_bandwidth_5m` to power the Genie Space and ad-hoc business analytics.
8. **`breach_notifications` (External Job-Maintained Delta Table):** Created and appended by the `record_new_breaches` job task. One row per newly detected breach (5-minute window × workspace × cluster × job run); `notified_at` stays `NULL` until the SQL alert has reported it (see Section 5.2).

```mermaid
erDiagram
    FLOW_EVENTS_CLEAN ||--o{ FLOW_EVENT_DELTAS : "re-created flows' repeats removed"
    FLOW_EVENT_DELTAS ||--o{ JOB_BANDWIDTH_5M : "aggregated into 5m windows"
    CLUSTER_NODE_RUNS ||--o{ JOB_BANDWIDTH_5M : "maps local_node_ip + time to job"
    JOB_EXCEPTIONS ||--o{ JOB_BANDWIDTH_5M : "marks (workspace_id, job_id) as EXEMPT"
    JOB_BANDWIDTH_5M ||--|| JOB_BANDWIDTH_METRICS_V : "exposes governed semantic measures"
    JOB_BANDWIDTH_5M ||--o{ BREACH_NOTIFICATIONS : "records each new breach once"

    FLOW_EVENTS_CLEAN {
        timestamp event_time PK "UTC timestamp of the C/E tuple (Auto CDC key, clustering column)"
        string event_id PK "SHA256(flow_log_guid, mac, epoch_ms, 5-tuple, direction)"
        string local_node_ip "In-VNet Databricks classic compute IP"
        string remote_peer_ip "Private Endpoint IP or External IP"
        int local_port "Local TCP/UDP port"
        int remote_port "Remote TCP/UDP port (e.g. 443)"
        int protocol "IANA protocol number (6=TCP, 17=UDP)"
        string flow_direction "NIC observation direction (I or O)"
        string flow_state "C (5-min continuing delta) or E (ending delta)"
        string traffic_scope "PRIVATE_ENDPOINT or EXTERNAL"
        bigint bytes_sent "Delta bytes sent by the Databricks node"
        bigint bytes_received "Delta bytes received by the Databricks node"
        boolean is_recreated "E reported in the same millisecond as a B of the same flow"
        string source_file "ADLS or UC Volume file path (_metadata.file_path)"
        struct sequence_key "Struct(event_time, state_priority, file_mod_time)"
    }

    FLOW_EVENT_DELTAS {
        timestamp event_time PK "Same report as in flow_events_clean, last lookback_hours"
        string event_id PK
        string local_node_ip "Plus the other flow_events_clean event columns"
        bigint bytes_sent "Bytes sent, minus a re-created flow's repeated counters"
        bigint bytes_received "Bytes received, minus a re-created flow's repeated counters"
        bigint raw_bytes_sent "bytes_sent as reported in flow_events_clean"
        bigint raw_bytes_received "bytes_received as reported in flow_events_clean"
    }

    CLUSTER_NODE_RUNS {
        string workspace_id PK
        string cluster_id PK
        string node_ip PK "Stores both host_private_ip and container private_ip"
        bigint run_id PK "0 for the cluster-level node tenure row"
        string node_role "DRIVER or WORKER"
        bigint job_id "Nullable if no job run is active"
        bigint task_run_id "Nullable task run ID"
        string job_name "Job or cluster display name"
        timestamp observed_start "UTC interval start"
        timestamp observed_end "UTC interval end"
        string source "LIVE_API or SYNTHETIC"
    }

    JOB_EXCEPTIONS {
        string workspace_id PK
        bigint job_id PK
        string job_name
        string reason
        string approved_by
        timestamp effective_from
        timestamp effective_to "Nullable (open-ended exemption)"
    }

    JOB_BANDWIDTH_5M {
        timestamp window_start PK "5-minute tumbling window start (UTC)"
        timestamp window_end PK "5-minute tumbling window end (UTC)"
        string workspace_id PK
        string cluster_id PK "UNATTRIBUTED when node_ip has no cluster match"
        string attribution_category PK "MONITORED, EXEMPT, SHARED, UNATTRIBUTED"
        bigint job_id "Populated for MONITORED and EXEMPT"
        bigint run_id "Populated for MONITORED and EXEMPT"
        string job_name "Job name or candidate summary for SHARED"
        array candidate_job_ids "Distinct active job_ids overlapping the cluster window"
        bigint bytes_sent "Sum of bytes_sent in window"
        bigint bytes_received "Sum of bytes_received in window"
        bigint total_bytes "bytes_sent + bytes_received"
        bigint private_endpoint_bytes "Subset of total_bytes with traffic_scope=PRIVATE_ENDPOINT"
        bigint external_bytes "Subset of total_bytes with traffic_scope=EXTERNAL"
        double avg_mbps "total_bytes * 8.0 / 300.0 / 1000000.0"
        double threshold_mbps "Configured breach threshold in Mbps"
        string top_remote_peer_ip "Remote IP with highest byte volume in window"
        boolean is_breach "True when attribution_category != EXEMPT and avg_mbps > threshold_mbps"
    }

    BREACH_NOTIFICATIONS {
        timestamp window_start PK "Breaching 5-minute window start (UTC)"
        string workspace_id PK
        string cluster_id PK
        bigint run_id PK "NULL for SHARED or UNATTRIBUTED windows (matched null-safely)"
        string attribution_category "MONITORED, SHARED, or UNATTRIBUTED when first detected"
        double avg_mbps "5-minute average bandwidth when first detected"
        timestamp detected_at "When record_new_breaches first recorded the breach"
        timestamp notified_at "NULL until the alert evaluation reporting it succeeded"
    }
```

---

## 2. Table Specifications and Auto CDC Mechanics

### 2.1 `flow_events_clean` (SDP Streaming Table via Auto CDC)

Azure Network Watcher appends new records to the same hourly `PT1H.json` blob every minute. To prevent duplicate byte counting when Auto Loader re-reads an updated `PT1H.json` file:

- **Primary Key (`event_id`):**
  ```text
  sha2(concat_ws('|',
    flow_log_guid,
    normalized_mac,
    cast(epoch_ms as string),
    src_ip,
    dest_ip,
    cast(src_port as string),
    cast(dest_port as string),
    cast(protocol as string),
    direction
  ), 256)
  ```
  `flow_log_guid` is the record's `flowLogGUID`. Notice that `state` (`C` vs. `E`) is intentionally excluded from `event_id` while included in `sequence_key` (`state_priority`: `E = 2`, `C = 1`). If an ending (`E`) record revises a continuing (`C`) record at the exact same millisecond timestamp, Auto CDC updates the existing `event_id` in place rather than inserting a second row.
- **Auto CDC Sequencing (`sequence_key`):**
  ```python
  F.struct(
      F.col("event_time").alias("event_time"),
      F.when(F.col("flow_state") == "E", F.lit(2)).otherwise(F.lit(1)).alias("state_priority"),
      F.col("file_modification_time").alias("file_mod_time"),
  )
  ```
- **SCD Type:** `stored_as_scd_type = 1` (retains only the latest version of each `event_id`).
- **Merge Keys & Layout:** Auto CDC keys on `(event_time, event_id)` and the table is liquid-clustered on `event_time`. `event_time` is derived from the same timestamp as `event_id`, so deduplication is unchanged, while each micro-batch merge can prune to the recent files that re-read `PT1H.json` tuples belong to instead of scanning the whole table.
- **Retention:** `snapshot_cluster_nodes` deletes flow events older than `retention_days` (default 30) at the start of each run. Old hourly `PT1H.json` blobs are never modified again, so Auto Loader does not re-ingest deleted events.

### 2.2 `cluster_node_runs` (SDP Managed Compute Ownership Table) & `live_cluster_node_snapshots`

Classic compute nodes in VNet-injected workspaces often expose two IP addresses:
- `host_private_ip`: The Azure VM NIC IP in the public/host subnet (e.g., `10.x.0.4`). External and Private Endpoint flows in VNet Flow Logs record this IP.
- `private_ip`: The Spark container IP in the private/container subnet (e.g., `10.x.64.5`).

Defined directly inside the SDP pipeline (`@dlt.table(name="cluster_node_runs")`), this table tracks **each distinct IP address** (`host_private_ip` and `private_ip`) of every node in a running or historical cluster (persisting live API snapshots into `${catalog}.${schema}.live_cluster_node_snapshots` so terminated ephemeral job clusters retain their IP-to-job mappings across refreshes) so `flow_events_clean.local_node_ip` always joins cleanly on `local_node_ip = node_ip` and `event_time BETWEEN observed_start AND observed_end`.

Every snapshot records **sightings**: a node seen alive at snapshot time `T` spans `[boot start, T]`, and each run active on its cluster spans `[max(run start, boot start), T]`. The boot start is 5 minutes before the node's reported start, but never before its cluster's start. A node's VM sends traffic before the API reports it started, mostly the Databricks Runtime image and library downloads, and that traffic counts toward the cluster and its job run. Terminated clusters are never sighted, even if the API still lists their old IPs. Because Azure assigns a freed IP to the next VM created in the subnet, the pipeline resolves the sightings into windows that never overlap across IP reuse:

- **Node tenure rows** (`job_id` `NULL`, `run_id = 0`): one per `(cluster_id, node_ip)`, from its earliest sighting start to its last sighting plus a 5-minute grace that covers traffic between the last snapshot and termination. The owners of an IP are taken in the order they were first sighted. A tenure never starts before the previous owner's last sighting, so a boot start cannot claim another cluster's traffic, and its grace is cut off where the next cluster's tenure on the same IP begins.
- **Job run rows**: one per run on each node IP, bounded by the node tenure, ending at the run's last sighting plus the same grace. The grace is cut off where a later run on that node begins if that run started after this one was last seen. Runs observed together remain overlapping, so genuinely concurrent jobs stay `SHARED`.

Traffic on a cluster between two runs therefore stays attributed to the cluster (`attribution_category = 'UNATTRIBUTED'` with the real `cluster_id`) instead of being double-counted or charged to the wrong job.

The `snapshot_cluster_nodes` job task records the sightings: once per run, before the pipeline refresh, it appends one row per node IP (tenure) and one per active run on that node to `live_cluster_node_snapshots` (liquid-clustered on `observed_end`), and deletes sightings older than `lookback_hours` plus 24 hours. `cluster_node_runs` reads only the sightings that can still own flow events in the `lookback_hours` window.

### 2.3 `job_exceptions` (External Operator-Editable Delta Table)

Because tables owned by an SDP pipeline cannot be modified directly by users via ad-hoc `INSERT`/`UPDATE`/`DELETE` SQL statements, `job_exceptions` is initialized outside SDP (`CREATE TABLE IF NOT EXISTS ${catalog}.${schema}.job_exceptions`) and read by the SDP pipeline. Platform administrators can exempt approved high-bandwidth ingestion or replication jobs without redeploying the bundle:

```sql
INSERT INTO ${catalog}.${schema}.job_exceptions
  (workspace_id, job_id, job_name, reason, approved_by, effective_from, effective_to)
VALUES
  ('1234567890123456', 9876543210, 'nightly-partner-bulk-extract',
   'Approved nightly 50 GB partner feed', 'platform-ops@example.com',
   TIMESTAMP '2026-10-01T00:00:00Z', NULL);
```

### 2.4 `job_bandwidth_5m` (Gold Materialized View)

Aggregates the last `lookback_hours` of `flow_event_deltas` (hour-aligned, default 24) into 5-minute tumbling windows (`window(event_time, "5 minutes")`), liquid-clustered on `window_start`. Each refresh recomputes only that rolling window, so its cost does not grow with history; windows older than `lookback_hours` age out of the view, while every breach detected in them remains in `breach_notifications`. Each cluster/node window is classified into one of four mutually exclusive `attribution_category` values:

| `attribution_category` | Condition | `is_breach` Eligible? |
| :--- | :--- | :--- |
| **`EXEMPT`** | Exactly 1 active `job_id` is associated with the cluster during the window **and** that `(workspace_id, job_id)` matches an active row in `job_exceptions` (`effective_from <= window_start` and `(effective_to IS NULL OR effective_to >= window_end)`). An exemption therefore starts with the first 5-minute window that begins at or after `effective_from`; the window it takes effect in is not exempt. | **No** (`is_breach = false`) |
| **`MONITORED`** | Exactly 1 active `job_id` is associated with the cluster during the window and is **not** exempt. | **Yes** (`avg_mbps > threshold_mbps`) |
| **`SHARED`** | More than 1 distinct `job_id` overlaps on the same cluster during the window. All candidate jobs are listed in `candidate_job_ids` without fabricating a per-job byte split. | **Yes** (`avg_mbps > threshold_mbps`) |
| **`UNATTRIBUTED`** | No matching cluster or active job run is found for `local_node_ip` during the window (for example, idle cluster background traffic, a cluster not sighted yet, or an unmapped VNet VM). | **Yes** (`avg_mbps > threshold_mbps`) |

**Bandwidth Rate Formula (Decimal Megabits per Second):**
\[
\text{avg\_mbps} = \frac{(\text{bytes\_sent} + \text{bytes\_received}) \times 8}{300 \times 1{,}000{,}000}
\]

### 2.5 `flow_event_deltas` (Re-created Flow Correction Materialized View)

Azure sometimes ends a flow and starts it again in the same millisecond, reporting an `E` and a `B` tuple with the same timestamp, endpoints, ports, protocol, and direction. The flow's counters do not reset: its next `C` or `E` report repeats that `E`'s counters plus whatever is new, so summing the raw reports would count those bytes twice.

- **Detection at ingestion:** `raw_flow_tuples_stream` collects the keys of the `B` tuples in each `flowTuples` array before dropping them, and sets `is_recreated` on every `E` tuple with the same key. The flag is stored in `flow_events_clean`.
- **Correction:** for each flow at the compute node's NIC (`local_node_ip`, `remote_peer_ip`, `local_port`, `remote_port`, `protocol`, `flow_direction`), ordered by `(event_time, event_id)`, a report that follows an `is_recreated` report keeps only `bytes - previous raw bytes` for `bytes_sent` and `bytes_received`, provided both of its counters are at least the previous report's. Any other report is a true delta and is left unchanged. Subtracting the previous report's raw counters keeps chained re-creations correct.
- **Scope:** the view covers the rolling `lookback_hours` window and reads one hour more, so a window's first report can still be compared with the report before it. Raw counters stay available as `raw_bytes_sent` and `raw_bytes_received`. `job_bandwidth_5m`, the dashboard's peer breakdown, and the Genie space sum bytes from this view.

---

## 3. Unity Catalog Metric View Specification (`job_bandwidth_metrics_v`)

The `publish_semantic_layer` task creates or updates the governed Unity Catalog Metric View `${catalog}.${schema}.job_bandwidth_metrics_v` on top of `job_bandwidth_5m`:

```sql
CREATE OR REPLACE VIEW ${catalog}.${schema}.job_bandwidth_metrics_v
WITH METRICS
LANGUAGE YAML
AS $$
version: 0.1
source: ${catalog}.${schema}.job_bandwidth_5m
dimensions:
  - name: window_start
    expr: window_start
  - name: window_end
    expr: window_end
  - name: workspace_id
    expr: workspace_id
  - name: cluster_id
    expr: cluster_id
  - name: job_id
    expr: job_id
  - name: run_id
    expr: run_id
  - name: job_name
    expr: COALESCE(job_name, 'Unattributed / Shared')
  - name: attribution_category
    expr: attribution_category
  - name: top_remote_peer_ip
    expr: top_remote_peer_ip
  - name: is_breach
    expr: is_breach
measures:
  - name: total_bytes
    expr: SUM(total_bytes)
  - name: total_megabytes
    expr: SUM(total_bytes) / 1000000.0
  - name: total_gigabytes
    expr: SUM(total_bytes) / 1000000000.0
  - name: bytes_received
    expr: SUM(bytes_received)
  - name: bytes_sent
    expr: SUM(bytes_sent)
  - name: private_endpoint_bytes
    expr: SUM(private_endpoint_bytes)
  - name: external_bytes
    expr: SUM(external_bytes)
  - name: peak_5m_mbps
    expr: MAX(avg_mbps)
  - name: avg_window_mbps
    expr: AVG(avg_mbps)
  - name: breach_window_count
    expr: COUNT_IF(is_breach = true)
  - name: exempt_bytes
    expr: SUM(CASE WHEN attribution_category = 'EXEMPT' THEN total_bytes ELSE 0 END)
$$;
```

---

## 4. Databricks Genie Space Specification (`resources/network_monitor_genie.yml`)

The bundle declaratively provisions a curated **Databricks Genie Space** using the native `resources.genie_spaces` DAB resource (`serialized_space` version `2`) bound to the target SQL Warehouse (`warehouse_id`) and six Unity Catalog assets:

1. `${catalog}.${schema}.breach_notifications` *(every detected breach with its job, run, and peak Mbps; the history beyond the rolling `lookback_hours` window)*
2. `${catalog}.${schema}.flow_event_deltas` *(the last 24 hours of flow events with re-created flows' repeated counters removed; the source for flow-level byte totals)*
3. `${catalog}.${schema}.flow_events_clean` *(Silver deduplicated flow tuple table for deep-dive IP/port queries)*
4. `${catalog}.${schema}.job_bandwidth_5m` *(Gold 5-minute job bandwidth attribution table)*
5. `${catalog}.${schema}.job_bandwidth_metrics_v` *(Metric View — primary KPI rollup source)*
6. `${catalog}.${schema}.job_exceptions` *(Reference table of exempt jobs)*

### Curated Genie Instructions & Benchmark Questions

- **System Instructions:**
  - *"Prefer `job_bandwidth_metrics_v` or `job_bandwidth_5m` for job-level bandwidth, Mbps rates, and threshold breach questions."*
  - *"Intra-cluster Spark shuffle traffic between classic compute nodes is already excluded from `flow_events_clean` and `job_bandwidth_5m`."*
  - *"Traffic to internal ADLS Private Endpoints is tracked in `private_endpoint_bytes` (`traffic_scope = 'PRIVATE_ENDPOINT'`), while traffic to 3rd-party or external endpoints is tracked in `external_bytes` (`traffic_scope = 'EXTERNAL'`)."*
  - *"Sum flow-level bytes from `flow_event_deltas`, which covers the last 24 hours, rather than `flow_events_clean`: when Azure re-creates a flow, the flow's next raw report in `flow_events_clean` repeats counters it already reported, and `flow_event_deltas` removes them."*
  - *"When a cluster runs multiple jobs concurrently, `attribution_category` is `'SHARED'` and candidate jobs are listed in `candidate_job_ids`."*
  - *"`job_bandwidth_5m` and `job_bandwidth_metrics_v` cover only the last 24 hours (the configured lookback window); use `breach_notifications`, which keeps every detected breach with its job, run, and peak Mbps, for older breaches."*
- **Pre-Loaded Benchmark Questions:**
  1. *"Which non-exempt Databricks jobs breached the bandwidth threshold today, and what was their peak Mbps?"*
  2. *"Compare total Private Endpoint traffic vs. external 3rd-party traffic by job over the last 24 hours."*
  3. *"What are the top 10 remote peer IP addresses receiving or sending the most bytes?"*
  4. *"Show all bandwidth windows classified as EXEMPT along with the exemption reason."*

---

## 5. AI/BI Lakeview Dashboard & SQL Alert Specifications

### 5.1 AI/BI Lakeview Dashboard (`resources/network_monitor_dashboard.yml`)

The bundle deploys a 4-panel **AI/BI Lakeview Dashboard** backed by the configured `warehouse_id`. Every panel covers the **last 24 hours**:

| Panel | Widget Type | Backing Query / Dataset | Purpose |
| :--- | :--- | :--- | :--- |
| **1. Bandwidth & Breach Summary KPIs** | Counter Cards (x3) | `job_bandwidth_5m` | Displays Peak 5-Min Bandwidth (Mbps), Total Non-Shuffle Data Transferred (decimal MB), and non-exempt Breach Windows (`COUNT_IF(is_breach)`). |
| **2. 5-Minute Bandwidth Rate (Mbps) by Attribution Category** | Stacked Area / Line Chart | `job_bandwidth_5m` grouped by `window_start`, `attribution_category` | Time-series view of `avg_mbps` across `MONITORED`, `EXEMPT`, `SHARED`, and `UNATTRIBUTED` workloads against `threshold_mbps`. |
| **3. Top Bandwidth-Consuming Jobs & Clusters** | Ranked Table | `job_bandwidth_5m` | Shows `window_start`, `job_name`, `job_id`, `run_id`, `cluster_id`, `attribution_category`, `avg_mbps`, `bytes_received`, `bytes_sent`, `top_remote_peer_ip`, and `is_breach`. |
| **4. Traffic Breakdown: Private Endpoints vs. External Peers** | Horizontal Bar Chart | `flow_event_deltas` grouped by `remote_peer_ip`, `traffic_scope` | Identifies the exact ADLS Private Endpoint IPs or external 3rd-party IPs driving the highest transfer volume. |

### 5.2 Databricks SQL Alert (`resources/network_monitor_alert.yml`)

The bundle deploys a native **Databricks SQL Alert** (`network_monitor_breach_alert`) that emails **every newly detected non-exempt breach once**. A breach is one 5-minute window of one job run (or of one cluster for `SHARED` and `UNATTRIBUTED` windows) whose `is_breach` is `true` in `job_bandwidth_5m`.

`network_monitor_job` drives the alert as part of every 5-minute run:

1. **`record_new_breaches`** (after `refresh_flow_pipeline`): `MERGE`s breaching `job_bandwidth_5m` rows from the last 24 hours that it has not seen before into `${catalog}.${schema}.breach_notifications`, keyed on `(window_start, workspace_id, cluster_id, run_id)`, with `notified_at = NULL`. An `UNATTRIBUTED` breach is recorded only once its window ended 15 minutes ago. A starting cluster is first sighted a few minutes after its first boot traffic, so the hold lets that sighting claim the window first, and the breach is emailed once, for its job run.
2. **`notify_new_breaches`** (a Lakeflow Jobs SQL alert task, `alert_task`): evaluates the alert against the pending rows below (at most 100, the oldest detections first) and emails the recipients.
3. **`mark_breaches_notified`**: once the alert evaluation has succeeded, sets `notified_at` on exactly the rows it reported, selected with the same order and limit.

```sql
SELECT
  window_start,
  window_end,
  workspace_id,
  cluster_id,
  job_id,
  run_id,
  job_name,
  attribution_category,
  ROUND(avg_mbps, 2) AS avg_mbps,
  threshold_mbps,
  bytes_received,
  bytes_sent,
  top_remote_peer_ip,
  detected_at
FROM (
  SELECT *
  FROM ${catalog}.${schema}.breach_notifications
  WHERE notified_at IS NULL
  ORDER BY detected_at, window_start, workspace_id, cluster_id, run_id
  LIMIT 100
)
ORDER BY avg_mbps DESC, window_end DESC
```

- **Alert Condition:** Triggers when the first row's `avg_mbps` (the peak, given the `ORDER BY`) is greater than `0`, that is, whenever at least one breach is pending; an empty result is `OK`. The condition uses no alert-level aggregation, because an aggregation would replace the email's breach table with its single aggregated value. The evaluated column also has no `display` label: with first-row evaluation, a display label makes the job's alert task evaluate `OK` even when breaches are pending, so no email would be sent.
- **Repeat Notifications:** `retrigger_seconds: 1` sends a notification on every evaluation that finds pending breaches, even when the previous evaluation also triggered. Because reported rows are marked notified, each email lists only breaches that are new since the previous one.
- **Delivery Guarantee:** A breach is reported once. An email lists at most 100 breaches, the email table's row limit; when more are pending, the rest stay pending and the following runs report them, oldest detections first. If a run fails after the alert evaluation but before `mark_breaches_notified`, the next run reports those breaches again rather than dropping them. A window whose attribution resolves to a specific job run only after that hold is reported again for that run.
- **Schedule:** Alerts v2 requires a schedule, but the alert's own schedule is permanently `PAUSED` in every target. The job is its only evaluator, and unpausing the schedule would race the job and send duplicate emails.
- **Exempt Job Suppression:** Because `is_breach` is `false` whenever `attribution_category = 'EXEMPT'`, approved high-bandwidth jobs never fire false-positive alerts while still remaining visible on the Lakeview Dashboard and in Genie.
- **Email Notifications:** The job's alert task emails its subscribers (the `alert_task_subscribers` bundle variable), and the alert's own subscriptions (`alert_subscriptions`) receive notifications when it is evaluated manually. Both are generated from the same recipients: Databricks workspace users and Email notification destinations for distribution lists. The email body lists the reported breaches, highest rate first, with their window, cluster, job, run, attribution, rate, bytes, and top remote peer (`{{QUERY_RESULT_TABLE}}`). See [Breach Alert Recipients](setup-and-deployment.md#breach-alert-recipients).
- **Preview Feature:** The SQL alert task (`alert_task`) is a Public Preview Lakeflow Jobs feature and must be available in the target workspace.
