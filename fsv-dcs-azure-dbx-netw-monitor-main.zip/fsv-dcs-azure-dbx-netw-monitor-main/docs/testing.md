# Testing and Validation Guide (`pytest`, `int-test` Bundle Target, and Live Environment Validation)

This project provides three complementary validation tiers so engineers can verify parsing, Auto CDC deduplication, job attribution, exemptions, dashboarding, and alerting both **without Azure network dependencies** (`int-test`) and **against live Azure VNet Flow Logs** (`dev` / `prod`).

```mermaid
flowchart TD
    subgraph Tier1 ["Tier 1: Offline Local Unit Tests (pytest)"]
        T1["• Schema v4 tuple parsing & direction normalization<br/>• Compute subnet shuffle exclusion<br/>• Auto CDC event_id & sequence_key generation<br/>• Semantic Layer, Dashboard & Genie contract checks"]
    end

    subgraph Tier2 ["Tier 2: Self-Contained Integration Target (int-test)"]
        T2["• Bundle target: int-test (is_int_test = true)<br/>• Isolated per-user schema: dev_{user}_network_monitor_int_test<br/>• Managed UC Volume: synthetic_flow_logs<br/>• Task 0 injects 7 realistic PT1H.json scenarios + overwrites<br/>• Exercises real Auto Loader + SDP Auto CDC + Metric View + Genie + Alert"]
    end

    subgraph Tier3 ["Tier 3: Live VNet Flow Log Validation (dev / prod)"]
        T3["• Upstream Network Watcher VNet Flow Logs v4 -> ADLS Gen2<br/>• Classic compute workloads across compute_subnet_cidrs<br/>• Live Clusters & Jobs API sightings (snapshot_cluster_nodes) ownership join"]
    end

    Tier1 --> Tier2 --> Tier3
```

---

## 1. Tier 1: Local Unit & Contract Tests (`pytest`)

Tier 1 runs completely offline on the developer's workstation in under a second with zero cloud credentials required.

### What Tier 1 Verifies
- **Tuple Parsing & Direction Normalization:** Confirms 13-field VNet Flow Log v4 strings (`epoch,src_ip,dest_ip,src_port,dest_port,proto,dir,state,encap,pkts_out,bytes_out,pkts_in,bytes_in`) are parsed accurately across both 10-digit second and 13-digit millisecond epochs.
- **Shuffle Exclusion vs. Private Endpoint Inclusion:** Confirms tuples with both IPs inside `compute_subnet_cidrs` are dropped, while tuples between a compute subnet IP and a Private Endpoint subnet IP (e.g., `10.0.128.0/18`) or external IP are retained with accurate `traffic_scope` (`PRIVATE_ENDPOINT` vs. `EXTERNAL`).
- **Auto CDC Identity & Sequencing:** Confirms `event_id` is deterministic and `sequence_key` orders `E` (Ending) updates ahead of `C` (Continuing) updates at the same millisecond.
- **Contract & Deployment Guardrails:** Confirms Lakeview Dashboard JSON, Metric View DDL, Genie Space table sorting, and the one-shot deployment orchestrator (`scripts/deploy.py`).

### Running Tier 1 Locally

**Windows PowerShell:**
```powershell
$FsvPython = Join-Path (Get-Location) '.venv\Scripts\python.exe'
& $FsvPython -m mypy src scripts
& $FsvPython -m ruff check src scripts
& $FsvPython -m ruff format --check src scripts
& $FsvPython -m pytest
```

**macOS / Linux (`zsh` / `bash`):**
```bash
.venv/bin/mypy src scripts
.venv/bin/ruff check src scripts
.venv/bin/ruff format --check src scripts
.venv/bin/pytest
```

---

## 2. Tier 2: Self-Contained Integration Testing (`int-test` Bundle Target)

The **`int-test` bundle target** allows any engineer or operator team to test the entire Databricks pipeline—including **Spark Auto Loader (`cloudFiles`)**, **SDP Auto CDC (`create_auto_cdc_flow`)**, **`job_bandwidth_5m` attribution**, **Unity Catalog Metric View**, **Genie Space**, **Lakeview Dashboard**, and **SQL Alert**—without needing Azure Network Watcher flow logs or active classic compute VMs.

### How the `int-test` Target Works

When deployed with `-t int-test`, `databricks.yml` configures:
- `schema = "dev_${workspace.current_user.short_name}_network_monitor_int_test"` (isolated from `dev` and `prod` schemas).
- `is_int_test = "true"` (passed into job tasks and SDP pipeline configuration).
- `flow_log_source_path = "/Volumes/${var.catalog}/${var.schema}/synthetic_flow_logs"`.
- `flow_log_target_resource_ids` set to the synthetic VNet's resource ID, in a different letter case from the generated records, so the case-insensitive flow-log target filter is exercised.
- `flow_log_start_after = "2000-01-01T00:00:00Z"`, which every synthetic file is newer than, so the Auto Loader `modifiedAfter` filter runs without skipping any scenario.
- A managed Unity Catalog Volume (`resources.volumes.synthetic_flow_logs`) provisioned automatically in the isolated `int-test` schema.
- A 5-minute Quartz cron schedule (`0 */5 * * * ?` UTC, `max_concurrent_runs: 1` with queueing off so an overrunning run skips the next trigger, controlled by `schedule_pause_status`) on `network_monitor_job` alongside an upstream task (`generate_synthetic_telemetry`) that accumulates 5-minute flow intervals into the current hour's `PT1H.json` file just like Azure Network Watcher.

### The 7 Deterministic Scenarios Injected by `generate_synthetic_telemetry`

On each execution, `generate_synthetic_telemetry` appends the current 5-minute window's tuples into the hourly `PT1H.json` blob in `/Volumes/${catalog}/${schema}/synthetic_flow_logs` (preserving any earlier 5-minute windows in the same clock hour) and seeds synthetic node/run records so every attribution branch—including both active IP hits and temporal/unknown IP misses—is exercised:

| Scenario ID | Simulated Workload & Flow Tuples | Expected Pipeline & Table Outcome |
| :--- | :--- | :--- |
| **S1: Dedicated Monitored Breach** | Cluster `cluster-monitored-01` (`node_ip = 10.0.0.4`) running single `job_id = 1001` (`fx-market-feed-ingest`) downloads **120 MB** (`O` flow, reverse counter) from external peer `20.60.194.131:443` within a 5-min window. | Classified as `MONITORED` (`traffic_scope = 'EXTERNAL'`), `avg_mbps = 3.20`, `is_breach = true` (when `threshold_mbps = 1.0`). |
| **S2: Internal ADLS Private Endpoint Read** | Cluster `cluster-pe-02` (`node_ip = 10.0.0.5`) running single `job_id = 1002` (`adls-bronze-backfill`) reads **180 MB** from internal Private Endpoint IP `10.0.128.10:443` (outside `compute_subnet_cidrs`, inside `private_endpoint_cidrs`). | Retained (not dropped as shuffle!), `traffic_scope = 'PRIVATE_ENDPOINT'`, classified as `MONITORED`, `avg_mbps = 4.80`, `is_breach = true`. |
| **S3: Intra-Cluster Spark Shuffle Exclusion** | Driver `10.0.64.5` and Worker `10.0.64.4` (both inside `compute_subnet_cidrs`) exchange **500 MB** of shuffle data on port `7337`. | **100% excluded** by `raw_flow_tuples_stream`; 0 bytes appear in `flow_events_clean` or `job_bandwidth_5m`. |
| **S4: Approved Exempt Job** | Cluster `cluster-exempt-03` (`node_ip = 10.0.0.6`) running `job_id = 1003` (`regulatory-archive-sync`, present in `job_exceptions`) uploads **150 MB** to `20.60.194.131:443`. | Byte volume (`150 MB`, `4.00 Mbps`) is recorded and visible, classified as `EXEMPT`, and **`is_breach = false`** (suppresses SQL Alert). |
| **S5: Shared Cluster Concurrency** | Cluster `cluster-shared-04` (`node_ip = 10.0.0.7`) runs `job_id = 2001` and `job_id = 2002` concurrently while transferring **90 MB**. | Classified as `SHARED` with `candidate_job_ids = [2001, 2002]`, no fabricated per-job split, and `is_breach = true`. |
| **S6: Unattributed Traffic (Temporal & Unknown-IP Misses) + `PT1H.json` Overwrite Idempotency** | Expired-lease IP `10.0.0.99` (**10 MB**; present in `cluster_node_runs` for a terminated job from 2 hours ago) and unknown IP `10.0.0.98` (**5 MB**; absent from `cluster_node_runs`) total **15 MB** (`UNATTRIBUTED`). Additionally, the generator **overwrites `PT1H.json`** with all prior windows plus a `C` -> `E` revision for S1. | Both temporal and unknown-IP misses resolve to `UNATTRIBUTED` (`0.40 Mbps`, `is_breach = false`); Auto CDC (`flow_events_clean`) deduplicates the overwritten prefix with **0 double-counted bytes** and updates the revised `E` counter in place. |
| **S7: Re-created Flow** | Cluster `cluster-recreated-07` (`node_ip = 10.0.0.8`) running `job_id = 1007` (`recreated-flow-transfer`) reports an `E` and a `B` tuple in the same millisecond (**20 MB**), and 20 seconds later an `E` that repeats those counters plus **1,000,256** new bytes, as Azure does when it re-creates a flow. Its tuples carry Azure's non-numeric encryption field (`NX`). | `is_recreated` is set on the first `E`; `flow_event_deltas` keeps only the new bytes of the second, so the flow totals **21,000,256** bytes (`0.56 Mbps`, `is_breach = false`). Counted as raw deltas it would be 41,000,256 bytes (`1.09 Mbps`) and breach. |

### Running & Verifying `int-test` via One-Shot Deployment (`scripts/deploy.py`)

**Windows PowerShell:**
```powershell
$FsvPython = Join-Path (Get-Location) '.venv\Scripts\python.exe'
Copy-Item configs\deploy.int-test.example.json configs\deploy.int-test.local.json
# Edit configs\deploy.int-test.local.json with your profile, catalog, warehouse_id, and alert_email_recipients
& $FsvPython scripts\deploy.py --config configs\deploy.int-test.local.json
```

**macOS / Linux (`zsh` / `bash`):**
```bash
cp configs/deploy.int-test.example.json configs/deploy.int-test.local.json
# Edit configs/deploy.int-test.local.json with your profile, catalog, warehouse_id, and alert_email_recipients
.venv/bin/python scripts/deploy.py --config configs/deploy.int-test.local.json
```

### Verification Query on `int-test` Output

```sql
SELECT
  attribution_category,
  job_id,
  job_name,
  candidate_job_ids,
  bytes_sent,
  bytes_received,
  private_endpoint_bytes,
  external_bytes,
  ROUND(avg_mbps, 2) AS avg_mbps,
  is_breach
FROM <your-catalog>.<your-int-test-schema>.job_bandwidth_5m
ORDER BY attribution_category, job_id;
```

### Verifying Breach Emails on `int-test`

Each `network_monitor_job` run records the current window's synthetic breaches (S1, S2, and S5 at `threshold_mbps = 1.0`) in `breach_notifications`, evaluates the SQL alert through its `notify_new_breaches` task, and then marks them notified. Expect **one email per job run** listing those three windows to the configured `alert_email_recipients`. Confirm that every recorded breach was reported:

```sql
SELECT
  window_start,
  cluster_id,
  job_id,
  run_id,
  attribution_category,
  ROUND(avg_mbps, 2) AS avg_mbps,
  detected_at,
  notified_at
FROM <your-catalog>.<your-int-test-schema>.breach_notifications
ORDER BY detected_at DESC, avg_mbps DESC;
```

Every row from a completed run has a non-`NULL` `notified_at`. Running the job again within the same 5-minute window records no new rows and sends no email.

---

## 3. Tier 3: Live Environment Validation (`dev` / `prod` Targets)

Once Azure Network Watcher VNet Flow Logs (Schema v4) are delivering to your ADLS Gen2 storage account and accessible via a Unity Catalog External Location or Volume (see [docs/vnet-flow-logs-prerequisite.md](vnet-flow-logs-prerequisite.md)):

1. **Prepare the `dev` Deployment Configuration (`configs/deploy.dev.local.json`):**
   - Copy `configs/deploy.dev.example.json` to `configs/deploy.dev.local.json`.
   - Set `catalog`, `schema`, `warehouse_id`, `compute_subnet_cidrs` (your workspace's classic compute `public`/host and `private`/container subnet CIDRs), optional `private_endpoint_cidrs`, and `flow_log_source_path` (`abfss://insights-logs-flowlogflowevent@<storage-account>.dfs.core.windows.net/`).
   - Set `flow_log_target_resource_ids` to the Databricks VNet's resource ID, and `flow_log_start_after` to the first date to ingest (or clear it to read every flow log already in storage).
2. **Deploy & Run the Monitor Pipeline (`scripts/deploy.py`):**
   - Execute `python scripts/deploy.py --config configs/deploy.dev.local.json`.
3. **Verify Live Attribution & Analytics Assets:**
   - Confirm that `flow_events_clean` ingests and deduplicates `C`/`E` tuples while excluding intra-cluster Spark shuffle across `compute_subnet_cidrs`.
   - Confirm that the `snapshot_cluster_nodes` task output reports your run-as identity (`run_as`) and a non-zero `sightings` count while classic compute is running.
   - Confirm that `cluster_node_runs` and `live_cluster_node_snapshots` record active classic compute node IPs (`host_private_ip` and container `private_ip`) and join cleanly in `job_bandwidth_5m` and `job_bandwidth_metrics_v`.
   - Open the deployed **AI/BI Lakeview Dashboard**, **Databricks Genie Space**, and **Databricks SQL Alert** URLs printed by `scripts/deploy.py`.
