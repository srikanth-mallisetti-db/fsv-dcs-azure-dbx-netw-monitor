"""Synthetic Azure VNet Flow Log v4 and compute ownership generator for the int-test target.

Generates authentic Schema v4 PT1H.json flow log blobs and matching compute ownership +
job exemption records covering all 7 deterministic validation scenarios (S1-S7), including:
  - Cumulative multi-window accumulation within the same hourly PT1H.json file,
  - 1-minute PT1H.json file overwrites and C -> E state revisions,
  - Both active IP hits (dedicated, Private Endpoint, exempt, shared) and IP misses
    (temporal expired-lease IP miss + unknown-IP miss),
  - A re-created flow whose next report repeats its counters.
"""

from __future__ import annotations

import json
import os
import time
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from network_monitor.flow_utils import (
    JobExceptionRule,
    NodeOwnershipWindow,
    floor_to_5m_window,
    normalize_epoch_ms,
)
from network_monitor.ownership import CLUSTER_NODE_RUNS_SPARK_DDL, ownership_rows_to_dicts

JOB_EXCEPTIONS_SPARK_DDL: str = (
    "workspace_id STRING, "
    "job_id BIGINT, "
    "job_name STRING, "
    "reason STRING, "
    "approved_by STRING, "
    "effective_from TIMESTAMP, "
    "effective_to TIMESTAMP"
)

SYNTHETIC_COMPUTE_SUBNET_CIDRS: str = "10.0.0.0/18,10.0.64.0/18"
SYNTHETIC_PRIVATE_ENDPOINT_CIDRS: str = "10.0.128.0/18"
SYNTHETIC_THRESHOLD_MBPS: float = 1.0
SYNTHETIC_FLOW_LOG_GUID: str = "00000000-1111-2222-3333-444444444444"
SYNTHETIC_MAC_ADDRESS: str = "00-0D-3A-11-22-33"
SYNTHETIC_EXTERNAL_PEER_IP: str = "20.60.194.131"
SYNTHETIC_ADLS_PE_IP: str = "10.0.128.10"
SYNTHETIC_VNET_RESOURCE_ID: str = (
    "/SUBSCRIPTIONS/00000000-0000-0000-0000-000000000000"
    "/RESOURCEGROUPS/RG-DATABRICKS/PROVIDERS/MICROSOFT.NETWORK"
    "/VIRTUALNETWORKS/VNET-SYNTHETIC"
)


@dataclass(frozen=True, slots=True)
class SyntheticDataset:
    """Complete deterministic synthetic dataset for the 7 int-test validation scenarios."""

    window_start: datetime
    window_end: datetime
    workspace_id: str
    flow_log_guid: str
    mac_address: str
    pt1h_rev1_document: dict[str, Any]
    pt1h_rev2_document: dict[str, Any]
    ownership_rows: tuple[NodeOwnershipWindow, ...]
    exception_rules: tuple[JobExceptionRule, ...]


def _build_pt1h_document(
    *,
    record_time: datetime,
    flow_log_guid: str,
    mac_address: str,
    tuples: list[str],
) -> dict[str, Any]:
    iso_time = record_time.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%S.%f0Z")
    norm_mac = mac_address.replace("-", "").replace(":", "").upper()
    return {
        "records": [
            {
                "time": iso_time,
                "flowLogVersion": 4,
                "flowLogGUID": flow_log_guid,
                "macAddress": norm_mac,
                "category": "FlowLogFlowEvent",
                "flowLogResourceID": (
                    "/SUBSCRIPTIONS/00000000-0000-0000-0000-000000000000"
                    "/RESOURCEGROUPS/RG-NETWORK-WATCHER/PROVIDERS/MICROSOFT.NETWORK"
                    "/NETWORKWATCHERS/NW-SYNTHETIC/FLOWLOGS/FL-VNET-SYNTHETIC"
                ),
                "targetResourceID": SYNTHETIC_VNET_RESOURCE_ID,
                "operationName": "FlowLogFlowEvent",
                "flowRecords": {
                    "flows": [
                        {
                            "aclID": "00000000-aaaa-bbbb-cccc-000000000001",
                            "flowGroups": [
                                {
                                    "rule": "DefaultRule_AllowInternetAndVnetOutBound",
                                    "flowTuples": list(tuples),
                                }
                            ],
                        }
                    ]
                },
            }
        ]
    }


def build_synthetic_dataset(
    *,
    reference_time: datetime | None = None,
    workspace_id: str = "SYNTHETIC_WS",
) -> SyntheticDataset:
    """Construct the 7 deterministic int-test scenarios (S1-S7) for a 5-minute window."""
    base_now = (
        reference_time.astimezone(UTC)
        if reference_time is not None and reference_time.tzinfo is not None
        else (
            reference_time.replace(tzinfo=UTC)
            if reference_time is not None
            else datetime.now(UTC) - timedelta(minutes=5)
        )
    )
    win_start, win_end = floor_to_5m_window(base_now)
    base_ms = int(win_start.timestamp() * 1000)

    s1_ms = base_ms + 15_000
    s2_ms = base_ms + 30_000
    s3_ms = base_ms + 45_000
    s4_ms = base_ms + 60_000
    s5_ms = base_ms + 75_000
    s6_expired_ms = base_ms + 90_000
    s6_unknown_ms = base_ms + 105_000
    s7_ms = base_ms + 120_000
    # A flow's B tuple is reported when it begins, before its C/E reports; a B in the same
    # millisecond as an E marks a re-created flow (S7)
    anchor_lead_ms = 5_000

    # Revision 1 tuples (initial 1-minute PT1H.json write):
    # - S1 starts as a Continuing ('C') delta with 100 MB (revised to 'E' with 120 MB in Rev 2)
    rev1_tuples: list[str] = [
        # S1: Dedicated Monitored Breach (node 10.0.0.4 -> external 20.60.194.131:443)
        f"{s1_ms - anchor_lead_ms},10.0.0.4,{SYNTHETIC_EXTERNAL_PEER_IP},51001,443,6,O,B,0,0,0,0,0",
        f"{s1_ms},10.0.0.4,{SYNTHETIC_EXTERNAL_PEER_IP},51001,443,6,O,C,0,500,0,80000,100000000",
        # S2: Internal ADLS Private Endpoint Read (node 10.0.0.5 -> PE 10.0.128.10:443, 180 MB)
        f"{s2_ms - anchor_lead_ms},10.0.0.5,{SYNTHETIC_ADLS_PE_IP},51002,443,6,O,B,0,0,0,0,0",
        f"{s2_ms},10.0.0.5,{SYNTHETIC_ADLS_PE_IP},51002,443,6,O,E,0,900,0,144000,180000000",
        # S3: Intra-Cluster Spark Shuffle (10.0.64.5 <-> 10.0.64.4 on port 7337, 500 MB -> excluded)
        f"{s3_ms},10.0.64.5,10.0.64.4,7337,44100,6,O,C,0,200000,250000000,200000,250000000",
        # S4: Approved Exempt Job (node 10.0.0.6 -> external 20.60.194.131:443, 150 MB upload)
        f"{s4_ms},10.0.0.6,{SYNTHETIC_EXTERNAL_PEER_IP},51003,443,6,O,E,0,120000,150000000,600,0",
        # S5: Shared Cluster Concurrency (node 10.0.0.7 running jobs 2001 & 2002, 90 MB total)
        f"{s5_ms},10.0.0.7,{SYNTHETIC_EXTERNAL_PEER_IP},51004,443,6,O,C,0,24000,30000000,48000,60000000",
        # S6a: Unattributed Temporal Miss (10.0.0.99 has an expired lease in cluster_node_runs)
        (
            f"{s6_expired_ms},10.0.0.99,{SYNTHETIC_EXTERNAL_PEER_IP},"
            "51099,443,6,O,E,0,2500,3000000,5500,7000000"
        ),
        # S6b: Unattributed Unknown-IP Miss (10.0.0.98 has zero rows in cluster_node_runs, 5 MB)
        (
            f"{s6_unknown_ms},10.0.0.98,{SYNTHETIC_EXTERNAL_PEER_IP},"
            "51098,443,6,O,E,0,1500,2000000,2500,3000000"
        ),
        # S7: Re-created flow (node 10.0.0.8 -> external 20.60.194.131:443). Azure ends and
        # restarts the flow in one millisecond (E + B, 20 MB); 20 s later the next E repeats
        # those counters plus 1,000,256 new bytes. Counted once that is 21,000,256 bytes
        # (0.56 Mbps, no breach); counted as raw deltas it would be 41,000,256 (1.09 Mbps, breach).
        (
            f"{s7_ms},10.0.0.8,{SYNTHETIC_EXTERNAL_PEER_IP},"
            "51007,443,6,O,E,NX,1000,1000000,14000,19000000"
        ),
        f"{s7_ms},10.0.0.8,{SYNTHETIC_EXTERNAL_PEER_IP},51007,443,6,O,B,NX,0,0,0,0",
        (
            f"{s7_ms + 20_000},10.0.0.8,{SYNTHETIC_EXTERNAL_PEER_IP},"
            "51007,443,6,O,E,NX,1002,1000256,14700,20000000"
        ),
    ]

    # Revision 2 tuples (overwritten PT1H.json 1 minute later):
    # Contains all Rev 1 tuples PLUS the C -> E revision for S1 at the same timestamp (120 MB)
    rev2_tuples: list[str] = [
        *rev1_tuples,
        f"{s1_ms},10.0.0.4,{SYNTHETIC_EXTERNAL_PEER_IP},51001,443,6,O,E,0,600,0,96000,120000000",
    ]

    pt1h_rev1 = _build_pt1h_document(
        record_time=win_start + timedelta(minutes=1),
        flow_log_guid=SYNTHETIC_FLOW_LOG_GUID,
        mac_address=SYNTHETIC_MAC_ADDRESS,
        tuples=rev1_tuples,
    )
    pt1h_rev2 = _build_pt1h_document(
        record_time=win_start + timedelta(minutes=2),
        flow_log_guid=SYNTHETIC_FLOW_LOG_GUID,
        mac_address=SYNTHETIC_MAC_ADDRESS,
        tuples=rev2_tuples,
    )

    obs_start = win_start - timedelta(minutes=2)
    obs_end = win_end + timedelta(minutes=2)
    expired_start = win_start - timedelta(hours=3)
    expired_end = win_start - timedelta(hours=2)

    ownership_rows: tuple[NodeOwnershipWindow, ...] = (
        # S1: cluster-monitored-01 (both host NIC IP 10.0.0.4 and container IP 10.0.64.4)
        NodeOwnershipWindow(
            workspace_id=workspace_id,
            cluster_id="cluster-monitored-01",
            node_ip="10.0.0.4",
            run_id=501001,
            job_id=1001,
            job_name="fx-market-feed-ingest",
            observed_start=obs_start,
            observed_end=obs_end,
            node_role="WORKER",
            task_run_id=901001,
            source="SYNTHETIC",
        ),
        NodeOwnershipWindow(
            workspace_id=workspace_id,
            cluster_id="cluster-monitored-01",
            node_ip="10.0.64.4",
            run_id=501001,
            job_id=1001,
            job_name="fx-market-feed-ingest",
            observed_start=obs_start,
            observed_end=obs_end,
            node_role="WORKER",
            task_run_id=901001,
            source="SYNTHETIC",
        ),
        # S2: cluster-pe-02 (both host NIC IP 10.0.0.5 and container IP 10.0.64.5)
        NodeOwnershipWindow(
            workspace_id=workspace_id,
            cluster_id="cluster-pe-02",
            node_ip="10.0.0.5",
            run_id=501002,
            job_id=1002,
            job_name="adls-bronze-backfill",
            observed_start=obs_start,
            observed_end=obs_end,
            node_role="DRIVER",
            task_run_id=901002,
            source="SYNTHETIC",
        ),
        NodeOwnershipWindow(
            workspace_id=workspace_id,
            cluster_id="cluster-pe-02",
            node_ip="10.0.64.5",
            run_id=501002,
            job_id=1002,
            job_name="adls-bronze-backfill",
            observed_start=obs_start,
            observed_end=obs_end,
            node_role="DRIVER",
            task_run_id=901002,
            source="SYNTHETIC",
        ),
        # S4: cluster-exempt-03 (job_id = 1003, regulatory-archive-sync)
        NodeOwnershipWindow(
            workspace_id=workspace_id,
            cluster_id="cluster-exempt-03",
            node_ip="10.0.0.6",
            run_id=501003,
            job_id=1003,
            job_name="regulatory-archive-sync",
            observed_start=obs_start,
            observed_end=obs_end,
            node_role="WORKER",
            task_run_id=901003,
            source="SYNTHETIC",
        ),
        NodeOwnershipWindow(
            workspace_id=workspace_id,
            cluster_id="cluster-exempt-03",
            node_ip="10.0.64.6",
            run_id=501003,
            job_id=1003,
            job_name="regulatory-archive-sync",
            observed_start=obs_start,
            observed_end=obs_end,
            node_role="WORKER",
            task_run_id=901003,
            source="SYNTHETIC",
        ),
        # S5: cluster-shared-04 concurrently running job_id=2001 and job_id=2002
        NodeOwnershipWindow(
            workspace_id=workspace_id,
            cluster_id="cluster-shared-04",
            node_ip="10.0.0.7",
            run_id=502001,
            job_id=2001,
            job_name="shared-liquidity-calc",
            observed_start=obs_start,
            observed_end=obs_end,
            node_role="WORKER",
            task_run_id=902001,
            source="SYNTHETIC",
        ),
        NodeOwnershipWindow(
            workspace_id=workspace_id,
            cluster_id="cluster-shared-04",
            node_ip="10.0.0.7",
            run_id=502002,
            job_id=2002,
            job_name="shared-risk-aggregation",
            observed_start=obs_start,
            observed_end=obs_end,
            node_role="WORKER",
            task_run_id=902002,
            source="SYNTHETIC",
        ),
        # S7: cluster-recreated-07 (job_id = 1007, its flow is re-created mid-window)
        NodeOwnershipWindow(
            workspace_id=workspace_id,
            cluster_id="cluster-recreated-07",
            node_ip="10.0.0.8",
            run_id=501007,
            job_id=1007,
            job_name="recreated-flow-transfer",
            observed_start=obs_start,
            observed_end=obs_end,
            node_role="WORKER",
            task_run_id=901007,
            source="SYNTHETIC",
        ),
        # S6a: Expired node lease on 10.0.0.99 (terminated 2 hours prior -> Temporal Miss)
        NodeOwnershipWindow(
            workspace_id=workspace_id,
            cluster_id="cluster-expired-06",
            node_ip="10.0.0.99",
            run_id=501099,
            job_id=1099,
            job_name="terminated-backfill-job",
            observed_start=expired_start,
            observed_end=expired_end,
            node_role="WORKER",
            task_run_id=901099,
            source="SYNTHETIC",
        ),
    )

    exception_rules: tuple[JobExceptionRule, ...] = (
        JobExceptionRule(
            workspace_id=workspace_id,
            job_id=1003,
            job_name="regulatory-archive-sync",
            reason="Approved nightly regulatory compliance archive replication",
            approved_by="platform-netops@example.com",
            effective_from=win_start - timedelta(days=7),
            effective_to=None,
        ),
    )

    return SyntheticDataset(
        window_start=win_start,
        window_end=win_end,
        workspace_id=workspace_id,
        flow_log_guid=SYNTHETIC_FLOW_LOG_GUID,
        mac_address=SYNTHETIC_MAC_ADDRESS,
        pt1h_rev1_document=pt1h_rev1,
        pt1h_rev2_document=pt1h_rev2,
        ownership_rows=ownership_rows,
        exception_rules=exception_rules,
    )


def _record_belongs_to_window(
    record: Mapping[str, Any],
    window_start: datetime,
    window_end: datetime,
) -> bool:
    """Return True if any flowTuple in record falls inside [window_start, window_end)."""
    start_ms = int(window_start.astimezone(UTC).timestamp() * 1000)
    end_ms = int(window_end.astimezone(UTC).timestamp() * 1000)

    flow_records = record.get("flowRecords")
    if not isinstance(flow_records, Mapping):
        return False
    flows = flow_records.get("flows")
    if not isinstance(flows, Sequence):
        return False
    for flow in flows:
        if not isinstance(flow, Mapping):
            continue
        groups = flow.get("flowGroups")
        if not isinstance(groups, Sequence):
            continue
        for group in groups:
            if not isinstance(group, Mapping):
                continue
            tuples = group.get("flowTuples")
            if not isinstance(tuples, Sequence):
                continue
            for raw_tuple in tuples:
                if not isinstance(raw_tuple, str):
                    continue
                first_token = raw_tuple.split(",", 1)[0].strip()
                try:
                    epoch_ms = normalize_epoch_ms(first_token)
                except ValueError:
                    continue
                if start_ms <= epoch_ms < end_ms:
                    return True
    return False


def _load_prior_hour_records(
    pt1h_path: Path,
    current_window_start: datetime,
    current_window_end: datetime,
) -> list[dict[str, Any]]:
    """Load existing records[] from an hourly PT1H.json file, excluding the current 5-min window."""
    if not pt1h_path.is_file():
        return []
    try:
        existing_doc = json.loads(pt1h_path.read_text(encoding="utf-8"))
    except Exception:
        return []
    if not isinstance(existing_doc, Mapping):
        return []
    raw_records = existing_doc.get("records")
    if not isinstance(raw_records, Sequence):
        return []

    retained: list[dict[str, Any]] = []
    for rec in raw_records:
        if isinstance(rec, dict) and not _record_belongs_to_window(
            rec, current_window_start, current_window_end
        ):
            retained.append(rec)
    return retained


def write_synthetic_flow_log_files(
    dataset: SyntheticDataset,
    volume_root_path: str | Path,
    *,
    overwrite_delay_seconds: float = 0.02,
) -> Path:
    """Write Revision 1 of PT1H.json and overwrite it with Revision 2 in Azure folder layout.

    Preserves any earlier 5-minute window records already written to the same hourly
    PT1H.json file so continuous 5-minute runs accumulate across the clock hour just
    like Azure Network Watcher.
    """
    win = dataset.window_start.astimezone(UTC)
    norm_mac = dataset.mac_address.replace("-", "").replace(":", "").upper()
    hour_dir = (
        Path(volume_root_path)
        / "resourceId=SUBSCRIPTIONS_SYNTHETIC_FLOWLOGS"
        / f"y={win.year:04d}"
        / f"m={win.month:02d}"
        / f"d={win.day:02d}"
        / f"h={win.hour:02d}"
        / "m=00"
        / f"macAddress={norm_mac}"
    )
    hour_dir.mkdir(parents=True, exist_ok=True)
    pt1h_path = hour_dir / "PT1H.json"

    prior_records = _load_prior_hour_records(
        pt1h_path,
        dataset.window_start,
        dataset.window_end,
    )

    rev1_doc = {
        "records": [
            *prior_records,
            *dataset.pt1h_rev1_document["records"],
        ]
    }
    pt1h_path.write_text(json.dumps(rev1_doc, indent=2), encoding="utf-8")

    if overwrite_delay_seconds > 0:
        time.sleep(overwrite_delay_seconds)

    rev2_doc = {
        "records": [
            *prior_records,
            *dataset.pt1h_rev2_document["records"],
        ]
    }
    pt1h_path.write_text(json.dumps(rev2_doc, indent=2), encoding="utf-8")

    # Ensure mtime strictly reflects the latest revision
    now_ts = time.time()
    try:
        os.utime(pt1h_path, (now_ts, now_ts))
    except OSError:
        pass

    return pt1h_path


def exception_rules_to_dicts(rules: tuple[JobExceptionRule, ...]) -> list[dict[str, Any]]:
    """Serialize JobExceptionRule objects into Spark DataFrame row dictionaries."""
    return [
        {
            "workspace_id": r.workspace_id,
            "job_id": int(r.job_id),
            "job_name": r.job_name,
            "reason": r.reason,
            "approved_by": r.approved_by,
            "effective_from": r.effective_from,
            "effective_to": r.effective_to,
        }
        for r in rules
    ]


def seed_synthetic_environment(
    spark_session: Any,
    *,
    catalog: str,
    schema: str,
    volume_path: str,
    workspace_id: str = "SYNTHETIC_WS",
    reference_time: datetime | None = None,
) -> dict[str, Any]:
    """Seed the UC Volume PT1H.json blob, synthetic_cluster_node_runs, and job_exceptions."""
    dataset = build_synthetic_dataset(
        reference_time=reference_time,
        workspace_id=workspace_id,
    )

    spark_session.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")
    spark_session.sql(f"CREATE VOLUME IF NOT EXISTS {catalog}.{schema}.synthetic_flow_logs")

    pt1h_path = write_synthetic_flow_log_files(dataset, volume_path)

    owners_table = f"{catalog}.{schema}.synthetic_cluster_node_runs"
    spark_session.sql(
        f"""
        CREATE TABLE IF NOT EXISTS {owners_table} (
          {CLUSTER_NODE_RUNS_SPARK_DDL}
        ) USING DELTA
        """
    )

    distinct_starts = sorted(
        {r.observed_start.astimezone(UTC).isoformat() for r in dataset.ownership_rows}
    )
    in_list_sql = ", ".join(f"TIMESTAMP '{ts}'" for ts in distinct_starts)
    spark_session.sql(
        f"DELETE FROM {owners_table} "
        f"WHERE workspace_id = '{workspace_id}' AND observed_start IN ({in_list_sql})"
    )

    owners_df = spark_session.createDataFrame(
        ownership_rows_to_dicts(dataset.ownership_rows),
        schema=CLUSTER_NODE_RUNS_SPARK_DDL,
    )
    owners_df.write.format("delta").mode("append").saveAsTable(owners_table)

    exceptions_table = f"{catalog}.{schema}.job_exceptions"
    spark_session.sql(
        f"""
        CREATE TABLE IF NOT EXISTS {exceptions_table} (
          workspace_id STRING,
          job_id BIGINT,
          job_name STRING,
          reason STRING,
          approved_by STRING,
          effective_from TIMESTAMP,
          effective_to TIMESTAMP
        ) USING DELTA
        """
    )
    exceptions_df = spark_session.createDataFrame(
        exception_rules_to_dicts(dataset.exception_rules),
        schema=JOB_EXCEPTIONS_SPARK_DDL,
    )
    exceptions_df.write.format("delta").mode("overwrite").saveAsTable(exceptions_table)

    return {
        "window_start": dataset.window_start.isoformat(),
        "window_end": dataset.window_end.isoformat(),
        "pt1h_path": str(pt1h_path),
        "ownership_row_count": len(dataset.ownership_rows),
        "exception_rule_count": len(dataset.exception_rules),
    }
