"""Semantic Layer provisioner for job_exceptions and the Unity Catalog Metric View.

Maintains the operator-editable job_exceptions Delta table outside SDP ownership and
creates/updates the governed Unity Catalog Metric View (job_bandwidth_metrics_v) over
job_bandwidth_5m.
"""

from __future__ import annotations

import re
from typing import Any

IDENTIFIER_PATTERN = re.compile(r"^[A-Za-z0-9_]+$")

METRIC_VIEW_DIMENSIONS: tuple[str, ...] = (
    "window_start",
    "window_end",
    "workspace_id",
    "cluster_id",
    "job_id",
    "run_id",
    "job_name",
    "attribution_category",
    "top_remote_peer_ip",
    "is_breach",
)

METRIC_VIEW_MEASURES: tuple[str, ...] = (
    "total_bytes",
    "total_megabytes",
    "total_gigabytes",
    "bytes_received",
    "bytes_sent",
    "private_endpoint_bytes",
    "external_bytes",
    "peak_5m_mbps",
    "avg_window_mbps",
    "breach_window_count",
    "exempt_bytes",
)


def validate_uc_identifier(name: str, field: str) -> str:
    cleaned = name.strip()
    if not IDENTIFIER_PATTERN.match(cleaned):
        raise ValueError(f"Invalid Unity Catalog {field} identifier: {name!r}")
    return cleaned


def build_job_exceptions_ddl(catalog: str, schema: str) -> str:
    """Build the CREATE TABLE IF NOT EXISTS DDL for the external job_exceptions Delta table."""
    cat = validate_uc_identifier(catalog, "catalog")
    sch = validate_uc_identifier(schema, "schema")
    return f"""
CREATE TABLE IF NOT EXISTS {cat}.{sch}.job_exceptions (
  workspace_id STRING COMMENT 'Databricks workspace ID',
  job_id BIGINT COMMENT 'Exempt Lakeflow job ID',
  job_name STRING COMMENT 'Human-readable job name',
  reason STRING COMMENT 'Business justification for bandwidth threshold exemption',
  approved_by STRING COMMENT 'Operator or team approving the exemption',
  effective_from TIMESTAMP COMMENT 'UTC start timestamp of the exemption',
  effective_to TIMESTAMP COMMENT 'Optional UTC expiration timestamp (NULL for open-ended)'
) USING DELTA
COMMENT 'Operator-editable table of approved high-bandwidth jobs exempt from breach alerts.'
""".strip()


def build_metric_view_yaml(catalog: str, schema: str) -> str:
    """Build the YAML specification body for the job_bandwidth_metrics_v UC Metric View."""
    cat = validate_uc_identifier(catalog, "catalog")
    sch = validate_uc_identifier(schema, "schema")
    return f"""
version: 0.1
source: {cat}.{sch}.job_bandwidth_5m
dimensions:
  - name: window_start
    expr: window_start
  - name: window_end
    expr: window_end
  - name: workspace_id
    expr: workspace_id
  - name: cluster_id
    expr: cluster_id
  - name: job_id
    expr: job_id
  - name: run_id
    expr: run_id
  - name: job_name
    expr: COALESCE(job_name, 'Unattributed / Shared')
  - name: attribution_category
    expr: attribution_category
  - name: top_remote_peer_ip
    expr: top_remote_peer_ip
  - name: is_breach
    expr: is_breach
measures:
  - name: total_bytes
    expr: SUM(total_bytes)
  - name: total_megabytes
    expr: SUM(total_bytes) / 1000000.0
  - name: total_gigabytes
    expr: SUM(total_bytes) / 1000000000.0
  - name: bytes_received
    expr: SUM(bytes_received)
  - name: bytes_sent
    expr: SUM(bytes_sent)
  - name: private_endpoint_bytes
    expr: SUM(private_endpoint_bytes)
  - name: external_bytes
    expr: SUM(external_bytes)
  - name: peak_5m_mbps
    expr: MAX(avg_mbps)
  - name: avg_window_mbps
    expr: AVG(avg_mbps)
  - name: breach_window_count
    expr: COUNT_IF(is_breach = true)
  - name: exempt_bytes
    expr: SUM(CASE WHEN attribution_category = 'EXEMPT' THEN total_bytes ELSE 0 END)
""".strip()


def build_metric_view_ddl(catalog: str, schema: str) -> str:
    """Build the CREATE OR REPLACE VIEW ... WITH METRICS LANGUAGE YAML statement."""
    cat = validate_uc_identifier(catalog, "catalog")
    sch = validate_uc_identifier(schema, "schema")
    yaml_body = build_metric_view_yaml(cat, sch)
    return (
        f"CREATE OR REPLACE VIEW {cat}.{sch}.job_bandwidth_metrics_v\n"
        "WITH METRICS\n"
        "LANGUAGE YAML\n"
        "AS $$\n"
        f"{yaml_body}\n"
        "$$"
    )


def publish_semantic_layer(
    spark_session: Any,
    *,
    catalog: str,
    schema: str,
) -> dict[str, str]:
    """Ensure the schema, job_exceptions, and the Metric View exist."""
    cat = validate_uc_identifier(catalog, "catalog")
    sch = validate_uc_identifier(schema, "schema")

    spark_session.sql(f"CREATE SCHEMA IF NOT EXISTS {cat}.{sch}")
    spark_session.sql(build_job_exceptions_ddl(cat, sch))
    spark_session.sql(build_metric_view_ddl(cat, sch))

    return {
        "catalog": cat,
        "schema": sch,
        "exceptions_table": f"{cat}.{sch}.job_exceptions",
        "metric_view": f"{cat}.{sch}.job_bandwidth_metrics_v",
    }
