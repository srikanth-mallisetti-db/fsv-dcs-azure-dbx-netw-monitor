"""Azure VNet Flow Log (Schema v4) parser, CIDR classifier, and 5-minute attribution engine.

Provides both pure-Python domain functions (for fast deterministic unit testing) and
Photon-vectorized Spark SQL expression builders (zero Python UDF overhead in SDP).
"""

from __future__ import annotations

import hashlib
import ipaddress
import re
from collections import defaultdict
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, replace
from datetime import UTC, datetime, timedelta
from typing import Any, Literal

RFC1918_DEFAULT_CIDRS: str = "10.0.0.0/8,172.16.0.0/12,192.168.0.0/16"
WINDOW_SECONDS: int = 300
BITS_PER_BYTE: float = 8.0
BITS_PER_MEGABIT: float = 1_000_000.0
OWNERSHIP_GRACE_MINUTES: int = 5
RESOURCE_ID_PATTERN = re.compile(r"^/subscriptions/[a-z0-9/_.()-]+$")
# A flow's reports at the compute NIC, in flow_events_clean columns
FLOW_KEY_COLUMNS: tuple[str, ...] = (
    "local_node_ip",
    "remote_peer_ip",
    "local_port",
    "remote_port",
    "protocol",
    "flow_direction",
)
# flow_event_deltas reads this much before the lookback so a window's first report can still be
# compared with the report before it
RECREATION_LAG_MARGIN_HOURS: int = 1
FLOW_EVENT_PASSTHROUGH_COLUMNS: tuple[str, ...] = (
    "event_id",
    "event_time",
    *FLOW_KEY_COLUMNS,
    "flow_state",
    "traffic_scope",
    "is_recreated",
    "source_file",
)

TrafficScope = Literal["PRIVATE_ENDPOINT", "EXTERNAL"]
AttributionCategory = Literal["EXEMPT", "MONITORED", "SHARED", "UNATTRIBUTED"]
CidrRange = tuple[int, int]


@dataclass(frozen=True, slots=True)
class CleanFlowEvent:
    """Normalized, non-shuffle Azure VNet Flow Log v4 C/E delta tuple.

    is_recreated marks an E tuple reported in the same millisecond as a B tuple of the same flow:
    Azure re-created the flow, and the flow's next report repeats this tuple's counters.
    """

    event_id: str
    event_time: datetime
    local_node_ip: str
    remote_peer_ip: str
    local_port: int
    remote_port: int
    protocol: int
    flow_direction: str
    flow_state: str
    traffic_scope: TrafficScope
    bytes_sent: int
    bytes_received: int
    source_file: str
    state_priority: int
    file_mod_time: datetime
    is_recreated: bool = False


@dataclass(frozen=True, slots=True)
class NodeOwnershipWindow:
    """Time-bounded mapping of a Databricks classic compute node IP to a cluster and job run."""

    workspace_id: str
    cluster_id: str
    node_ip: str
    run_id: int
    job_id: int | None
    job_name: str | None
    observed_start: datetime
    observed_end: datetime
    node_role: str = "WORKER"
    task_run_id: int | None = None
    source: str = "LIVE_API"


@dataclass(frozen=True, slots=True)
class JobExceptionRule:
    """Admin-approved bandwidth alerting exemption for a specific (workspace_id, job_id)."""

    workspace_id: str
    job_id: int
    job_name: str
    reason: str
    approved_by: str
    effective_from: datetime
    effective_to: datetime | None = None


@dataclass(frozen=True, slots=True)
class JobBandwidthWindow:
    """5-minute tumbling window bandwidth attribution and breach evaluation record."""

    window_start: datetime
    window_end: datetime
    workspace_id: str
    cluster_id: str
    attribution_category: AttributionCategory
    job_id: int | None
    run_id: int | None
    job_name: str | None
    candidate_job_ids: tuple[int, ...]
    bytes_sent: int
    bytes_received: int
    total_bytes: int
    private_endpoint_bytes: int
    external_bytes: int
    avg_mbps: float
    threshold_mbps: float
    top_remote_peer_ip: str
    is_breach: bool


def parse_cidr_ranges(cidrs_csv: str) -> tuple[CidrRange, ...]:
    """Compile comma-separated IPv4 CIDRs into 32-bit unsigned integer (start, end) ranges."""
    ranges: list[CidrRange] = []
    for token in cidrs_csv.split(","):
        cleaned = token.strip()
        if not cleaned:
            continue
        network = ipaddress.ip_network(cleaned, strict=False)
        if not isinstance(network, ipaddress.IPv4Network):
            raise ValueError(f"Only IPv4 CIDRs are supported, got: {cleaned!r}")
        ranges.append((int(network.network_address), int(network.broadcast_address)))
    if not ranges:
        raise ValueError("At least one valid IPv4 CIDR must be provided.")
    return tuple(ranges)


def resolve_private_endpoint_ranges(
    private_endpoint_cidrs: str | None = None,
) -> tuple[CidrRange, ...]:
    """Honor explicit private_endpoint_cidrs if provided; otherwise fall back to RFC 1918."""
    if private_endpoint_cidrs is not None:
        stripped = private_endpoint_cidrs.strip().strip(",")
        if stripped:
            return parse_cidr_ranges(stripped)
    return parse_cidr_ranges(RFC1918_DEFAULT_CIDRS)


def ipv4_to_int(ip_str: str) -> int:
    """Convert a dotted-quad IPv4 address string into an unsigned 32-bit integer."""
    addr = ipaddress.ip_address(ip_str.strip())
    if not isinstance(addr, ipaddress.IPv4Address):
        raise ValueError(f"Expected IPv4 address, got: {ip_str!r}")
    return int(addr)


def ip_in_ranges(ip_str: str, ranges: Sequence[CidrRange]) -> bool:
    """Return True if ip_str is a valid IPv4 address falling within any (start, end) range."""
    try:
        ip_int = ipv4_to_int(ip_str)
    except ValueError:
        return False
    return any(start <= ip_int <= end for start, end in ranges)


def ipv4_to_bigint_sql(col_expr: str) -> str:
    """Build a Photon-vectorized Spark SQL expression converting an IPv4 column to BIGINT."""
    return (
        "("
        f"TRY_CAST(SPLIT_PART({col_expr}, '.', 1) AS BIGINT) * 16777216 + "
        f"TRY_CAST(SPLIT_PART({col_expr}, '.', 2) AS BIGINT) * 65536 + "
        f"TRY_CAST(SPLIT_PART({col_expr}, '.', 3) AS BIGINT) * 256 + "
        f"TRY_CAST(SPLIT_PART({col_expr}, '.', 4) AS BIGINT)"
        ")"
    )


def ip_in_cidr_ranges_sql(col_expr: str, ranges: Sequence[CidrRange]) -> str:
    """Build a Photon-vectorized Spark SQL predicate checking whether col_expr is in ranges."""
    if not ranges:
        return "FALSE"
    ip_int_sql = ipv4_to_bigint_sql(col_expr)
    predicates = [f"({ip_int_sql} BETWEEN {start} AND {end})" for start, end in ranges]
    return "(" + " OR ".join(predicates) + ")"


def normalize_mac_address(mac_address: str) -> str:
    """Normalize MAC addresses by removing colons/hyphens and uppercasing."""
    return mac_address.strip().replace("-", "").replace(":", "").upper()


def normalize_epoch_ms(raw_epoch: int | str) -> int:
    """Normalize 10-digit second or 13-digit millisecond epochs to UTC epoch milliseconds."""
    value = int(str(raw_epoch).strip())
    if value < 0:
        raise ValueError(f"Negative epoch timestamp is invalid: {raw_epoch!r}")
    if value < 100_000_000_000:
        return value * 1000
    return value


def compute_event_id(
    flow_log_guid: str,
    mac_address: str,
    epoch_ms: int,
    src_ip: str,
    dest_ip: str,
    src_port: int,
    dest_port: int,
    protocol: int,
    direction: str,
) -> str:
    """Compute the deterministic Auto CDC primary key (excluding state so E updates C)."""
    canonical = "|".join(
        (
            flow_log_guid.strip(),
            normalize_mac_address(mac_address),
            str(epoch_ms),
            src_ip.strip(),
            dest_ip.strip(),
            str(src_port),
            str(dest_port),
            str(protocol),
            direction.strip().upper(),
        )
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _ensure_utc(ts: datetime) -> datetime:
    if ts.tzinfo is None:
        return ts.replace(tzinfo=UTC)
    return ts.astimezone(UTC)


def _tuple_state(raw_tuple: str) -> str:
    parts = raw_tuple.split(",")
    return parts[7].strip().upper() if len(parts) > 7 else ""


def flow_tuple_key(raw_tuple: str) -> str:
    """Return a raw tuple's timestamp, endpoints, protocol, and direction (its first 7 fields).

    An E tuple whose key matches a B tuple's key in the same flowTuples array is a re-created
    flow (see CleanFlowEvent.is_recreated).
    """
    return ",".join(part.strip().upper() for part in raw_tuple.split(",")[:7])


def flow_tuple_key_sql(tuple_expr: str) -> str:
    """Build the Spark SQL twin of flow_tuple_key for a raw tuple string expression."""
    return f"ARRAY_JOIN(SLICE(TRANSFORM(SPLIT({tuple_expr}, ','), f -> UPPER(TRIM(f))), 1, 7), ',')"


def recreation_keys_sql(tuples_expr: str) -> str:
    """Build the Spark SQL keys of the B tuples in a flowTuples array (stateless, per array)."""
    return (
        f"TRANSFORM(FILTER({tuples_expr}, b -> UPPER(TRIM(SPLIT_PART(b, ',', 8))) = 'B'), "
        f"b -> {flow_tuple_key_sql('b')})"
    )


def is_recreated_tuple_sql(tuple_expr: str, keys_expr: str) -> str:
    """Build the Spark SQL flag for an E tuple that shares its key with a B tuple of its array."""
    return (
        f"(UPPER(TRIM(SPLIT_PART({tuple_expr}, ',', 8))) = 'E' "
        f"AND ARRAY_CONTAINS({keys_expr}, {flow_tuple_key_sql(tuple_expr)}))"
    )


def parse_flow_tuple(
    raw_tuple: str,
    *,
    flow_log_guid: str,
    mac_address: str,
    compute_ranges: Sequence[CidrRange],
    private_endpoint_ranges: Sequence[CidrRange] | None = None,
    source_file: str = "memory://PT1H.json",
    file_mod_time: datetime | None = None,
    recreation_keys: frozenset[str] = frozenset(),
) -> CleanFlowEvent | None:
    """Parse and classify a single 13-field Azure VNet Flow Log (Schema v4) tuple.

    Returns None when the tuple is a Beginning ('B') state record, intra-cluster Spark
    shuffle (both endpoints inside compute_ranges), outside compute_ranges on both sides,
    observed at the non-compute end of the flow (so it is counted once, at the compute
    node's NIC), or malformed. recreation_keys are the flow_tuple_key values of the B tuples
    in the tuple's flowTuples array; an E tuple matching one is marked is_recreated.
    """
    parts = [part.strip() for part in raw_tuple.split(",")]
    if len(parts) < 13:
        return None

    flow_state = parts[7].upper()
    if flow_state not in {"C", "E"}:
        return None

    try:
        epoch_ms = normalize_epoch_ms(parts[0])
        src_ip = parts[1]
        dest_ip = parts[2]
        src_port = int(parts[3])
        dest_port = int(parts[4])
        protocol = int(parts[5])
        flow_direction = parts[6].upper()
        forward_bytes = int(parts[10]) if parts[10] else 0
        reverse_bytes = int(parts[12]) if parts[12] else 0
    except ValueError:
        return None

    if flow_direction not in {"I", "O"}:
        return None
    if forward_bytes < 0 or reverse_bytes < 0:
        return None

    src_in_compute = ip_in_ranges(src_ip, compute_ranges)
    dest_in_compute = ip_in_ranges(dest_ip, compute_ranges)

    # Drop intra-cluster Spark shuffle (Compute Subnet <-> Compute Subnet) and unrelated flows
    if src_in_compute and dest_in_compute:
        return None
    if not src_in_compute and not dest_in_compute:
        return None
    # A flow between two flow-logged NICs is recorded at both of them; count it once, where the
    # compute node's own NIC observed it (outbound from the node or inbound to the node).
    if flow_direction != ("O" if src_in_compute else "I"):
        return None

    if src_in_compute:
        local_node_ip = src_ip
        remote_peer_ip = dest_ip
        local_port = src_port
        remote_port = dest_port
        bytes_sent = forward_bytes
        bytes_received = reverse_bytes
    else:
        local_node_ip = dest_ip
        remote_peer_ip = src_ip
        local_port = dest_port
        remote_port = src_port
        bytes_sent = reverse_bytes
        bytes_received = forward_bytes

    pe_ranges = (
        private_endpoint_ranges
        if private_endpoint_ranges is not None
        else resolve_private_endpoint_ranges(None)
    )
    traffic_scope: TrafficScope = (
        "PRIVATE_ENDPOINT" if ip_in_ranges(remote_peer_ip, pe_ranges) else "EXTERNAL"
    )

    event_time = datetime.fromtimestamp(epoch_ms / 1000.0, tz=UTC)
    resolved_mod_time = _ensure_utc(file_mod_time) if file_mod_time is not None else event_time
    state_priority = 2 if flow_state == "E" else 1

    event_id = compute_event_id(
        flow_log_guid=flow_log_guid,
        mac_address=mac_address,
        epoch_ms=epoch_ms,
        src_ip=src_ip,
        dest_ip=dest_ip,
        src_port=src_port,
        dest_port=dest_port,
        protocol=protocol,
        direction=flow_direction,
    )

    return CleanFlowEvent(
        event_id=event_id,
        event_time=event_time,
        local_node_ip=local_node_ip,
        remote_peer_ip=remote_peer_ip,
        local_port=local_port,
        remote_port=remote_port,
        protocol=protocol,
        flow_direction=flow_direction,
        flow_state=flow_state,
        traffic_scope=traffic_scope,
        bytes_sent=bytes_sent,
        bytes_received=bytes_received,
        source_file=source_file,
        state_priority=state_priority,
        file_mod_time=resolved_mod_time,
        is_recreated=flow_state == "E" and flow_tuple_key(raw_tuple) in recreation_keys,
    )


def extract_flow_events_from_document(
    document: Mapping[str, Any],
    *,
    compute_ranges: Sequence[CidrRange],
    private_endpoint_ranges: Sequence[CidrRange] | None = None,
    source_file: str = "memory://PT1H.json",
    file_mod_time: datetime | None = None,
    target_resource_ids: Sequence[str] = (),
) -> list[CleanFlowEvent]:
    """Extract all valid non-shuffle C/E flow events from a parsed PT1H.json document.

    Records whose flow-log target is not one of target_resource_ids (when any are given) are
    skipped; see matches_target_resource.
    """
    events: list[CleanFlowEvent] = []
    records = document.get("records")
    if not isinstance(records, Sequence):
        return events

    for record in records:
        if not isinstance(record, Mapping):
            continue
        if not matches_target_resource(record.get("targetResourceID"), target_resource_ids):
            continue
        # Azure writes flowLogGUID; flowLogGuid is accepted for older test documents
        flow_log_guid = str(
            record.get("flowLogGUID") or record.get("flowLogGuid") or "unknown-guid"
        )
        mac_address = str(record.get("macAddress") or "000000000000")
        flow_records = record.get("flowRecords")
        if not isinstance(flow_records, Mapping):
            continue
        flows = flow_records.get("flows")
        if not isinstance(flows, Sequence):
            continue
        for flow in flows:
            if not isinstance(flow, Mapping):
                continue
            flow_groups = flow.get("flowGroups")
            if not isinstance(flow_groups, Sequence):
                continue
            for group in flow_groups:
                if not isinstance(group, Mapping):
                    continue
                tuples = group.get("flowTuples")
                if not isinstance(tuples, Sequence):
                    continue
                recreation_keys = frozenset(
                    flow_tuple_key(raw)
                    for raw in tuples
                    if isinstance(raw, str) and _tuple_state(raw) == "B"
                )
                for raw_tuple in tuples:
                    if not isinstance(raw_tuple, str):
                        continue
                    parsed = parse_flow_tuple(
                        raw_tuple,
                        flow_log_guid=flow_log_guid,
                        mac_address=mac_address,
                        compute_ranges=compute_ranges,
                        private_endpoint_ranges=private_endpoint_ranges,
                        source_file=source_file,
                        file_mod_time=file_mod_time,
                        recreation_keys=recreation_keys,
                    )
                    if parsed is not None:
                        events.append(parsed)
    return events


def deduplicate_flow_events_scd1(events: Iterable[CleanFlowEvent]) -> list[CleanFlowEvent]:
    """Deduplicate flow events by event_id using Auto CDC SCD Type 1 sequencing semantics.

    Retains the record with the highest (event_time, state_priority, file_mod_time).
    """
    by_id: dict[str, CleanFlowEvent] = {}
    for event in events:
        existing = by_id.get(event.event_id)
        if existing is None:
            by_id[event.event_id] = event
            continue
        candidate_seq = (
            _ensure_utc(event.event_time),
            event.state_priority,
            _ensure_utc(event.file_mod_time),
        )
        existing_seq = (
            _ensure_utc(existing.event_time),
            existing.state_priority,
            _ensure_utc(existing.file_mod_time),
        )
        if candidate_seq >= existing_seq:
            by_id[event.event_id] = event
    return sorted(by_id.values(), key=lambda e: (_ensure_utc(e.event_time), e.event_id))


def _flow_key(event: CleanFlowEvent) -> tuple[str, str, int, int, int, str]:
    return (
        event.local_node_ip,
        event.remote_peer_ip,
        event.local_port,
        event.remote_port,
        event.protocol,
        event.flow_direction,
    )


def correct_recreated_flow_counters(events: Iterable[CleanFlowEvent]) -> list[CleanFlowEvent]:
    """Remove the counters a re-created flow's next report repeats (twin of flow_event_deltas).

    Each flow's reports at the compute NIC are ordered by (event_time, event_id). A report that
    follows a re-created E (is_recreated) repeats that E's counters, so it keeps only what it
    adds, provided both of its counters are at least the E's; otherwise it is left unchanged.
    Every other report is a true delta. The previous report's raw counters are subtracted, so
    chained re-creations stay correct.
    """
    ordered = sorted(events, key=lambda e: (_flow_key(e), _ensure_utc(e.event_time), e.event_id))
    corrected: list[CleanFlowEvent] = []
    previous: CleanFlowEvent | None = None
    for event in ordered:
        if (
            previous is not None
            and previous.is_recreated
            and _flow_key(previous) == _flow_key(event)
            and event.bytes_sent >= previous.bytes_sent
            and event.bytes_received >= previous.bytes_received
        ):
            corrected.append(
                replace(
                    event,
                    bytes_sent=event.bytes_sent - previous.bytes_sent,
                    bytes_received=event.bytes_received - previous.bytes_received,
                )
            )
        else:
            corrected.append(event)
        previous = event
    return sorted(corrected, key=lambda e: (_ensure_utc(e.event_time), e.event_id))


def floor_to_5m_window(ts: datetime) -> tuple[datetime, datetime]:
    """Floor a timestamp to its 5-minute UTC tumbling window [window_start, window_end)."""
    utc_ts = _ensure_utc(ts)
    floored_minute = (utc_ts.minute // 5) * 5
    window_start = utc_ts.replace(minute=floored_minute, second=0, microsecond=0)
    window_end = window_start + timedelta(minutes=5)
    return window_start, window_end


def calculate_avg_mbps(total_bytes: int, window_seconds: int = WINDOW_SECONDS) -> float:
    """Calculate average decimal megabits per second (Mbps) over a window."""
    if window_seconds <= 0:
        raise ValueError("window_seconds must be positive")
    return (float(total_bytes) * BITS_PER_BYTE) / (float(window_seconds) * BITS_PER_MEGABIT)


def _is_job_exempt(
    workspace_id: str,
    job_id: int,
    window_start: datetime,
    window_end: datetime,
    exceptions: Sequence[JobExceptionRule],
) -> bool:
    win_start = _ensure_utc(window_start)
    win_end = _ensure_utc(window_end)
    for rule in exceptions:
        if rule.workspace_id != workspace_id or rule.job_id != job_id:
            continue
        eff_from = _ensure_utc(rule.effective_from)
        eff_to = _ensure_utc(rule.effective_to) if rule.effective_to is not None else None
        if eff_from <= win_start and (eff_to is None or eff_to >= win_end):
            return True
    return False


def resolve_ownership_windows(
    rows: Iterable[NodeOwnershipWindow],
    *,
    grace_minutes: int = OWNERSHIP_GRACE_MINUTES,
) -> list[NodeOwnershipWindow]:
    """Collapse node sightings into tenure and run windows that never overlap across IP reuse.

    Pure-Python reference model of ownership.resolve_cluster_node_runs_df. Owners of an IP are
    ordered by their first sighting. Each (cluster, node IP) tenure and each run on it spans its
    earliest sighting start to its last sighting plus grace_minutes. A tenure never starts before
    the previous owner's last sighting, so a node's boot allowance cannot claim it, and its
    grace never extends into the next cluster's tenure on the same IP (Azure hands a freed IP to
    the next VM in the subnet). A run's grace never extends into a later run on the same node
    that started after the run was last seen. Emits one cluster-level row (job_id None) per
    tenure plus one row per run.
    """
    grace = timedelta(minutes=max(0, grace_minutes))
    tenure_members: dict[tuple[str, str, str], list[NodeOwnershipWindow]] = defaultdict(list)
    run_members: dict[tuple[str, str, str, int, int], list[NodeOwnershipWindow]] = defaultdict(list)
    for row in rows:
        node_key = (row.workspace_id, row.cluster_id, row.node_ip)
        tenure_members[node_key].append(row)
        if row.job_id is not None:
            run_members[(*node_key, row.run_id, row.job_id)].append(row)

    # Tenures sharing an IP, in the order their owners were first sighted: each starts no earlier
    # than the previous owner's last sighting, and its grace ends where the next one begins.
    tenures_by_ip: dict[tuple[str, str], list[tuple[datetime, str, datetime, datetime]]] = (
        defaultdict(list)
    )
    for (workspace_id, cluster_id, node_ip), members in tenure_members.items():
        tenures_by_ip[(workspace_id, node_ip)].append(
            (
                min(_ensure_utc(m.observed_end) for m in members),
                cluster_id,
                min(_ensure_utc(m.observed_start) for m in members),
                max(_ensure_utc(m.observed_end) for m in members),
            )
        )
    tenure_bounds: dict[tuple[str, str, str], tuple[datetime, datetime]] = {}
    for (workspace_id, node_ip), tenures in tenures_by_ip.items():
        tenures.sort(key=lambda tenure: (tenure[0], tenure[1]))
        starts: list[datetime] = []
        for idx, (first_seen, _, earliest_start, _) in enumerate(tenures):
            start = earliest_start if idx == 0 else max(earliest_start, tenures[idx - 1][3])
            starts.append(min(start, first_seen))
        for idx, (_, cluster_id, _, last_seen) in enumerate(tenures):
            end = last_seen + grace
            if idx + 1 < len(tenures):
                end = min(end, max(last_seen, starts[idx + 1]))
            tenure_bounds[(workspace_id, cluster_id, node_ip)] = (starts[idx], end)

    runs_by_node: dict[tuple[str, str, str], list[tuple[datetime, int, int, datetime]]] = (
        defaultdict(list)
    )
    for (workspace_id, cluster_id, node_ip, run_id, job_id), members in run_members.items():
        runs_by_node[(workspace_id, cluster_id, node_ip)].append(
            (
                min(_ensure_utc(m.observed_start) for m in members),
                run_id,
                job_id,
                max(_ensure_utc(m.observed_end) for m in members),
            )
        )

    resolved: list[NodeOwnershipWindow] = []
    for node_key, members in tenure_members.items():
        workspace_id, cluster_id, node_ip = node_key
        tenure_start, tenure_end = tenure_bounds[node_key]
        node_role = max(m.node_role for m in members)
        source = max(m.source for m in members)
        cluster_names = [m.job_name for m in members if m.job_id is None and m.job_name is not None]
        resolved.append(
            NodeOwnershipWindow(
                workspace_id=workspace_id,
                cluster_id=cluster_id,
                node_ip=node_ip,
                run_id=0,
                job_id=None,
                job_name=max(cluster_names) if cluster_names else f"cluster-{cluster_id}",
                observed_start=tenure_start,
                observed_end=tenure_end,
                node_role=node_role,
                task_run_id=None,
                source=source,
            )
        )

        runs = sorted(runs_by_node.get(node_key, []), key=lambda run: (run[0], run[1]))
        for idx, (run_start, run_id, job_id, last_seen) in enumerate(runs):
            run_end = min(last_seen + grace, tenure_end)
            if idx + 1 < len(runs) and runs[idx + 1][0] > last_seen:
                run_end = min(run_end, runs[idx + 1][0])
            run_rows = run_members[(*node_key, run_id, job_id)]
            task_run_ids = [m.task_run_id for m in run_rows if m.task_run_id is not None]
            run_names = [m.job_name for m in run_rows if m.job_name is not None]
            resolved.append(
                NodeOwnershipWindow(
                    workspace_id=workspace_id,
                    cluster_id=cluster_id,
                    node_ip=node_ip,
                    run_id=run_id,
                    job_id=job_id,
                    job_name=max(run_names) if run_names else None,
                    observed_start=max(run_start, tenure_start),
                    observed_end=run_end,
                    node_role=node_role,
                    task_run_id=max(task_run_ids) if task_run_ids else None,
                    source=source,
                )
            )

    return sorted(
        resolved,
        key=lambda w: (w.workspace_id, w.node_ip, w.observed_start, w.cluster_id, w.run_id),
    )


def attribute_window_records(
    events: Sequence[CleanFlowEvent],
    ownership_rows: Sequence[NodeOwnershipWindow],
    exceptions: Sequence[JobExceptionRule] = (),
    *,
    threshold_mbps: float = 100.0,
    default_workspace_id: str = "UNATTRIBUTED",
) -> list[JobBandwidthWindow]:
    """Aggregate deduplicated flow events into 5-minute windows and attribute to jobs/clusters.

    Guarantees each deduplicated CleanFlowEvent's byte counters are counted once per
    matched cluster even when multiple concurrent job runs overlap on a shared cluster.
    """
    deduped_events = deduplicate_flow_events_scd1(events)

    # Group Key: (window_start, window_end, workspace_id, cluster_id)
    group_events: dict[tuple[datetime, datetime, str, str], list[CleanFlowEvent]] = defaultdict(
        list
    )
    group_matches: dict[tuple[datetime, datetime, str, str], list[NodeOwnershipWindow]] = (
        defaultdict(list)
    )

    for event in deduped_events:
        ev_time = _ensure_utc(event.event_time)
        win_start, win_end = floor_to_5m_window(ev_time)
        matching_owners = [
            row
            for row in ownership_rows
            if row.node_ip == event.local_node_ip
            and _ensure_utc(row.observed_start) <= ev_time <= _ensure_utc(row.observed_end)
        ]

        if not matching_owners:
            key = (win_start, win_end, default_workspace_id, "UNATTRIBUTED")
            group_events[key].append(event)
            continue

        # Group matching ownership rows by (workspace_id, cluster_id) so an event on a
        # shared cluster with N concurrent jobs is only added once to that cluster's bucket.
        by_cluster: dict[tuple[str, str], list[NodeOwnershipWindow]] = defaultdict(list)
        for row in matching_owners:
            by_cluster[(row.workspace_id, row.cluster_id)].append(row)

        for (workspace_id, cluster_id), cluster_rows in by_cluster.items():
            key = (win_start, win_end, workspace_id, cluster_id)
            group_events[key].append(event)
            group_matches[key].extend(cluster_rows)

    results: list[JobBandwidthWindow] = []
    for key in sorted(group_events.keys()):
        win_start, win_end, workspace_id, cluster_id = key
        bucket_events = group_events[key]
        bucket_owners = group_matches.get(key, [])

        bytes_sent = sum(e.bytes_sent for e in bucket_events)
        bytes_received = sum(e.bytes_received for e in bucket_events)
        total_bytes = bytes_sent + bytes_received
        pe_bytes = sum(
            e.bytes_sent + e.bytes_received
            for e in bucket_events
            if e.traffic_scope == "PRIVATE_ENDPOINT"
        )
        ext_bytes = sum(
            e.bytes_sent + e.bytes_received for e in bucket_events if e.traffic_scope == "EXTERNAL"
        )

        peer_totals: dict[str, int] = defaultdict(int)
        for e in bucket_events:
            peer_totals[e.remote_peer_ip] += e.bytes_sent + e.bytes_received
        top_remote_peer_ip = min(
            peer_totals.keys(),
            key=lambda ip: (-peer_totals[ip], ip),
        )

        distinct_jobs: dict[int, tuple[int, str | None]] = {}
        for row in bucket_owners:
            if row.job_id is not None and row.job_id not in distinct_jobs:
                distinct_jobs[row.job_id] = (row.run_id, row.job_name)

        candidate_job_ids = tuple(sorted(distinct_jobs.keys()))
        avg_mbps = calculate_avg_mbps(total_bytes)

        if cluster_id == "UNATTRIBUTED" or len(candidate_job_ids) == 0:
            attribution_category: AttributionCategory = "UNATTRIBUTED"
            job_id: int | None = None
            run_id: int | None = None
            job_name: str | None = (
                bucket_owners[0].job_name if bucket_owners and bucket_owners[0].job_name else None
            )
        elif len(candidate_job_ids) == 1:
            job_id = candidate_job_ids[0]
            run_id, job_name = distinct_jobs[job_id]
            if _is_job_exempt(workspace_id, job_id, win_start, win_end, exceptions):
                attribution_category = "EXEMPT"
            else:
                attribution_category = "MONITORED"
        else:
            attribution_category = "SHARED"
            job_id = None
            run_id = None
            joined_ids = ",".join(str(jid) for jid in candidate_job_ids)
            job_name = f"SHARED ({joined_ids})"

        is_breach = (attribution_category != "EXEMPT") and (avg_mbps > threshold_mbps)

        results.append(
            JobBandwidthWindow(
                window_start=win_start,
                window_end=win_end,
                workspace_id=workspace_id,
                cluster_id=cluster_id,
                attribution_category=attribution_category,
                job_id=job_id,
                run_id=run_id,
                job_name=job_name,
                candidate_job_ids=candidate_job_ids,
                bytes_sent=bytes_sent,
                bytes_received=bytes_received,
                total_bytes=total_bytes,
                private_endpoint_bytes=pe_bytes,
                external_bytes=ext_bytes,
                avg_mbps=avg_mbps,
                threshold_mbps=threshold_mbps,
                top_remote_peer_ip=top_remote_peer_ip,
                is_breach=is_breach,
            )
        )

    return results


def parse_target_resource_ids(ids_csv: str | None) -> tuple[str, ...]:
    """Parse comma-separated Azure resource IDs of flow-log targets to count.

    IDs are normalized to lowercase without a trailing slash, because Azure resource IDs are
    case-insensitive and the case in flow-log records need not match the configured one.
    Anything that is not shaped like an Azure resource ID is rejected, so the IDs can be
    embedded in Spark SQL safely.
    """
    target_ids: list[str] = []
    for token in (ids_csv or "").split(","):
        cleaned = token.strip().rstrip("/").lower()
        if not cleaned:
            continue
        if not RESOURCE_ID_PATTERN.match(cleaned):
            raise ValueError(f"Invalid Azure resource ID for a flow-log target: {token.strip()!r}")
        if cleaned not in target_ids:
            target_ids.append(cleaned)
    return tuple(target_ids)


def matches_target_resource(target_resource_id: Any, target_ids: Sequence[str]) -> bool:
    """Return True if the record's flow-log target should be counted.

    Every target counts when none are configured; otherwise the target must be a configured
    resource or a child of one (such as a subnet of a configured VNet).
    """
    if not target_ids:
        return True
    resource = str(target_resource_id or "").strip().rstrip("/").lower()
    return any(resource == tid or resource.startswith(f"{tid}/") for tid in target_ids)


def target_resource_filter_sql(column: str, target_ids: Sequence[str]) -> str:
    """Build the Spark SQL twin of matches_target_resource for a targetResourceID column."""
    if not target_ids:
        return "TRUE"
    value = f"LOWER(TRIM(TRAILING '/' FROM TRIM({column})))"
    predicates = [f"({value} = '{tid}' OR STARTSWITH({value}, '{tid}/'))" for tid in target_ids]
    return "(" + " OR ".join(predicates) + ")"


def parse_flow_log_start_after(value: str | None) -> str | None:
    """Parse the optional flow-log start time into Auto Loader's modifiedAfter format.

    Accepts an ISO 8601 date or date-time; a value without a UTC offset is taken as UTC.
    Returns None when empty, so every flow-log file is read.
    """
    cleaned = (value or "").strip()
    if not cleaned:
        return None
    try:
        start_after = _ensure_utc(datetime.fromisoformat(cleaned))
    except ValueError as exc:
        raise ValueError(
            f"Invalid flow-log start time {cleaned!r}: use an ISO 8601 date or date-time, "
            "for example 2026-11-01 or 2026-11-01T00:00:00Z."
        ) from exc
    return start_after.strftime("%Y-%m-%d %H:%M:%S.%f UTC+0")


def lookback_cutoff_sql(lookback_hours: int) -> str:
    """Build the Spark SQL start of the rolling lookback window, aligned to the clock hour.

    Hour alignment keeps the oldest 5-minute window in the lookback complete rather than
    truncated mid-window.
    """
    hours = max(1, int(lookback_hours))
    return f"date_trunc('HOUR', current_timestamp()) - INTERVAL {hours} HOURS"


def sql_expr(expr_str: str) -> Any:
    """Return pyspark.sql.functions.expr(expr_str) in Spark, or raw SQL string in unit tests."""
    try:
        from pyspark.sql import functions as F  # type: ignore[import-not-found]

        return F.expr(expr_str)
    except Exception:
        return expr_str


def build_raw_flow_tuples_sql_projections(
    compute_subnet_cidrs: str,
    private_endpoint_cidrs: str | None = None,
) -> dict[str, str]:
    """Build Photon-vectorized Spark SQL predicates for VNet Flow Log v4 classification."""
    compute_ranges = parse_cidr_ranges(compute_subnet_cidrs)
    pe_ranges = resolve_private_endpoint_ranges(private_endpoint_cidrs)

    src_in_compute = ip_in_cidr_ranges_sql("src_ip", compute_ranges)
    dest_in_compute = ip_in_cidr_ranges_sql("dest_ip", compute_ranges)
    remote_in_pe = ip_in_cidr_ranges_sql("remote_peer_ip", pe_ranges)

    return {
        "src_in_compute_sql": src_in_compute,
        "dest_in_compute_sql": dest_in_compute,
        "non_shuffle_filter_sql": (
            "flow_state IN ('C', 'E') "
            "AND flow_direction IN ('I', 'O') "
            "AND forward_bytes >= 0 AND reverse_bytes >= 0 "
            "AND ((src_in_compute AND NOT dest_in_compute AND flow_direction = 'O') "
            "OR (dest_in_compute AND NOT src_in_compute AND flow_direction = 'I'))"
        ),
        "traffic_scope_sql": (
            f"CASE WHEN {remote_in_pe} THEN 'PRIVATE_ENDPOINT' ELSE 'EXTERNAL' END"
        ),
    }


def recreation_lag_sql_exprs() -> tuple[str, ...]:
    """Build the previous-report columns the re-creation correction compares each report with."""
    window = f"OVER (PARTITION BY {', '.join(FLOW_KEY_COLUMNS)} ORDER BY event_time, event_id)"
    return (
        f"LAG(is_recreated) {window} AS prev_is_recreated",
        f"LAG(bytes_sent) {window} AS prev_bytes_sent",
        f"LAG(bytes_received) {window} AS prev_bytes_received",
    )


def corrected_counter_sql(counter: Literal["bytes_sent", "bytes_received"]) -> str:
    """Build the Spark SQL twin of correct_recreated_flow_counters for one byte counter."""
    return (
        "CASE WHEN COALESCE(prev_is_recreated, FALSE) "
        "AND bytes_sent >= prev_bytes_sent AND bytes_received >= prev_bytes_received "
        f"THEN {counter} - prev_{counter} ELSE {counter} END"
    )


def build_flow_event_deltas_sql(flow_events_view: str, *, lookback_hours: int) -> str:
    """Build the Spark SQL query for the flow_event_deltas Materialized View.

    It covers the rolling lookback window, reading RECREATION_LAG_MARGIN_HOURS more so the
    report before a window's first one is visible, and carries the corrected byte counters
    (raw ones as raw_bytes_sent and raw_bytes_received).
    """
    hours = max(1, int(lookback_hours))
    lags = ",\n    ".join(recreation_lag_sql_exprs())
    columns = ",\n  ".join(FLOW_EVENT_PASSTHROUGH_COLUMNS)
    return f"""
WITH ordered AS (
  SELECT
    *,
    {lags}
  FROM {flow_events_view}
  WHERE event_time >= {lookback_cutoff_sql(hours + RECREATION_LAG_MARGIN_HOURS)}
),
corrected AS (
  SELECT
    *,
    {corrected_counter_sql("bytes_sent")} AS corrected_bytes_sent,
    {corrected_counter_sql("bytes_received")} AS corrected_bytes_received
  FROM ordered
)
SELECT
  {columns},
  bytes_sent AS raw_bytes_sent,
  bytes_received AS raw_bytes_received,
  corrected_bytes_sent AS bytes_sent,
  corrected_bytes_received AS bytes_received
FROM corrected
WHERE event_time >= {lookback_cutoff_sql(hours)}
""".strip()


def build_job_bandwidth_5m_sql(
    *,
    flow_events_view: str,
    cluster_runs_view: str,
    exceptions_view: str,
    threshold_mbps: float,
) -> str:
    """Build the Spark SQL query for the job_bandwidth_5m Gold Materialized View.

    flow_events_view is flow_event_deltas, whose byte counters are corrected for re-created
    flows.
    """
    threshold_literal = float(threshold_mbps)
    return f"""
WITH event_windows AS (
  SELECT
    e.event_id,
    e.event_time,
    window(e.event_time, '5 minutes').start AS window_start,
    window(e.event_time, '5 minutes').end AS window_end,
    e.local_node_ip,
    e.remote_peer_ip,
    e.traffic_scope,
    CAST(e.bytes_sent AS BIGINT) AS bytes_sent,
    CAST(e.bytes_received AS BIGINT) AS bytes_received,
    CAST(e.bytes_sent + e.bytes_received AS BIGINT) AS event_total_bytes
  FROM {flow_events_view} e
),
matched_events AS (
  SELECT
    ew.event_id,
    ew.window_start,
    ew.window_end,
    COALESCE(c.workspace_id, 'UNATTRIBUTED') AS workspace_id,
    COALESCE(c.cluster_id, 'UNATTRIBUTED') AS cluster_id,
    MAX(ew.remote_peer_ip) AS remote_peer_ip,
    MAX(ew.traffic_scope) AS traffic_scope,
    MAX(ew.bytes_sent) AS bytes_sent,
    MAX(ew.bytes_received) AS bytes_received,
    MAX(ew.event_total_bytes) AS event_total_bytes,
    ARRAY_SORT(COLLECT_SET(c.job_id)) AS event_job_ids,
    MAX_BY(c.run_id, COALESCE(c.job_id, -1)) AS sample_run_id,
    MAX_BY(c.job_name, COALESCE(c.job_id, -1)) AS sample_job_name
  FROM event_windows ew
  LEFT JOIN {cluster_runs_view} c
    ON ew.local_node_ip = c.node_ip
   AND ew.event_time BETWEEN c.observed_start AND c.observed_end
  GROUP BY
    ew.event_id,
    ew.window_start,
    ew.window_end,
    COALESCE(c.workspace_id, 'UNATTRIBUTED'),
    COALESCE(c.cluster_id, 'UNATTRIBUTED')
),
peer_ranks AS (
  SELECT
    window_start,
    window_end,
    workspace_id,
    cluster_id,
    remote_peer_ip,
    SUM(event_total_bytes) AS peer_bytes
  FROM matched_events
  GROUP BY window_start, window_end, workspace_id, cluster_id, remote_peer_ip
),
top_peers AS (
  SELECT
    window_start,
    window_end,
    workspace_id,
    cluster_id,
    MAX_BY(remote_peer_ip, (peer_bytes, remote_peer_ip)) AS top_remote_peer_ip
  FROM peer_ranks
  GROUP BY window_start, window_end, workspace_id, cluster_id
),
cluster_window_agg AS (
  SELECT
    m.window_start,
    m.window_end,
    m.workspace_id,
    m.cluster_id,
    ARRAY_SORT(ARRAY_COMPACT(FLATTEN(COLLECT_SET(m.event_job_ids)))) AS candidate_job_ids,
    MAX(m.sample_run_id) AS single_run_id,
    MAX(m.sample_job_name) AS single_job_name,
    CAST(SUM(m.bytes_sent) AS BIGINT) AS bytes_sent,
    CAST(SUM(m.bytes_received) AS BIGINT) AS bytes_received,
    CAST(SUM(m.event_total_bytes) AS BIGINT) AS total_bytes,
    CAST(
      SUM(CASE WHEN m.traffic_scope = 'PRIVATE_ENDPOINT' THEN m.event_total_bytes ELSE 0 END)
      AS BIGINT
    ) AS private_endpoint_bytes,
    CAST(
      SUM(CASE WHEN m.traffic_scope = 'EXTERNAL' THEN m.event_total_bytes ELSE 0 END)
      AS BIGINT
    ) AS external_bytes
  FROM matched_events m
  GROUP BY m.window_start, m.window_end, m.workspace_id, m.cluster_id
),
active_exemptions AS (
  SELECT DISTINCT
    cwa.window_start,
    cwa.window_end,
    cwa.workspace_id,
    ex.job_id
  FROM cluster_window_agg cwa
  INNER JOIN {exceptions_view} ex
    ON cwa.workspace_id = ex.workspace_id
   AND SIZE(cwa.candidate_job_ids) = 1
   AND ELEMENT_AT(cwa.candidate_job_ids, 1) = ex.job_id
   AND ex.effective_from <= cwa.window_start
   AND (ex.effective_to IS NULL OR ex.effective_to >= cwa.window_end)
)
SELECT
  cwa.window_start,
  cwa.window_end,
  cwa.workspace_id,
  cwa.cluster_id,
  CASE
    WHEN cwa.cluster_id = 'UNATTRIBUTED' OR SIZE(cwa.candidate_job_ids) = 0 THEN 'UNATTRIBUTED'
    WHEN SIZE(cwa.candidate_job_ids) > 1 THEN 'SHARED'
    WHEN ae.job_id IS NOT NULL THEN 'EXEMPT'
    ELSE 'MONITORED'
  END AS attribution_category,
  CASE
    WHEN SIZE(cwa.candidate_job_ids) = 1 THEN ELEMENT_AT(cwa.candidate_job_ids, 1)
    ELSE CAST(NULL AS BIGINT)
  END AS job_id,
  CASE
    WHEN SIZE(cwa.candidate_job_ids) = 1 THEN cwa.single_run_id
    ELSE CAST(NULL AS BIGINT)
  END AS run_id,
  CASE
    WHEN cwa.cluster_id = 'UNATTRIBUTED' OR SIZE(cwa.candidate_job_ids) = 0 THEN cwa.single_job_name
    WHEN SIZE(cwa.candidate_job_ids) = 1 THEN cwa.single_job_name
    ELSE CONCAT(
      'SHARED (',
      ARRAY_JOIN(TRANSFORM(cwa.candidate_job_ids, x -> CAST(x AS STRING)), ','),
      ')'
    )
  END AS job_name,
  cwa.candidate_job_ids,
  cwa.bytes_sent,
  cwa.bytes_received,
  cwa.total_bytes,
  cwa.private_endpoint_bytes,
  cwa.external_bytes,
  CAST((cwa.total_bytes * 8.0) / (300.0 * 1000000.0) AS DOUBLE) AS avg_mbps,
  CAST({threshold_literal} AS DOUBLE) AS threshold_mbps,
  tp.top_remote_peer_ip,
  CASE
    WHEN (
      CASE
        WHEN cwa.cluster_id = 'UNATTRIBUTED' OR SIZE(cwa.candidate_job_ids) = 0 THEN 'UNATTRIBUTED'
        WHEN SIZE(cwa.candidate_job_ids) > 1 THEN 'SHARED'
        WHEN ae.job_id IS NOT NULL THEN 'EXEMPT'
        ELSE 'MONITORED'
      END
    ) != 'EXEMPT'
    AND ((cwa.total_bytes * 8.0) / (300.0 * 1000000.0)) > {threshold_literal}
    THEN TRUE
    ELSE FALSE
  END AS is_breach
FROM cluster_window_agg cwa
LEFT JOIN top_peers tp
  ON cwa.window_start = tp.window_start
 AND cwa.window_end = tp.window_end
 AND cwa.workspace_id = tp.workspace_id
 AND cwa.cluster_id = tp.cluster_id
LEFT JOIN active_exemptions ae
  ON cwa.window_start = ae.window_start
 AND cwa.window_end = ae.window_end
 AND cwa.workspace_id = ae.workspace_id
 AND ELEMENT_AT(cwa.candidate_job_ids, 1) = ae.job_id
""".strip()
