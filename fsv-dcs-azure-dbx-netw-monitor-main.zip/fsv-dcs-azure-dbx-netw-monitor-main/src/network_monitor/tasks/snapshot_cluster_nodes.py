"""Task 1 entrypoint: prepares monitor tables, applies retention, and snapshots live nodes."""

from __future__ import annotations

import argparse
import inspect
import json
import sys
from pathlib import Path
from typing import Any


def _ensure_package_importable() -> None:
    """Ensure src/ is on sys.path when executed directly by spark_python_task."""
    candidates: list[Path] = []
    frame = inspect.currentframe()
    raw_paths = [
        globals().get("__file__"),
        globals().get("filename"),
        frame.f_code.co_filename if frame is not None else None,
        sys.argv[0] if sys.argv else None,
    ]
    for raw in raw_paths:
        if isinstance(raw, str) and raw and not raw.startswith("<"):
            resolved = Path(raw).resolve()
            candidates.extend([resolved.parents[2], resolved.parents[1], resolved.parent])
    cwd = Path.cwd().resolve()
    candidates.extend([cwd / "src", cwd.parent / "src", cwd])
    for candidate in candidates:
        if (candidate / "network_monitor").is_dir():
            cand_str = str(candidate)
            if cand_str not in sys.path:
                sys.path.insert(0, cand_str)
            return


_ensure_package_importable()

from network_monitor.node_snapshots import (  # noqa: E402
    DEFAULT_RETENTION_DAYS,
    snapshot_cluster_nodes,
)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Prepare monitor tables, apply retention, and snapshot live cluster nodes."
    )
    parser.add_argument("--catalog", required=True, help="Target Unity Catalog name.")
    parser.add_argument("--schema", required=True, help="Target Unity Catalog schema name.")
    parser.add_argument(
        "--is-int-test",
        default="false",
        help="When true, skip live API polling (int-test attributes synthetic ownership rows).",
    )
    parser.add_argument(
        "--lookback-hours",
        type=int,
        default=24,
        help="Rolling window the pipeline re-attributes; sightings are kept one day longer.",
    )
    parser.add_argument(
        "--retention-days",
        type=int,
        default=DEFAULT_RETENTION_DAYS,
        help="Days of flow events kept in flow_events_clean.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None, *, spark_session: Any = None) -> dict[str, Any]:
    args = parse_args(argv)
    if spark_session is None:
        from pyspark.sql import SparkSession  # type: ignore[import-not-found]

        spark_session = SparkSession.builder.getOrCreate()

    summary = snapshot_cluster_nodes(
        spark_session,
        catalog=args.catalog,
        schema=args.schema,
        is_int_test=args.is_int_test.strip().lower() in {"true", "1", "yes"},
        lookback_hours=args.lookback_hours,
        retention_days=args.retention_days,
    )
    print(json.dumps(summary, sort_keys=True))
    return summary


if __name__ == "__main__":
    main()
