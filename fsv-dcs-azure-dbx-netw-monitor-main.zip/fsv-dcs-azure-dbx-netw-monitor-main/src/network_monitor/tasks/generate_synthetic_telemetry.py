"""Task 0 entrypoint for int-test: generates synthetic VNet Flow Logs and staging tables."""

from __future__ import annotations

import argparse
import inspect
import json
import sys
from pathlib import Path
from typing import Any


def _ensure_package_importable() -> None:
    """Ensure src/ is on sys.path when executed directly by spark_python_task."""
    candidates: list[Path] = []
    frame = inspect.currentframe()
    raw_paths = [
        globals().get("__file__"),
        globals().get("filename"),
        frame.f_code.co_filename if frame is not None else None,
        sys.argv[0] if sys.argv else None,
    ]
    for raw in raw_paths:
        if isinstance(raw, str) and raw and not raw.startswith("<"):
            resolved = Path(raw).resolve()
            candidates.extend([resolved.parents[2], resolved.parents[1], resolved.parent])
    cwd = Path.cwd().resolve()
    candidates.extend([cwd / "src", cwd.parent / "src", cwd])
    for candidate in candidates:
        if (candidate / "network_monitor").is_dir():
            cand_str = str(candidate)
            if cand_str not in sys.path:
                sys.path.insert(0, cand_str)
            return


_ensure_package_importable()

from network_monitor.synthetic import seed_synthetic_environment  # noqa: E402


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate synthetic VNet Flow Log v4 PT1H.json and staging tables."
    )
    parser.add_argument("--catalog", required=True, help="Target Unity Catalog name.")
    parser.add_argument("--schema", required=True, help="Target Unity Catalog schema name.")
    parser.add_argument(
        "--volume-path",
        required=True,
        help="Managed UC Volume path where synthetic PT1H.json files are written.",
    )
    parser.add_argument(
        "--workspace-id",
        default="SYNTHETIC_WS",
        help="Synthetic workspace_id used for staging rows.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None, *, spark_session: Any = None) -> dict[str, Any]:
    args = parse_args(argv)
    if spark_session is None:
        from pyspark.sql import SparkSession  # type: ignore[import-not-found]

        spark_session = SparkSession.builder.getOrCreate()

    summary = seed_synthetic_environment(
        spark_session,
        catalog=args.catalog,
        schema=args.schema,
        volume_path=args.volume_path,
        workspace_id=args.workspace_id,
    )
    print(json.dumps(summary, sort_keys=True))
    return summary


if __name__ == "__main__":
    main()
