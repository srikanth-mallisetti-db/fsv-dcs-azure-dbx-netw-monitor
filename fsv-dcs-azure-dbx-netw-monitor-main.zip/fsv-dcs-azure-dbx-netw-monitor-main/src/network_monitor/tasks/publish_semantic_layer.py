"""Task 2 entrypoint: provisions job_exceptions and the job_bandwidth_metrics_v UC Metric View."""

from __future__ import annotations

import argparse
import inspect
import json
import sys
from pathlib import Path
from typing import Any


def _ensure_package_importable() -> None:
    """Ensure src/ is on sys.path when executed directly by spark_python_task."""
    candidates: list[Path] = []
    frame = inspect.currentframe()
    raw_paths = [
        globals().get("__file__"),
        globals().get("filename"),
        frame.f_code.co_filename if frame is not None else None,
        sys.argv[0] if sys.argv else None,
    ]
    for raw in raw_paths:
        if isinstance(raw, str) and raw and not raw.startswith("<"):
            resolved = Path(raw).resolve()
            candidates.extend([resolved.parents[2], resolved.parents[1], resolved.parent])
    cwd = Path.cwd().resolve()
    candidates.extend([cwd / "src", cwd.parent / "src", cwd])
    for candidate in candidates:
        if (candidate / "network_monitor").is_dir():
            cand_str = str(candidate)
            if cand_str not in sys.path:
                sys.path.insert(0, cand_str)
            return


_ensure_package_importable()

from network_monitor.semantic_layer import publish_semantic_layer  # noqa: E402


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Provision job_exceptions table and job_bandwidth_metrics_v UC Metric View."
    )
    parser.add_argument("--catalog", required=True, help="Target Unity Catalog name.")
    parser.add_argument("--schema", required=True, help="Target Unity Catalog schema name.")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None, *, spark_session: Any = None) -> dict[str, str]:
    args = parse_args(argv)
    if spark_session is None:
        from pyspark.sql import SparkSession  # type: ignore[import-not-found]

        spark_session = SparkSession.builder.getOrCreate()

    summary = publish_semantic_layer(
        spark_session,
        catalog=args.catalog,
        schema=args.schema,
    )
    print(json.dumps(summary, sort_keys=True))
    return summary


if __name__ == "__main__":
    main()
