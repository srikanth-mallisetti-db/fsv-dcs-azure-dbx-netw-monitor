"""Cluster node snapshot task that runs before every pipeline refresh.

Ensures the operator tables the pipeline reads exist, enforces retention on node sightings and
flow events, and appends the live dual-IP sightings of every active cluster to
live_cluster_node_snapshots. It is the only place that polls the Clusters and Jobs APIs (once
per cycle, outside the pipeline), and it fails loudly: an API or permission error fails the
task and the job run instead of silently leaving traffic unattributed.
"""

from __future__ import annotations

from typing import Any

from network_monitor.flow_utils import lookback_cutoff_sql
from network_monitor.ownership import (
    CLUSTER_NODE_RUNS_SPARK_DDL,
    collect_live_cluster_node_runs,
    ownership_rows_to_dicts,
)
from network_monitor.semantic_layer import build_job_exceptions_ddl, validate_uc_identifier

WORKSPACE_ADMINS_GROUP: str = "admins"
SNAPSHOT_RETENTION_MARGIN_HOURS: int = 24
DEFAULT_RETENTION_DAYS: int = 30


def build_live_snapshots_ddl(catalog: str, schema: str) -> str:
    """Build the CREATE TABLE IF NOT EXISTS DDL for the live_cluster_node_snapshots table."""
    cat = validate_uc_identifier(catalog, "catalog")
    sch = validate_uc_identifier(schema, "schema")
    return (
        f"CREATE TABLE IF NOT EXISTS {cat}.{sch}.live_cluster_node_snapshots "
        f"({CLUSTER_NODE_RUNS_SPARK_DDL}) USING DELTA CLUSTER BY (observed_end)"
    )


def build_retention_sql(
    catalog: str,
    schema: str,
    *,
    lookback_hours: int,
    retention_days: int = DEFAULT_RETENTION_DAYS,
    include_flow_events: bool = True,
) -> list[str]:
    """Build the DELETE statements that bound node sightings and flow events.

    Sightings are only needed while they can own flow events inside the lookback window, so
    they are kept for lookback_hours plus a one-day margin. Flow events are kept for
    retention_days. Cutoffs are hour-aligned, so most cycles delete nothing.
    """
    cat = validate_uc_identifier(catalog, "catalog")
    sch = validate_uc_identifier(schema, "schema")
    snapshot_hours = max(1, int(lookback_hours)) + SNAPSHOT_RETENTION_MARGIN_HOURS
    statements = [
        f"DELETE FROM {cat}.{sch}.live_cluster_node_snapshots "
        f"WHERE observed_end < {lookback_cutoff_sql(snapshot_hours)}"
    ]
    if include_flow_events:
        days = max(1, int(retention_days))
        statements.append(
            f"DELETE FROM {cat}.{sch}.flow_events_clean "
            f"WHERE event_time < date_trunc('HOUR', current_timestamp()) - INTERVAL {days} DAYS"
        )
    return statements


def verify_workspace_admin(workspace_client: Any) -> str:
    """Return the run-as identity's name, or fail unless it is a workspace admin.

    The Clusters and Jobs APIs return only the clusters and job runs the caller may view. A
    non-admin identity would silently see part of the workspace and report the rest of its
    traffic as UNATTRIBUTED, so the snapshot refuses to run.
    """
    me = workspace_client.current_user.me()
    name = str(getattr(me, "user_name", None) or getattr(me, "display_name", None) or "unknown")
    groups = {getattr(group, "display", None) for group in (getattr(me, "groups", None) or [])}
    if WORKSPACE_ADMINS_GROUP not in groups:
        raise PermissionError(
            f"{name} is not a workspace admin. network_monitor_job must run as a workspace "
            "admin (user or service principal) so the Clusters and Jobs APIs return every "
            "cluster and job run; otherwise their traffic is reported as UNATTRIBUTED."
        )
    return name


def snapshot_cluster_nodes(
    spark_session: Any,
    *,
    catalog: str,
    schema: str,
    is_int_test: bool = False,
    lookback_hours: int = 24,
    retention_days: int = DEFAULT_RETENTION_DAYS,
    workspace_client: Any = None,
) -> dict[str, Any]:
    """Prepare the monitor tables, apply retention, and append this cycle's live sightings.

    The int-test target attributes synthetic ownership rows, so it only prepares tables and
    applies retention without polling the APIs.
    """
    cat = validate_uc_identifier(catalog, "catalog")
    sch = validate_uc_identifier(schema, "schema")
    snapshots_table = f"{cat}.{sch}.live_cluster_node_snapshots"

    spark_session.sql(f"CREATE SCHEMA IF NOT EXISTS {cat}.{sch}")
    spark_session.sql(build_job_exceptions_ddl(cat, sch))
    spark_session.sql(build_live_snapshots_ddl(cat, sch))
    include_flow_events = bool(spark_session.catalog.tableExists(f"{cat}.{sch}.flow_events_clean"))
    for statement in build_retention_sql(
        cat,
        sch,
        lookback_hours=lookback_hours,
        retention_days=retention_days,
        include_flow_events=include_flow_events,
    ):
        spark_session.sql(statement)

    summary: dict[str, Any] = {"table": snapshots_table, "run_as": None, "sightings": 0}
    if is_int_test:
        return summary

    if workspace_client is None:
        from databricks.sdk import WorkspaceClient

        workspace_client = WorkspaceClient()
    summary["run_as"] = verify_workspace_admin(workspace_client)
    rows = collect_live_cluster_node_runs(workspace_client)
    if rows:
        spark_session.createDataFrame(
            ownership_rows_to_dicts(rows),
            schema=CLUSTER_NODE_RUNS_SPARK_DDL,
        ).write.format("delta").mode("append").saveAsTable(snapshots_table)
    summary["sightings"] = len(rows)
    return summary
