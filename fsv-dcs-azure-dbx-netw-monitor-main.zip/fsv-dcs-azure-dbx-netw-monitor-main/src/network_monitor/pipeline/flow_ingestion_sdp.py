"""Serverless Lakeflow Spark Declarative Pipeline (SDP) for Azure VNet Flow Log v4 attribution.

Manages the end-to-end streaming ingestion, Auto CDC SCD Type 1 deduplication, live +
Unity Catalog system table compute ownership resolution, and 5-minute window bandwidth
attribution in a single declarative pipeline definition:
  1. raw_flow_tuples_stream (@dlt.view)
  2. flow_events_clean (Streaming Table via dlt.create_auto_cdc_flow, SCD Type 1)
  3. flow_event_deltas (@dlt.table Materialized View; re-created flows' repeated counters removed)
  4. cluster_node_runs (@dlt.table)
  5. job_bandwidth_5m (@dlt.table Materialized View)
"""

from __future__ import annotations

import importlib.util
import inspect
import sys
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol, TypeVar


def _ensure_package_importable() -> None:
    """Ensure src/ is on sys.path when loaded by SDP or spark_python_task."""
    candidates: list[Path] = []
    spark_obj = globals().get("spark")
    if spark_obj is not None:
        try:
            cfg_src = spark_obj.conf.get("network_monitor.bundle_src_path", "")
            if cfg_src:
                candidates.extend([Path(cfg_src), Path(f"/Workspace{cfg_src}")])
        except Exception:
            pass
    frame = inspect.currentframe()
    raw_paths = [
        globals().get("__file__"),
        globals().get("filename"),
        frame.f_code.co_filename if frame is not None else None,
        sys.argv[0] if sys.argv else None,
    ]
    for raw in raw_paths:
        if isinstance(raw, str) and raw and not raw.startswith("<"):
            for prefix in ("", "/Workspace/", "/Workspace/Users/"):
                p = Path(f"{prefix}{raw.lstrip('/')}" if prefix else raw).resolve()
                candidates.extend([p.parents[2], p.parents[1], p.parent])
    cwd = Path.cwd().resolve()
    candidates.extend([cwd / "src", cwd.parent / "src", cwd])
    for candidate in candidates:
        if (candidate / "network_monitor").is_dir():
            cand_str = str(candidate)
            if cand_str not in sys.path:
                sys.path.insert(0, cand_str)
            return


_ensure_package_importable()

from network_monitor.flow_utils import (  # noqa: E402
    FLOW_EVENT_PASSTHROUGH_COLUMNS,
    RECREATION_LAG_MARGIN_HOURS,
    build_raw_flow_tuples_sql_projections,
    corrected_counter_sql,
    is_recreated_tuple_sql,
    lookback_cutoff_sql,
    parse_flow_log_start_after,
    parse_target_resource_ids,
    recreation_keys_sql,
    recreation_lag_sql_exprs,
    sql_expr,
    target_resource_filter_sql,
)
from network_monitor.ownership import build_cluster_node_runs_df  # noqa: E402

FuncT = TypeVar("FuncT", bound=Callable[[], Any])

VNET_FLOW_LOG_V4_JSON_DDL: str = (
    "records ARRAY<STRUCT<"
    "time: STRING, "
    "flowLogVersion: INT, "
    "flowLogGUID: STRING, "
    "macAddress: STRING, "
    "category: STRING, "
    "flowLogResourceID: STRING, "
    "targetResourceID: STRING, "
    "operationName: STRING, "
    "flowRecords: STRUCT<"
    "flows: ARRAY<STRUCT<"
    "aclID: STRING, "
    "flowGroups: ARRAY<STRUCT<"
    "rule: STRING, "
    "flowTuples: ARRAY<STRING>"
    ">>"
    ">>"
    ">"
    ">>"
)

PIPELINE_VIEWS: tuple[str, ...] = ("raw_flow_tuples_stream",)

PIPELINE_TABLES: tuple[str, ...] = (
    "flow_events_clean",
    "flow_event_deltas",
    "cluster_node_runs",
    "job_bandwidth_5m",
)


@dataclass(frozen=True, slots=True)
class PipelineConfig:
    """Resolved runtime configuration parameters for the Serverless SDP pipeline."""

    catalog: str
    schema: str
    compute_subnet_cidrs: str
    private_endpoint_cidrs: str
    flow_log_source_path: str
    flow_log_target_resource_ids: str
    flow_log_start_after: str
    bandwidth_threshold_mbps: float
    lookback_hours: int
    is_int_test: bool


class DltLike(Protocol):
    """Protocol representing the Databricks Lakeflow SDP (dlt) runtime module."""

    def view(self, *, name: str, comment: str) -> Callable[[FuncT], FuncT]: ...

    def table(
        self, *, name: str, comment: str, cluster_by: list[str] | None = None
    ) -> Callable[[FuncT], FuncT]: ...

    def create_streaming_table(
        self, *, name: str, comment: str, cluster_by: list[str] | None = None
    ) -> None: ...

    def create_auto_cdc_flow(
        self,
        *,
        target: str,
        source: str,
        keys: list[str],
        sequence_by: Any,
        stored_as_scd_type: int,
    ) -> None: ...

    def read(self, name: str) -> Any: ...


def _conf_get(spark_session: Any, key: str, default: str) -> str:
    conf = getattr(spark_session, "conf", None)
    if conf is not None and hasattr(conf, "get"):
        try:
            value = conf.get(key, default)
            if value is not None and str(value).strip():
                return str(value).strip()
        except Exception:
            return default
    return default


def read_pipeline_config(spark_session: Any) -> PipelineConfig:
    """Read network_monitor.* pipeline configuration from SparkSession.conf."""
    catalog = _conf_get(spark_session, "network_monitor.catalog", "main")
    schema = _conf_get(spark_session, "network_monitor.schema", "network_monitor")
    compute_subnet_cidrs = _conf_get(
        spark_session,
        "network_monitor.compute_subnet_cidrs",
        "10.0.0.0/18,10.0.64.0/18",
    )
    private_endpoint_cidrs = _conf_get(
        spark_session,
        "network_monitor.private_endpoint_cidrs",
        "",
    )
    flow_log_source_path = _conf_get(
        spark_session,
        "network_monitor.flow_log_source_path",
        f"/Volumes/{catalog}/{schema}/flow_logs",
    )
    flow_log_target_resource_ids = _conf_get(
        spark_session,
        "network_monitor.flow_log_target_resource_ids",
        "",
    )
    flow_log_start_after = _conf_get(
        spark_session,
        "network_monitor.flow_log_start_after",
        "",
    )
    threshold_raw = _conf_get(
        spark_session,
        "network_monitor.bandwidth_threshold_mbps",
        "100.0",
    )
    lookback_raw = _conf_get(
        spark_session,
        "network_monitor.lookback_hours",
        "24",
    )
    is_int_test_raw = _conf_get(
        spark_session,
        "network_monitor.is_int_test",
        "false",
    )

    try:
        threshold_mbps = float(threshold_raw)
    except ValueError:
        threshold_mbps = 100.0

    try:
        lookback_hours = max(1, int(lookback_raw))
    except ValueError:
        lookback_hours = 24

    is_int_test = is_int_test_raw.lower() in {"true", "1", "yes"}

    return PipelineConfig(
        catalog=catalog,
        schema=schema,
        compute_subnet_cidrs=compute_subnet_cidrs,
        private_endpoint_cidrs=private_endpoint_cidrs,
        flow_log_source_path=flow_log_source_path,
        flow_log_target_resource_ids=flow_log_target_resource_ids,
        flow_log_start_after=flow_log_start_after,
        bandwidth_threshold_mbps=threshold_mbps,
        lookback_hours=lookback_hours,
        is_int_test=is_int_test,
    )


def build_raw_flow_tuples_stream_df(spark_session: Any, cfg: PipelineConfig) -> Any:
    """Build the Auto Loader streaming DataFrame for raw_flow_tuples_stream."""
    sql_proj = build_raw_flow_tuples_sql_projections(
        compute_subnet_cidrs=cfg.compute_subnet_cidrs,
        private_endpoint_cidrs=cfg.private_endpoint_cidrs,
    )
    target_ids = parse_target_resource_ids(cfg.flow_log_target_resource_ids)
    start_after = parse_flow_log_start_after(cfg.flow_log_start_after)

    reader = (
        spark_session.readStream.format("cloudFiles")
        .option("cloudFiles.format", "json")
        .option("cloudFiles.allowOverwrites", "true")
        .option("cloudFiles.partitionColumns", "")
        .option("multiLine", "true")
    )
    if start_after is not None:
        # Skip flow-log files last modified before the configured start instead of backfilling
        reader = reader.option("modifiedAfter", start_after)
    raw_files_df = reader.schema(VNET_FLOW_LOG_V4_JSON_DDL).load(cfg.flow_log_source_path)

    exploded_records = (
        raw_files_df.selectExpr(
            "EXPLODE(records) AS rec",
            "_metadata.file_path AS source_file",
            "_metadata.file_modification_time AS file_mod_time",
        )
        # Ignore records from flow logs of other networks that share the storage path
        .where(target_resource_filter_sql("rec.targetResourceID", target_ids))
        .selectExpr(
            "COALESCE(TRIM(rec.flowLogGUID), 'unknown-guid') AS flow_log_guid",
            "COALESCE(TRIM(rec.macAddress), '000000000000') AS mac_address",
            "EXPLODE(rec.flowRecords.flows) AS flow_entry",
            "source_file",
            "file_mod_time",
        )
        .selectExpr(
            "flow_log_guid",
            "mac_address",
            "EXPLODE(flow_entry.flowGroups) AS flow_group",
            "source_file",
            "file_mod_time",
        )
        .selectExpr(
            "flow_log_guid",
            "mac_address",
            "EXPLODE(flow_group.flowTuples) AS raw_tuple",
            # The B tuples' keys, read before B tuples are dropped: an E tuple sharing one is a
            # re-created flow, whose next report repeats its counters
            f"{recreation_keys_sql('flow_group.flowTuples')} AS recreation_keys",
            "source_file",
            "file_mod_time",
        )
    )

    parsed_tuples = exploded_records.selectExpr(
        "flow_log_guid",
        "mac_address",
        "source_file",
        "COALESCE(file_mod_time, current_timestamp()) AS file_mod_time",
        "TRY_CAST(TRIM(SPLIT_PART(raw_tuple, ',', 1)) AS BIGINT) AS raw_epoch",
        "TRIM(SPLIT_PART(raw_tuple, ',', 2)) AS src_ip",
        "TRIM(SPLIT_PART(raw_tuple, ',', 3)) AS dest_ip",
        "TRY_CAST(TRIM(SPLIT_PART(raw_tuple, ',', 4)) AS INT) AS src_port",
        "TRY_CAST(TRIM(SPLIT_PART(raw_tuple, ',', 5)) AS INT) AS dest_port",
        "TRY_CAST(TRIM(SPLIT_PART(raw_tuple, ',', 6)) AS INT) AS protocol",
        "UPPER(TRIM(SPLIT_PART(raw_tuple, ',', 7))) AS flow_direction",
        "UPPER(TRIM(SPLIT_PART(raw_tuple, ',', 8))) AS flow_state",
        "COALESCE(TRY_CAST(NULLIF(TRIM(SPLIT_PART(raw_tuple, ',', 11)), '') AS BIGINT), 0L) "
        "AS forward_bytes",
        "COALESCE(TRY_CAST(NULLIF(TRIM(SPLIT_PART(raw_tuple, ',', 13)), '') AS BIGINT), 0L) "
        "AS reverse_bytes",
        f"{is_recreated_tuple_sql('raw_tuple', 'recreation_keys')} AS is_recreated",
    ).selectExpr(
        "*",
        "CASE WHEN raw_epoch < 100000000000L THEN raw_epoch * 1000L ELSE raw_epoch END AS epoch_ms",
        f"{sql_proj['src_in_compute_sql']} AS src_in_compute",
        f"{sql_proj['dest_in_compute_sql']} AS dest_in_compute",
    )

    non_shuffle_tuples = parsed_tuples.where(
        "epoch_ms IS NOT NULL AND epoch_ms >= 0 "
        "AND src_port IS NOT NULL AND dest_port IS NOT NULL AND protocol IS NOT NULL "
        f"AND {sql_proj['non_shuffle_filter_sql']}"
    )

    normalized = non_shuffle_tuples.selectExpr(
        "SHA2(CONCAT_WS('|', "
        "flow_log_guid, "
        "UPPER(REGEXP_REPLACE(mac_address, '[-:]', '')), "
        "CAST(epoch_ms AS STRING), "
        "src_ip, "
        "dest_ip, "
        "CAST(src_port AS STRING), "
        "CAST(dest_port AS STRING), "
        "CAST(protocol AS STRING), "
        "flow_direction"
        "), 256) AS event_id",
        "TIMESTAMP_MILLIS(epoch_ms) AS event_time",
        "CASE WHEN src_in_compute THEN src_ip ELSE dest_ip END AS local_node_ip",
        "CASE WHEN src_in_compute THEN dest_ip ELSE src_ip END AS remote_peer_ip",
        "CASE WHEN src_in_compute THEN src_port ELSE dest_port END AS local_port",
        "CASE WHEN src_in_compute THEN dest_port ELSE src_port END AS remote_port",
        "protocol",
        "flow_direction",
        "flow_state",
        "CASE WHEN src_in_compute THEN forward_bytes ELSE reverse_bytes END AS bytes_sent",
        "CASE WHEN src_in_compute THEN reverse_bytes ELSE forward_bytes END AS bytes_received",
        "source_file",
        "CASE WHEN flow_state = 'E' THEN 2 ELSE 1 END AS state_priority",
        "file_mod_time",
        "is_recreated",
    )

    return normalized.selectExpr(
        "event_id",
        "event_time",
        "local_node_ip",
        "remote_peer_ip",
        "local_port",
        "remote_port",
        "protocol",
        "flow_direction",
        "flow_state",
        f"{sql_proj['traffic_scope_sql']} AS traffic_scope",
        "bytes_sent",
        "bytes_received",
        "is_recreated",
        "source_file",
        "NAMED_STRUCT("
        "'event_time', event_time, "
        "'state_priority', state_priority, "
        "'file_mod_time', file_mod_time"
        ") AS sequence_key",
    )


def build_flow_event_deltas_df(flow_events_df: Any, *, lookback_hours: int) -> Any:
    """Build flow_event_deltas: the lookback's flow events with re-created flows' repeats removed.

    Spark twin of flow_utils.correct_recreated_flow_counters and build_flow_event_deltas_sql.
    """
    hours = max(1, int(lookback_hours))
    ordered = flow_events_df.where(
        f"event_time >= {lookback_cutoff_sql(hours + RECREATION_LAG_MARGIN_HOURS)}"
    ).selectExpr("*", *recreation_lag_sql_exprs())
    corrected = ordered.selectExpr(
        "*",
        f"{corrected_counter_sql('bytes_sent')} AS corrected_bytes_sent",
        f"{corrected_counter_sql('bytes_received')} AS corrected_bytes_received",
    )
    return corrected.where(f"event_time >= {lookback_cutoff_sql(hours)}").selectExpr(
        *FLOW_EVENT_PASSTHROUGH_COLUMNS,
        "bytes_sent AS raw_bytes_sent",
        "bytes_received AS raw_bytes_received",
        "corrected_bytes_sent AS bytes_sent",
        "corrected_bytes_received AS bytes_received",
    )


def _read_job_exceptions_df(spark_session: Any, cfg: PipelineConfig) -> Any:
    # snapshot_cluster_nodes creates job_exceptions before every refresh, so a failed read is a
    # real error (permissions, dropped table) and must fail the update instead of hiding it.
    table_fqn = f"{cfg.catalog}.{cfg.schema}.job_exceptions"
    return spark_session.read.table(table_fqn).selectExpr(
        "CAST(workspace_id AS STRING) AS workspace_id",
        "CAST(job_id AS BIGINT) AS job_id",
        "CAST(job_name AS STRING) AS job_name",
        "CAST(reason AS STRING) AS reason",
        "CAST(approved_by AS STRING) AS approved_by",
        "CAST(effective_from AS TIMESTAMP) AS effective_from",
        "CAST(effective_to AS TIMESTAMP) AS effective_to",
    )


def build_job_bandwidth_5m_df(
    flow_events_df: Any,
    cluster_runs_df: Any,
    exceptions_df: Any,
    *,
    threshold_mbps: float,
) -> Any:
    """Build the Gold 5-minute window bandwidth attribution DataFrame."""
    threshold_lit = float(threshold_mbps)

    event_windows = flow_events_df.selectExpr(
        "event_id",
        "event_time",
        "window(event_time, '5 minutes').start AS window_start",
        "window(event_time, '5 minutes').end AS window_end",
        "local_node_ip",
        "remote_peer_ip",
        "traffic_scope",
        "CAST(bytes_sent AS BIGINT) AS bytes_sent",
        "CAST(bytes_received AS BIGINT) AS bytes_received",
        "CAST(bytes_sent + bytes_received AS BIGINT) AS event_total_bytes",
    )

    joined_events = (
        event_windows.alias("ew")
        .join(
            cluster_runs_df.alias("c"),
            on=sql_expr(
                "ew.local_node_ip = c.node_ip "
                "AND ew.event_time BETWEEN c.observed_start AND c.observed_end"
            ),
            how="left",
        )
        .selectExpr(
            "ew.event_id AS event_id",
            "ew.window_start AS window_start",
            "ew.window_end AS window_end",
            "COALESCE(c.workspace_id, 'UNATTRIBUTED') AS workspace_id",
            "COALESCE(c.cluster_id, 'UNATTRIBUTED') AS cluster_id",
            "ew.remote_peer_ip AS remote_peer_ip",
            "ew.traffic_scope AS traffic_scope",
            "ew.bytes_sent AS bytes_sent",
            "ew.bytes_received AS bytes_received",
            "ew.event_total_bytes AS event_total_bytes",
            "c.job_id AS job_id",
            "c.run_id AS run_id",
            "c.job_name AS job_name",
        )
    )

    # Deduplicate per (event_id, window_start, window_end, workspace_id, cluster_id)
    # so shared clusters with multiple overlapping runs never multiply byte counters.
    matched_events = joined_events.groupBy(
        "event_id",
        "window_start",
        "window_end",
        "workspace_id",
        "cluster_id",
    ).agg(
        sql_expr("MAX(remote_peer_ip) AS remote_peer_ip"),
        sql_expr("MAX(traffic_scope) AS traffic_scope"),
        sql_expr("MAX(bytes_sent) AS bytes_sent"),
        sql_expr("MAX(bytes_received) AS bytes_received"),
        sql_expr("MAX(event_total_bytes) AS event_total_bytes"),
        sql_expr("ARRAY_SORT(COLLECT_SET(job_id)) AS event_job_ids"),
        sql_expr("MAX_BY(run_id, COALESCE(job_id, -1)) AS sample_run_id"),
        sql_expr("MAX_BY(job_name, COALESCE(job_id, -1)) AS sample_job_name"),
    )

    top_peers = (
        matched_events.groupBy(
            "window_start",
            "window_end",
            "workspace_id",
            "cluster_id",
            "remote_peer_ip",
        )
        .agg(sql_expr("SUM(event_total_bytes) AS peer_bytes"))
        .groupBy("window_start", "window_end", "workspace_id", "cluster_id")
        .agg(
            sql_expr(
                "MIN_BY(remote_peer_ip, "
                "NAMED_STRUCT('neg_bytes', -peer_bytes, 'ip', remote_peer_ip)) "
                "AS top_remote_peer_ip"
            )
        )
    )

    cluster_window_agg = matched_events.groupBy(
        "window_start",
        "window_end",
        "workspace_id",
        "cluster_id",
    ).agg(
        sql_expr(
            "ARRAY_SORT(ARRAY_COMPACT(FLATTEN(COLLECT_SET(event_job_ids)))) AS candidate_job_ids"
        ),
        sql_expr("MAX(sample_run_id) AS single_run_id"),
        sql_expr("MAX(sample_job_name) AS single_job_name"),
        sql_expr("CAST(SUM(bytes_sent) AS BIGINT) AS bytes_sent"),
        sql_expr("CAST(SUM(bytes_received) AS BIGINT) AS bytes_received"),
        sql_expr("CAST(SUM(event_total_bytes) AS BIGINT) AS total_bytes"),
        sql_expr(
            "CAST(SUM(CASE WHEN traffic_scope = 'PRIVATE_ENDPOINT' "
            "THEN event_total_bytes ELSE 0 END) AS BIGINT) AS private_endpoint_bytes"
        ),
        sql_expr(
            "CAST(SUM(CASE WHEN traffic_scope = 'EXTERNAL' "
            "THEN event_total_bytes ELSE 0 END) AS BIGINT) AS external_bytes"
        ),
    )

    active_exemptions = (
        cluster_window_agg.alias("cwa")
        .join(
            exceptions_df.alias("ex"),
            on=sql_expr(
                "cwa.workspace_id = ex.workspace_id "
                "AND SIZE(cwa.candidate_job_ids) = 1 "
                "AND ELEMENT_AT(cwa.candidate_job_ids, 1) = ex.job_id "
                "AND ex.effective_from <= cwa.window_start "
                "AND (ex.effective_to IS NULL OR ex.effective_to >= cwa.window_end)"
            ),
            how="inner",
        )
        .selectExpr(
            "cwa.window_start AS window_start",
            "cwa.window_end AS window_end",
            "cwa.workspace_id AS workspace_id",
            "ex.job_id AS exempt_job_id",
        )
        .distinct()
    )

    enriched = (
        cluster_window_agg.alias("cwa")
        .join(
            top_peers.alias("tp"),
            on=["window_start", "window_end", "workspace_id", "cluster_id"],
            how="left",
        )
        .join(
            active_exemptions.alias("ae"),
            on=sql_expr(
                "cwa.window_start = ae.window_start "
                "AND cwa.window_end = ae.window_end "
                "AND cwa.workspace_id = ae.workspace_id "
                "AND SIZE(cwa.candidate_job_ids) = 1 "
                "AND ELEMENT_AT(cwa.candidate_job_ids, 1) = ae.exempt_job_id"
            ),
            how="left",
        )
    )

    return enriched.selectExpr(
        "cwa.window_start AS window_start",
        "cwa.window_end AS window_end",
        "cwa.workspace_id AS workspace_id",
        "cwa.cluster_id AS cluster_id",
        "CASE "
        "WHEN cwa.cluster_id = 'UNATTRIBUTED' "
        "OR SIZE(cwa.candidate_job_ids) = 0 THEN 'UNATTRIBUTED' "
        "WHEN SIZE(cwa.candidate_job_ids) > 1 THEN 'SHARED' "
        "WHEN ae.exempt_job_id IS NOT NULL THEN 'EXEMPT' "
        "ELSE 'MONITORED' "
        "END AS attribution_category",
        "CASE WHEN SIZE(cwa.candidate_job_ids) = 1 "
        "THEN ELEMENT_AT(cwa.candidate_job_ids, 1) ELSE CAST(NULL AS BIGINT) END AS job_id",
        "CASE WHEN SIZE(cwa.candidate_job_ids) = 1 "
        "THEN cwa.single_run_id ELSE CAST(NULL AS BIGINT) END AS run_id",
        "CASE "
        "WHEN cwa.cluster_id = 'UNATTRIBUTED' OR SIZE(cwa.candidate_job_ids) <= 1 "
        "THEN cwa.single_job_name "
        "ELSE CONCAT('SHARED (', "
        "ARRAY_JOIN(TRANSFORM(cwa.candidate_job_ids, x -> CAST(x AS STRING)), ','), ')') "
        "END AS job_name",
        "cwa.candidate_job_ids AS candidate_job_ids",
        "cwa.bytes_sent AS bytes_sent",
        "cwa.bytes_received AS bytes_received",
        "cwa.total_bytes AS total_bytes",
        "cwa.private_endpoint_bytes AS private_endpoint_bytes",
        "cwa.external_bytes AS external_bytes",
        "CAST((cwa.total_bytes * 8.0) / (300.0 * 1000000.0) AS DOUBLE) AS avg_mbps",
        f"CAST({threshold_lit} AS DOUBLE) AS threshold_mbps",
        "tp.top_remote_peer_ip AS top_remote_peer_ip",
        "CASE "
        "WHEN ("
        "CASE "
        "WHEN cwa.cluster_id = 'UNATTRIBUTED' "
        "OR SIZE(cwa.candidate_job_ids) = 0 THEN 'UNATTRIBUTED' "
        "WHEN SIZE(cwa.candidate_job_ids) > 1 THEN 'SHARED' "
        "WHEN ae.exempt_job_id IS NOT NULL THEN 'EXEMPT' "
        "ELSE 'MONITORED' "
        "END"
        f") != 'EXEMPT' AND ((cwa.total_bytes * 8.0) / (300.0 * 1000000.0)) > {threshold_lit} "
        "THEN TRUE ELSE FALSE END AS is_breach",
    )


def register_pipeline(dlt_module: DltLike, spark_session: Any) -> None:
    """Register the declarative views, Auto CDC streaming table, and materialized views."""
    cfg = read_pipeline_config(spark_session)

    @dlt_module.view(
        name="raw_flow_tuples_stream",
        comment=(
            "Ephemeral Auto Loader stream over Azure VNet Flow Log v4 PT1H.json blobs "
            "(allowOverwrites=true) with intra-cluster Spark shuffle excluded."
        ),
    )
    def raw_flow_tuples_stream() -> Any:
        return build_raw_flow_tuples_stream_df(spark_session, cfg)

    # Clustering on event_time and keying merges on it lets each micro-batch MERGE prune to the
    # few recent files its re-read PT1H.json tuples can touch instead of scanning the whole table.
    dlt_module.create_streaming_table(
        name="flow_events_clean",
        comment=(
            "Deduplicated non-shuffle VNet Flow Log v4 C/E delta tuples maintained via "
            "Auto CDC SCD Type 1 on (event_time, event_id)."
        ),
        cluster_by=["event_time"],
    )

    dlt_module.create_auto_cdc_flow(
        target="flow_events_clean",
        source="raw_flow_tuples_stream",
        keys=["event_time", "event_id"],
        sequence_by="sequence_key",
        stored_as_scd_type=1,
    )

    @dlt_module.table(
        name="flow_event_deltas",
        comment=(
            "Flow events of the last lookback_hours with the counters a re-created flow's next "
            "report repeats removed (raw counters in raw_bytes_sent and raw_bytes_received); sum "
            "bytes here rather than in flow_events_clean."
        ),
    )
    def flow_event_deltas() -> Any:
        # Re-attribute only the rolling lookback window so each refresh costs the same no matter
        # how much flow history has accumulated; reported breaches persist in
        # breach_notifications.
        return build_flow_event_deltas_df(
            dlt_module.read("flow_events_clean"),
            lookback_hours=cfg.lookback_hours,
        )

    @dlt_module.table(
        name="cluster_node_runs",
        comment=(
            "Databricks classic compute node tenure and job run windows resolved from live "
            "REST API dual-IP snapshots (host_private_ip + private_ip) within lookback_hours."
        ),
    )
    def cluster_node_runs() -> Any:
        return build_cluster_node_runs_df(
            spark_session,
            catalog=cfg.catalog,
            schema=cfg.schema,
            is_int_test=cfg.is_int_test,
            lookback_hours=cfg.lookback_hours,
        )

    @dlt_module.table(
        name="job_bandwidth_5m",
        comment=(
            "5-minute tumbling window job and cluster bandwidth attribution over the last "
            "lookback_hours, traffic scope breakdown (PRIVATE_ENDPOINT vs EXTERNAL), exemption "
            "evaluation, and breach flags."
        ),
        cluster_by=["window_start"],
    )
    def job_bandwidth_5m() -> Any:
        flow_events_df = dlt_module.read("flow_event_deltas")
        cluster_runs_df = dlt_module.read("cluster_node_runs")
        exceptions_df = _read_job_exceptions_df(spark_session, cfg)
        return build_job_bandwidth_5m_df(
            flow_events_df=flow_events_df,
            cluster_runs_df=cluster_runs_df,
            exceptions_df=exceptions_df,
            threshold_mbps=cfg.bandwidth_threshold_mbps,
        )


_dlt: Any = None
if "spark" in globals() and importlib.util.find_spec("dlt") is not None:
    try:
        import dlt as _dlt_mod  # type: ignore[import-not-found]

        _dlt = _dlt_mod
    except Exception:
        _dlt = None

if _dlt is not None and "spark" in globals():
    register_pipeline(_dlt, globals()["spark"])
