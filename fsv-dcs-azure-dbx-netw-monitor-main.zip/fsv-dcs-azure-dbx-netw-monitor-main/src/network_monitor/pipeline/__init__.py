"""Lakeflow Spark Declarative Pipeline definitions for VNet Flow Log bandwidth attribution."""
