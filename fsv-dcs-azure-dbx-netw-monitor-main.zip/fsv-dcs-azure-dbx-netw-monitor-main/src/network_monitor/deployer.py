"""One-shot JSON-driven deployment orchestrator for the Azure Databricks Network Bandwidth Monitor.

Supports dev, prod, and int-test bundle targets using a single JSON configuration file.
Automatically exports BUNDLE_VAR_* environment variables (preventing CLI comma splitting on
CIDRs), writes complex variables (breach alert recipients) to the target's
variable-overrides.json, ensures target Unity Catalog schemas exist, validates and deploys the
bundle, and handles cold-schema Genie Space bootstrapping on first deployment.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from network_monitor.flow_utils import (
    parse_cidr_ranges,
    parse_flow_log_start_after,
    parse_target_resource_ids,
    resolve_private_endpoint_ranges,
)

BundleTarget = Literal["dev", "prod", "int-test"]
VALID_TARGETS: frozenset[str] = frozenset({"dev", "prod", "int-test"})

ALERT_SUBSCRIPTIONS_VAR: str = "alert_subscriptions"
ALERT_TASK_SUBSCRIBERS_VAR: str = "alert_task_subscribers"
JOB_FAILURE_EMAILS_VAR: str = "job_failure_emails"
JOB_FAILURE_DESTINATIONS_VAR: str = "job_failure_destinations"
VARIABLE_OVERRIDES_FILENAME: str = "variable-overrides.json"
EMAIL_PATTERN = re.compile(r"^[^@\s,;<>]+@[^@\s,;<>]+\.[^@\s,;<>]+$")
DESTINATION_ID_PATTERN = re.compile(r"^[A-Za-z0-9-]+$")

BUNDLE_VAR_KEYS: tuple[str, ...] = (
    "catalog",
    "schema",
    "warehouse_id",
    "compute_subnet_cidrs",
    "private_endpoint_cidrs",
    "flow_log_source_path",
    "flow_log_target_resource_ids",
    "flow_log_start_after",
    "bandwidth_threshold_mbps",
    "lookback_hours",
    "retention_days",
    "is_int_test",
    "schedule_pause_status",
)

CommandRunner = Callable[[Sequence[str], Mapping[str, str]], subprocess.CompletedProcess[str]]


@dataclass(frozen=True, slots=True)
class DeploymentConfig:
    """Validated deployment orchestration parameters and DAB variable overrides."""

    profile: str
    target: BundleTarget
    workspace_host: str | None
    ensure_schema: bool
    run_initial_job: bool
    full_refresh: bool
    bundle_vars: dict[str, str]
    alert_subscriptions: tuple[dict[str, str], ...]

    def build_subprocess_env(
        self,
        base_env: Mapping[str, str] | None = None,
    ) -> dict[str, str]:
        """Build the environment dictionary with BUNDLE_VAR_<key> variables injected."""
        env = dict(os.environ if base_env is None else base_env)
        for key, value in self.bundle_vars.items():
            if value != "":
                env[f"BUNDLE_VAR_{key}"] = str(value)
        return env

    def build_variable_overrides(self) -> dict[str, Any]:
        """Build complex variable values; the CLI reads these only from variable-overrides.json.

        The same recipients feed the alert's own subscriptions (user_email), the job's
        notify_new_breaches alert task subscribers (user_name), which receive job evaluations,
        and the job's failure notifications (emails and notification destination webhooks).
        """
        return {
            ALERT_SUBSCRIPTIONS_VAR: [dict(sub) for sub in self.alert_subscriptions],
            ALERT_TASK_SUBSCRIBERS_VAR: [
                {"user_name": sub["user_email"]} if "user_email" in sub else dict(sub)
                for sub in self.alert_subscriptions
            ],
            JOB_FAILURE_EMAILS_VAR: [
                sub["user_email"] for sub in self.alert_subscriptions if "user_email" in sub
            ],
            JOB_FAILURE_DESTINATIONS_VAR: [
                {"id": sub["destination_id"]}
                for sub in self.alert_subscriptions
                if "destination_id" in sub
            ],
        }


def _coerce_bool(val: Any, default: bool) -> bool:
    if val is None:
        return default
    if isinstance(val, bool):
        return val
    if isinstance(val, str):
        return val.strip().lower() in {"true", "1", "yes"}
    return bool(val)


def _coerce_str_list(val: Any, field: str) -> list[str]:
    if val is None:
        return []
    items: Sequence[Any]
    if isinstance(val, str):
        items = re.split(r"[,;]", val)
    elif isinstance(val, list):
        items = val
    else:
        raise ValueError(f"'{field}' must be a JSON list or a comma-separated string.")
    cleaned: list[str] = []
    for item in items:
        if not isinstance(item, str):
            raise ValueError(f"'{field}' entries must be strings.")
        value = item.strip()
        if value and value not in cleaned:
            cleaned.append(value)
    return cleaned


def _build_alert_subscriptions(
    emails: Sequence[str],
    destination_ids: Sequence[str],
) -> tuple[dict[str, str], ...]:
    for email in emails:
        if not EMAIL_PATTERN.match(email):
            raise ValueError(f"Invalid alert recipient email address: {email!r}")
    for destination_id in destination_ids:
        if not DESTINATION_ID_PATTERN.match(destination_id):
            raise ValueError(f"Invalid alert notification destination ID: {destination_id!r}")
    subscriptions = [{"user_email": email} for email in emails]
    subscriptions.extend({"destination_id": dest_id} for dest_id in destination_ids)
    if not subscriptions:
        raise ValueError(
            "At least one breach alert recipient is required: set 'alert_email_recipients' "
            "(Databricks workspace user emails) and/or 'alert_notification_destination_ids' "
            "(email notification destination IDs) in the deployment JSON config."
        )
    return tuple(subscriptions)


def load_deployment_config(
    config_source: str | Path | Mapping[str, Any],
    *,
    profile_override: str | None = None,
    target_override: str | None = None,
    skip_job_run: bool = False,
    full_refresh_override: bool | None = None,
) -> DeploymentConfig:
    """Load and validate a DeploymentConfig from a JSON file path or dictionary."""
    if isinstance(config_source, (str, Path)):
        # utf-8-sig: Windows editors and PowerShell may save the JSON with a byte-order mark
        raw_text = Path(config_source).read_text(encoding="utf-8-sig")
        payload = json.loads(raw_text)
    else:
        payload = dict(config_source)

    if not isinstance(payload, Mapping):
        raise ValueError("Deployment configuration JSON must be an object.")

    raw_profile = profile_override or payload.get("profile") or payload.get("databricks_profile")
    if not isinstance(raw_profile, str) or not raw_profile.strip():
        raise ValueError("A non-empty Databricks CLI 'profile' is required in the JSON config.")
    profile = raw_profile.strip()

    raw_target = target_override or payload.get("target") or payload.get("bundle_target") or "dev"
    target_str = str(raw_target).strip()
    if target_str not in VALID_TARGETS:
        raise ValueError(
            f"Unsupported bundle target {target_str!r}. Must be one of: dev, prod, int-test."
        )
    target: BundleTarget = target_str  # type: ignore[assignment]

    raw_host = payload.get("workspace_host") or payload.get("host")
    workspace_host = (
        str(raw_host).strip() if isinstance(raw_host, str) and raw_host.strip() else None
    )

    nested_vars = payload.get("bundle_vars")
    if nested_vars is not None and not isinstance(nested_vars, Mapping):
        raise ValueError("'bundle_vars' must be a JSON object when provided.")

    def lookup(key: str) -> Any:
        if isinstance(nested_vars, Mapping) and key in nested_vars:
            return nested_vars[key]
        return payload.get(key)

    merged_vars: dict[str, str] = {}
    for key in BUNDLE_VAR_KEYS:
        val = lookup(key)
        if val is not None and str(val).strip() != "":
            merged_vars[key] = str(val).strip()

    if "catalog" not in merged_vars or not merged_vars["catalog"]:
        raise ValueError("Bundle variable 'catalog' is required in the deployment JSON config.")
    if "warehouse_id" not in merged_vars or not merged_vars["warehouse_id"]:
        raise ValueError(
            "Bundle variable 'warehouse_id' is required in the deployment JSON config."
        )

    if target == "int-test":
        merged_vars["is_int_test"] = "true"
        merged_vars.setdefault("bandwidth_threshold_mbps", "1.0")
        merged_vars.setdefault("compute_subnet_cidrs", "10.0.0.0/18,10.0.64.0/18")
        merged_vars.setdefault("private_endpoint_cidrs", "10.0.128.0/18")
        merged_vars.setdefault("schedule_pause_status", "PAUSED")
    else:
        merged_vars.setdefault("is_int_test", "false")
        merged_vars.setdefault("schema", "network_monitor")
        merged_vars.setdefault("bandwidth_threshold_mbps", "100.0")
        merged_vars.setdefault("lookback_hours", "24")
        merged_vars.setdefault(
            "schedule_pause_status",
            "UNPAUSED" if target == "prod" else "PAUSED",
        )
        if "compute_subnet_cidrs" not in merged_vars:
            raise ValueError(
                f"Bundle variable 'compute_subnet_cidrs' is required for target {target!r}."
            )
        if "flow_log_source_path" not in merged_vars:
            raise ValueError(
                f"Bundle variable 'flow_log_source_path' is required for target {target!r}."
            )

    # Validate CIDRs, flow-log targets, and the flow-log start upfront before calling the CLI
    parse_cidr_ranges(merged_vars["compute_subnet_cidrs"])
    resolve_private_endpoint_ranges(merged_vars.get("private_endpoint_cidrs"))
    parse_target_resource_ids(merged_vars.get("flow_log_target_resource_ids"))
    parse_flow_log_start_after(merged_vars.get("flow_log_start_after"))

    try:
        threshold_val = float(merged_vars["bandwidth_threshold_mbps"])
        if threshold_val <= 0:
            raise ValueError
    except ValueError as exc:
        raise ValueError(
            "Bundle variable 'bandwidth_threshold_mbps' must be a positive number."
        ) from exc

    for hours_or_days in ("lookback_hours", "retention_days"):
        value = merged_vars.get(hours_or_days)
        if value is not None and not (value.isdigit() and int(value) > 0):
            raise ValueError(f"Bundle variable '{hours_or_days}' must be a positive whole number.")

    alert_subscriptions = _build_alert_subscriptions(
        _coerce_str_list(lookup("alert_email_recipients"), "alert_email_recipients"),
        _coerce_str_list(
            lookup("alert_notification_destination_ids"), "alert_notification_destination_ids"
        ),
    )

    ensure_schema = _coerce_bool(
        payload.get("ensure_schema"),
        default=(target in {"dev", "prod"}),
    )
    run_initial_job = False if skip_job_run else _coerce_bool(payload.get("run_initial_job"), True)
    full_refresh = (
        full_refresh_override
        if full_refresh_override is not None
        else _coerce_bool(payload.get("full_refresh"), False)
    )

    return DeploymentConfig(
        profile=profile,
        target=target,
        workspace_host=workspace_host,
        ensure_schema=ensure_schema,
        run_initial_job=run_initial_job,
        full_refresh=full_refresh,
        bundle_vars=merged_vars,
        alert_subscriptions=alert_subscriptions,
    )


def variable_overrides_path(bundle_root: Path, target: str) -> Path:
    """Return the per-target file the Databricks CLI reads complex variable values from."""
    return bundle_root / ".databricks" / "bundle" / target / VARIABLE_OVERRIDES_FILENAME


def write_variable_overrides(
    bundle_root: Path,
    target: str,
    overrides: Mapping[str, Any],
) -> Path:
    """Merge overrides into the target's variable-overrides.json, preserving other variables."""
    path = variable_overrides_path(bundle_root, target)
    existing: dict[str, Any] = {}
    if path.is_file():
        try:
            loaded = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"{path} is not valid JSON: {exc}") from exc
        if not isinstance(loaded, dict):
            raise ValueError(f"{path} must contain a JSON object.")
        existing = loaded
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({**existing, **overrides}, indent=2) + "\n", encoding="utf-8")
    return path


def _default_runner(
    cmd: Sequence[str],
    env: Mapping[str, str],
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        list(cmd),
        env=dict(env),
        text=True,
        capture_output=True,
        check=False,
    )


def _names_genie_space(output: str) -> bool:
    """Return True if a failed deploy names the Genie Space.

    The wording of the missing-table error differs between CLI versions and deployment
    engines, but every version names the Genie Space resource that failed.
    """
    return "genie" in output.lower()


def execute_deployment(
    cfg: DeploymentConfig,
    *,
    validate_only: bool = False,
    destroy: bool = False,
    dry_run: bool = False,
    runner: CommandRunner | None = None,
    bundle_root: Path | None = None,
) -> dict[str, Any]:
    """Execute the one-shot DAB validation, deployment, job bootstrap, and summary workflow.

    With destroy=True it instead removes everything the bundle deployed for the target.
    """
    if validate_only and destroy:
        raise ValueError("validate_only and destroy cannot be combined.")
    exec_runner = runner or _default_runner
    env = cfg.build_subprocess_env()
    executed_commands: list[list[str]] = []
    root = bundle_root if bundle_root is not None else Path.cwd()
    overrides_path = variable_overrides_path(root, cfg.target)
    alert_subscriptions = [dict(sub) for sub in cfg.alert_subscriptions]

    def run_step(
        cmd: list[str],
        *,
        allow_failure: bool = False,
    ) -> subprocess.CompletedProcess[str]:
        executed_commands.append(cmd)
        if dry_run:
            return subprocess.CompletedProcess(cmd, 0, stdout="[dry-run]", stderr="")
        res = exec_runner(cmd, env)
        if res.returncode != 0 and not allow_failure:
            combined = "\n".join(part for part in (res.stdout, res.stderr) if part).strip()
            raise RuntimeError(f"Command failed ({' '.join(cmd)}):\n{combined}")
        return res

    # 1. Verify Databricks CLI profile authentication
    run_step(["databricks", "current-user", "me", "--profile", cfg.profile, "-o", "json"])

    # 2. Optionally ensure target UC schema exists for dev/prod (--validate-only changes nothing
    # in the workspace)
    if cfg.ensure_schema and cfg.target in {"dev", "prod"} and not (validate_only or destroy):
        schema_name = cfg.bundle_vars.get("schema", "network_monitor")
        catalog_name = cfg.bundle_vars["catalog"]
        run_step(
            [
                "databricks",
                "schemas",
                "create",
                schema_name,
                catalog_name,
                "--profile",
                cfg.profile,
            ],
            allow_failure=True,
        )

    # 3. Write complex variables (breach alert recipients), which the CLI cannot read from env
    if not dry_run:
        write_variable_overrides(root, cfg.target, cfg.build_variable_overrides())

    if destroy:
        # The CLI must load the bundle to destroy it, and it needs this config's variables to do
        # so: a bare `databricks bundle destroy` fails without warehouse_id
        run_step(
            [
                "databricks",
                "bundle",
                "destroy",
                "-t",
                cfg.target,
                "--profile",
                cfg.profile,
                "--auto-approve",
            ]
        )
        return {
            "status": "dry_run" if dry_run else "destroyed",
            "target": cfg.target,
            "profile": cfg.profile,
            "executed_commands": executed_commands,
        }

    # 4. Validate bundle
    run_step(["databricks", "bundle", "validate", "-t", cfg.target, "--profile", cfg.profile])

    if validate_only:
        return {
            "status": "dry_run" if dry_run else "validated",
            "target": cfg.target,
            "profile": cfg.profile,
            "bundle_vars": cfg.bundle_vars,
            "alert_subscriptions": alert_subscriptions,
            "variable_overrides_path": str(overrides_path),
            "executed_commands": executed_commands,
        }

    # 5. Deploy bundle. On a cold schema the Genie Space cannot be created until
    # network_monitor_job has created the tables it reads, so a deploy that fails on the Genie
    # Space runs the job once and deploys again.
    deploy_cmd = ["databricks", "bundle", "deploy", "-t", cfg.target, "--profile", cfg.profile]
    deploy_res = run_step(deploy_cmd, allow_failure=True)
    deploy_output = "\n".join(
        part for part in (deploy_res.stdout, deploy_res.stderr) if part
    ).strip()

    cold_genie_bootstrap_needed = deploy_res.returncode != 0 and _names_genie_space(deploy_output)
    if deploy_res.returncode != 0 and not cold_genie_bootstrap_needed:
        raise RuntimeError(f"Bundle deploy failed ({' '.join(deploy_cmd)}):\n{deploy_output}")

    job_cmd = [
        "databricks",
        "bundle",
        "run",
        "network_monitor_job",
        "-t",
        cfg.target,
        "--profile",
        cfg.profile,
    ]

    job_ran = False
    try:
        # A full refresh resets the pipeline tables and re-ingests every flow log still in
        # storage (since flow_log_start_after, when set). Pipeline flags do not apply to job
        # runs, so the pipeline is run directly, after the job tasks that create the tables it
        # reads (plus, in int-test, its synthetic inputs).
        if cfg.full_refresh:
            prepare_tasks = (
                "+generate_synthetic_telemetry"
                if cfg.target == "int-test"
                else "snapshot_cluster_nodes"
            )
            run_step([*job_cmd, "--only", prepare_tasks])
            run_step(
                [
                    "databricks",
                    "bundle",
                    "run",
                    "network_monitor_sdp",
                    "-t",
                    cfg.target,
                    "--profile",
                    cfg.profile,
                    "--full-refresh-all",
                ]
            )

        if cfg.run_initial_job or cold_genie_bootstrap_needed:
            run_step(job_cmd)
            job_ran = not dry_run

        if cold_genie_bootstrap_needed:
            run_step(deploy_cmd)
    except RuntimeError as exc:
        if not cold_genie_bootstrap_needed:
            raise
        # The first failure may not have been a cold schema after all, so show it too
        raise RuntimeError(
            "Bundle deploy failed on the Genie Space, and the cold-schema bootstrap (run "
            "network_monitor_job, then deploy again) failed too.\n"
            f"First deploy ({' '.join(deploy_cmd)}):\n{deploy_output}\n\n{exc}"
        ) from exc

    # 6. Fetch bundle summary (resource URLs)
    summary_res = run_step(
        ["databricks", "bundle", "summary", "-t", cfg.target, "--profile", cfg.profile]
    )

    return {
        "status": "dry_run" if dry_run else "deployed",
        "target": cfg.target,
        "profile": cfg.profile,
        "job_ran": job_ran,
        "pipeline_full_refreshed": cfg.full_refresh and not dry_run,
        "cold_genie_bootstrapped": cold_genie_bootstrap_needed,
        "bundle_vars": cfg.bundle_vars,
        "alert_subscriptions": alert_subscriptions,
        "variable_overrides_path": str(overrides_path),
        "summary": summary_res.stdout.strip(),
        "executed_commands": executed_commands,
    }
