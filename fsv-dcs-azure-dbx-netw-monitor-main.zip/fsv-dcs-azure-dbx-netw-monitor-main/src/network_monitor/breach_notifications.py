"""Breach notification bookkeeping so every newly detected breach is emailed once.

After each pipeline refresh, network_monitor_job records breaches it has not seen before (one
row per 5-minute window x workspace x cluster x job run) in breach_notifications, evaluates the
SQL alert over the rows not yet reported (the notify_new_breaches alert task), and then stamps
notified_at on them. The alert's own schedule stays paused, so the job is its only evaluator.
"""

from __future__ import annotations

from typing import Any

from network_monitor.semantic_layer import validate_uc_identifier

BREACH_DETECTION_LOOKBACK_HOURS: int = 24
# A starting cluster is first sighted a few minutes after its first (boot) traffic, which stays
# UNATTRIBUTED until then. Holding UNATTRIBUTED breaches this long lets the sighting claim the
# window first, so the breach is emailed once, as its job run's, rather than twice.
UNATTRIBUTED_BREACH_HOLD_MINUTES: int = 15
# The alert email's result table shows at most 100 rows, so each alert evaluation reports, and
# mark_breaches_notified marks, at most this many pending breaches, oldest detections first.
ALERT_EMAIL_MAX_BREACHES: int = 100
PENDING_BREACH_REPORT_ORDER: str = "detected_at, window_start, workspace_id, cluster_id, run_id"


def build_breach_notifications_ddl(catalog: str, schema: str) -> str:
    """Build the CREATE TABLE IF NOT EXISTS DDL for the breach_notifications Delta table."""
    cat = validate_uc_identifier(catalog, "catalog")
    sch = validate_uc_identifier(schema, "schema")
    return f"""
CREATE TABLE IF NOT EXISTS {cat}.{sch}.breach_notifications (
  window_start TIMESTAMP COMMENT 'UTC start of the breaching 5-minute window',
  window_end TIMESTAMP COMMENT 'UTC end of the breaching 5-minute window',
  workspace_id STRING COMMENT 'Databricks workspace ID',
  cluster_id STRING COMMENT 'Classic compute cluster ID, or UNATTRIBUTED',
  attribution_category STRING COMMENT 'MONITORED, SHARED, or UNATTRIBUTED when first detected',
  job_id BIGINT COMMENT 'Breaching job ID (NULL for SHARED or UNATTRIBUTED windows)',
  run_id BIGINT COMMENT 'Breaching job run ID (NULL for SHARED or UNATTRIBUTED windows)',
  job_name STRING COMMENT 'Job name, shared job list, or cluster name',
  avg_mbps DOUBLE COMMENT '5-minute average bandwidth in decimal Mbps when first detected',
  threshold_mbps DOUBLE COMMENT 'Breach threshold in decimal Mbps',
  bytes_sent BIGINT COMMENT 'Bytes sent by the cluster in the window when first detected',
  bytes_received BIGINT COMMENT 'Bytes received by the cluster in the window when first detected',
  top_remote_peer_ip STRING COMMENT 'Remote peer IP with the most bytes in the window',
  detected_at TIMESTAMP COMMENT 'UTC time the job first recorded this breach',
  notified_at TIMESTAMP COMMENT 'UTC time the alert evaluation reporting this breach completed'
) USING DELTA
COMMENT 'One row per newly detected bandwidth breach; rows with NULL notified_at are pending.'
""".strip()


def build_record_new_breaches_sql(
    catalog: str,
    schema: str,
    *,
    lookback_hours: int = BREACH_DETECTION_LOOKBACK_HOURS,
    unattributed_hold_minutes: int = UNATTRIBUTED_BREACH_HOLD_MINUTES,
) -> str:
    """Build the MERGE that records job_bandwidth_5m breaches not seen before.

    A breach is keyed by (window_start, workspace_id, cluster_id, run_id), so a window whose
    attribution later resolves to a specific job run is reported again with that run. Only
    windows ending within lookback_hours are considered, so a first deployment over historical
    flow logs does not email the whole history. UNATTRIBUTED breaches are recorded only once
    their window ended unattributed_hold_minutes ago.
    """
    cat = validate_uc_identifier(catalog, "catalog")
    sch = validate_uc_identifier(schema, "schema")
    hours = max(1, int(lookback_hours))
    hold = max(0, int(unattributed_hold_minutes))
    return f"""
MERGE INTO {cat}.{sch}.breach_notifications AS t
USING (
  SELECT
    window_start,
    window_end,
    workspace_id,
    cluster_id,
    attribution_category,
    job_id,
    run_id,
    job_name,
    avg_mbps,
    threshold_mbps,
    bytes_sent,
    bytes_received,
    top_remote_peer_ip
  FROM {cat}.{sch}.job_bandwidth_5m
  WHERE is_breach = true
    AND window_end >= current_timestamp() - INTERVAL {hours} HOURS
    AND (
      attribution_category <> 'UNATTRIBUTED'
      OR window_end <= current_timestamp() - INTERVAL {hold} MINUTES
    )
) AS s
ON t.window_start = s.window_start
  AND t.workspace_id = s.workspace_id
  AND t.cluster_id = s.cluster_id
  AND t.run_id <=> s.run_id
WHEN NOT MATCHED THEN INSERT (
  window_start,
  window_end,
  workspace_id,
  cluster_id,
  attribution_category,
  job_id,
  run_id,
  job_name,
  avg_mbps,
  threshold_mbps,
  bytes_sent,
  bytes_received,
  top_remote_peer_ip,
  detected_at,
  notified_at
) VALUES (
  s.window_start,
  s.window_end,
  s.workspace_id,
  s.cluster_id,
  s.attribution_category,
  s.job_id,
  s.run_id,
  s.job_name,
  s.avg_mbps,
  s.threshold_mbps,
  s.bytes_sent,
  s.bytes_received,
  s.top_remote_peer_ip,
  current_timestamp(),
  CAST(NULL AS TIMESTAMP)
)
""".strip()


def build_mark_breaches_notified_sql(catalog: str, schema: str) -> str:
    """Build the MERGE that stamps notified_at on the pending breaches the alert just reported.

    The alert reports the first ALERT_EMAIL_MAX_BREACHES pending breaches in
    PENDING_BREACH_REPORT_ORDER, a total order over the breach key. This selects the same rows,
    so any others stay pending and are reported by the next run.
    """
    cat = validate_uc_identifier(catalog, "catalog")
    sch = validate_uc_identifier(schema, "schema")
    return f"""
MERGE INTO {cat}.{sch}.breach_notifications AS t
USING (
  SELECT window_start, workspace_id, cluster_id, run_id
  FROM {cat}.{sch}.breach_notifications
  WHERE notified_at IS NULL
  ORDER BY {PENDING_BREACH_REPORT_ORDER}
  LIMIT {ALERT_EMAIL_MAX_BREACHES}
) AS s
ON t.window_start = s.window_start
  AND t.workspace_id = s.workspace_id
  AND t.cluster_id = s.cluster_id
  AND t.run_id <=> s.run_id
WHEN MATCHED THEN UPDATE SET notified_at = current_timestamp()
""".strip()


def record_new_breaches(
    spark_session: Any,
    *,
    catalog: str,
    schema: str,
    lookback_hours: int = BREACH_DETECTION_LOOKBACK_HOURS,
) -> dict[str, str]:
    """Ensure breach_notifications exists and record breaches not seen before as pending."""
    spark_session.sql(build_breach_notifications_ddl(catalog, schema))
    spark_session.sql(build_record_new_breaches_sql(catalog, schema, lookback_hours=lookback_hours))
    return {"action": "record", "table": f"{catalog}.{schema}.breach_notifications"}


def mark_breaches_notified(spark_session: Any, *, catalog: str, schema: str) -> dict[str, str]:
    """Mark the pending breaches notified once the alert evaluation that reported them succeeded.

    Runs only after the alert task succeeds and, with max_concurrent_runs = 1, nothing can record
    new breaches in between, so it marks exactly the rows of the evaluated alert result.
    """
    spark_session.sql(build_breach_notifications_ddl(catalog, schema))
    spark_session.sql(build_mark_breaches_notified_sql(catalog, schema))
    return {"action": "mark-notified", "table": f"{catalog}.{schema}.breach_notifications"}
