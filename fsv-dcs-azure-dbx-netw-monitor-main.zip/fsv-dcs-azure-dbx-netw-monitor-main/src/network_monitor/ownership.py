"""Compute ownership resolution from live Databricks Clusters and Jobs API snapshots.

Resolves both VM NIC host_private_ip and container private_ip addresses for classic
compute drivers and workers so VNet Flow Log 5-tuples join cleanly to clusters and jobs.
snapshot_cluster_nodes persists each cycle's sightings into
${catalog}.${schema}.live_cluster_node_snapshots so historical windows remain attributed after
ephemeral job clusters terminate. Sightings are collapsed into tenure and run windows
(resolve_cluster_node_runs_df) that never overlap when Azure reassigns a freed IP to another
cluster's VM. UC system tables are not used: on Azure, system.compute.node_timeline identifies
nodes by VM ID, not by the private IPs that VNet Flow Logs record.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any

from network_monitor.flow_utils import (
    OWNERSHIP_GRACE_MINUTES,
    NodeOwnershipWindow,
    lookback_cutoff_sql,
    sql_expr,
)

CLUSTER_NODE_RUNS_SPARK_DDL: str = (
    "workspace_id STRING, "
    "cluster_id STRING, "
    "node_ip STRING, "
    "run_id BIGINT, "
    "node_role STRING, "
    "job_id BIGINT, "
    "task_run_id BIGINT, "
    "job_name STRING, "
    "observed_start TIMESTAMP, "
    "observed_end TIMESTAMP, "
    "source STRING"
)

ACTIVE_CLUSTER_STATES: frozenset[str] = frozenset(
    {"RUNNING", "RESIZING", "RESTARTING", "PENDING", "TERMINATING"}
)
# A node's VM sends traffic, such as the runtime image and library downloads, before the API
# reports the node started, so a tenure reaches back this far (never before its cluster started).
NODE_BOOT_ALLOWANCE_MINUTES: int = 5


@dataclass(frozen=True, slots=True)
class ActiveRunBinding:
    """Association between an active Lakeflow job/task run and a classic compute cluster."""

    cluster_id: str
    job_id: int
    run_id: int
    task_run_id: int | None
    job_name: str | None
    start_time: datetime | None


def _get_field(obj: Any, name: str, default: Any = None) -> Any:
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def _epoch_ms_to_utc(epoch_ms: Any) -> datetime | None:
    if epoch_ms is None:
        return None
    try:
        val = int(epoch_ms)
    except (TypeError, ValueError):
        return None
    if val <= 0:
        return None
    if val < 100_000_000_000:
        val *= 1000
    return datetime.fromtimestamp(val / 1000.0, tz=UTC)


def _normalize_state_name(state_obj: Any) -> str:
    if state_obj is None:
        return ""
    value = getattr(state_obj, "value", None)
    if isinstance(value, str):
        return value.upper()
    return str(state_obj).split(".")[-1].upper()


def _extract_node_ips(node_obj: Any) -> tuple[str, ...]:
    """Extract distinct non-empty IPv4 addresses from both host_private_ip and private_ip."""
    ips: list[str] = []
    for field_name in ("host_private_ip", "private_ip"):
        raw = _get_field(node_obj, field_name)
        if isinstance(raw, str):
            cleaned = raw.strip()
            if cleaned and cleaned not in ips:
                ips.append(cleaned)
    return tuple(ips)


def _extract_active_run_bindings(runs: Iterable[Any]) -> dict[str, list[ActiveRunBinding]]:
    """Map cluster_id -> active job/task run bindings from jobs.list_runs(expand_tasks=True)."""
    by_cluster: dict[str, list[ActiveRunBinding]] = defaultdict(list)

    for run in runs:
        job_id_raw = _get_field(run, "job_id")
        run_id_raw = _get_field(run, "run_id")
        if job_id_raw is None or run_id_raw is None:
            continue
        try:
            job_id = int(job_id_raw)
            run_id = int(run_id_raw)
        except (TypeError, ValueError):
            continue

        run_name_raw = _get_field(run, "run_name")
        job_name = str(run_name_raw).strip() if run_name_raw else f"job-{job_id}"
        run_start = _epoch_ms_to_utc(_get_field(run, "start_time"))

        seen_cluster_tasks: set[tuple[str, int | None]] = set()
        tasks = _get_field(run, "tasks") or ()
        if isinstance(tasks, Iterable):
            for task in tasks:
                task_cluster_inst = _get_field(task, "cluster_instance")
                task_cluster_id = _get_field(task_cluster_inst, "cluster_id") or _get_field(
                    task, "existing_cluster_id"
                )
                if not isinstance(task_cluster_id, str) or not task_cluster_id.strip():
                    continue
                cluster_id = task_cluster_id.strip()
                task_run_raw = _get_field(task, "run_id")
                task_run_id: int | None = None
                if task_run_raw is not None:
                    try:
                        task_run_id = int(task_run_raw)
                    except (TypeError, ValueError):
                        task_run_id = None
                dedup_key = (cluster_id, task_run_id)
                if dedup_key in seen_cluster_tasks:
                    continue
                seen_cluster_tasks.add(dedup_key)
                task_start = _epoch_ms_to_utc(_get_field(task, "start_time")) or run_start
                by_cluster[cluster_id].append(
                    ActiveRunBinding(
                        cluster_id=cluster_id,
                        job_id=job_id,
                        run_id=run_id,
                        task_run_id=task_run_id,
                        job_name=job_name,
                        start_time=task_start,
                    )
                )

        run_cluster_inst = _get_field(run, "cluster_instance")
        run_cluster_id = _get_field(run_cluster_inst, "cluster_id")
        if isinstance(run_cluster_id, str) and run_cluster_id.strip():
            cluster_id = run_cluster_id.strip()
            if not any(cid == cluster_id for cid, _ in seen_cluster_tasks):
                by_cluster[cluster_id].append(
                    ActiveRunBinding(
                        cluster_id=cluster_id,
                        job_id=job_id,
                        run_id=run_id,
                        task_run_id=None,
                        job_name=job_name,
                        start_time=run_start,
                    )
                )

    return by_cluster


def collect_live_cluster_node_runs(
    workspace_client: Any = None,
    *,
    workspace_id: str | None = None,
    snapshot_time: datetime | None = None,
) -> list[NodeOwnershipWindow]:
    """Poll live Databricks Clusters and Jobs APIs for dual-IP node sightings at snapshot time.

    Emits one cluster-level row (job_id None) per node IP spanning [node boot start, snapshot] and
    one row per active run on the cluster spanning [max(run start, node boot start), snapshot].
    The boot start is NODE_BOOT_ALLOWANCE_MINUTES before the node's reported start, but never
    before the cluster's start; resolve_cluster_node_runs_df adds the post-sighting grace period.
    """
    now_utc = (
        snapshot_time.astimezone(UTC)
        if snapshot_time is not None and snapshot_time.tzinfo is not None
        else (snapshot_time.replace(tzinfo=UTC) if snapshot_time is not None else datetime.now(UTC))
    )

    if workspace_client is None:
        from databricks.sdk import WorkspaceClient

        workspace_client = WorkspaceClient()

    resolved_ws_id = workspace_id
    if not resolved_ws_id:
        get_ws_id = getattr(workspace_client, "get_workspace_id", None)
        if callable(get_ws_id):
            try:
                resolved_ws_id = str(get_ws_id())
            except Exception:
                resolved_ws_id = None
    final_ws_id = str(resolved_ws_id).strip() if resolved_ws_id else "LIVE_WORKSPACE"

    runs_api = getattr(workspace_client, "jobs", None)
    raw_runs: Iterable[Any] = ()
    if runs_api is not None and hasattr(runs_api, "list_runs"):
        raw_runs = runs_api.list_runs(active_only=True, expand_tasks=True)
    run_bindings_by_cluster = _extract_active_run_bindings(raw_runs)

    clusters_api = getattr(workspace_client, "clusters", None)
    raw_clusters: Iterable[Any] = ()
    if clusters_api is not None and hasattr(clusters_api, "list"):
        raw_clusters = _list_active_clusters(clusters_api)

    records: list[NodeOwnershipWindow] = []
    for cluster in raw_clusters:
        cluster_id_raw = _get_field(cluster, "cluster_id")
        if not isinstance(cluster_id_raw, str) or not cluster_id_raw.strip():
            continue
        cluster_id = cluster_id_raw.strip()

        # A terminated cluster can still list stale node IPs; sighting it would extend its tenure
        # over whichever cluster now holds those IPs.
        state_name = _normalize_state_name(_get_field(cluster, "state"))
        if state_name and state_name not in ACTIVE_CLUSTER_STATES:
            continue
        driver_node = _get_field(cluster, "driver")
        executor_nodes = _get_field(cluster, "executors") or ()

        cluster_name_raw = _get_field(cluster, "cluster_name")
        cluster_name = (
            str(cluster_name_raw).strip() if cluster_name_raw else f"cluster-{cluster_id}"
        )
        cluster_start = _epoch_ms_to_utc(_get_field(cluster, "start_time"))

        role_nodes: list[tuple[str, Any]] = []
        if driver_node is not None:
            role_nodes.append(("DRIVER", driver_node))
        if isinstance(executor_nodes, Iterable):
            for exec_node in executor_nodes:
                if exec_node is not None:
                    role_nodes.append(("WORKER", exec_node))

        # Collect distinct (node_ip, node_role, node_start)
        node_entries: dict[str, tuple[str, datetime | None]] = {}
        for role, node_obj in role_nodes:
            node_start = _epoch_ms_to_utc(_get_field(node_obj, "start_timestamp"))
            for ip_addr in _extract_node_ips(node_obj):
                if ip_addr not in node_entries:
                    node_entries[ip_addr] = (role, node_start)

        if not node_entries:
            continue

        bindings = run_bindings_by_cluster.get(cluster_id, [])
        for ip_addr, (node_role, node_start) in sorted(node_entries.items()):
            # Count the node's boot traffic toward its cluster and runs; resolution keeps the
            # earlier start from reaching before the IP's previous owner was last seen
            boot_start = node_start
            if node_start is not None and cluster_start is not None:
                boot_floor = node_start - timedelta(minutes=NODE_BOOT_ALLOWANCE_MINUTES)
                boot_start = min(node_start, max(cluster_start, boot_floor))
            tenure_start = min(boot_start or cluster_start or now_utc, now_utc)
            records.append(
                NodeOwnershipWindow(
                    workspace_id=final_ws_id,
                    cluster_id=cluster_id,
                    node_ip=ip_addr,
                    run_id=0,
                    job_id=None,
                    job_name=cluster_name,
                    observed_start=tenure_start,
                    observed_end=now_utc,
                    node_role=node_role,
                    task_run_id=None,
                    source="LIVE_API",
                )
            )
            for binding in bindings:
                # A node added by autoscaling only carries the run from the node's own start.
                run_start = max(binding.start_time or tenure_start, tenure_start)
                records.append(
                    NodeOwnershipWindow(
                        workspace_id=final_ws_id,
                        cluster_id=cluster_id,
                        node_ip=ip_addr,
                        run_id=binding.run_id,
                        job_id=binding.job_id,
                        job_name=binding.job_name or cluster_name,
                        observed_start=min(run_start, now_utc),
                        observed_end=now_utc,
                        node_role=node_role,
                        task_run_id=binding.task_run_id,
                        source="LIVE_API",
                    )
                )

    return records


def _list_active_clusters(clusters_api: Any) -> Iterable[Any]:
    """List only active clusters, filtered server-side.

    Unfiltered, the API also returns every cluster terminated in the last 30 days, which is
    thousands of pages in a busy job workspace. SDKs that predate the server-side filter fall
    back to the full list; the state check in collect_live_cluster_node_runs still applies.
    """
    clusters: Iterable[Any]
    try:
        from databricks.sdk.service.compute import ListClustersFilterBy, State
    except ImportError:
        clusters = clusters_api.list()
        return clusters
    states = [State(name) for name in sorted(ACTIVE_CLUSTER_STATES)]
    clusters = clusters_api.list(filter_by=ListClustersFilterBy(cluster_states=states))
    return clusters


def ownership_rows_to_dicts(rows: Iterable[NodeOwnershipWindow]) -> list[dict[str, Any]]:
    """Serialize NodeOwnershipWindow objects into Spark DataFrame row dictionaries."""
    return [
        {
            "workspace_id": r.workspace_id,
            "cluster_id": r.cluster_id,
            "node_ip": r.node_ip,
            "run_id": int(r.run_id),
            "node_role": r.node_role,
            "job_id": int(r.job_id) if r.job_id is not None else None,
            "task_run_id": int(r.task_run_id) if r.task_run_id is not None else None,
            "job_name": r.job_name,
            "observed_start": r.observed_start,
            "observed_end": r.observed_end,
            "source": r.source,
        }
        for r in rows
    ]


def resolve_cluster_node_runs_df(
    sightings_df: Any,
    *,
    grace_minutes: int = OWNERSHIP_GRACE_MINUTES,
) -> Any:
    """Collapse node sightings into tenure and run windows that never overlap across IP reuse.

    Spark twin of flow_utils.resolve_ownership_windows (keep the two in sync): owners of an IP
    are ordered by their first sighting. Each (cluster, node IP) tenure spans its earliest
    sighting start, but never before the previous owner's last sighting, to its last sighting
    plus the grace, trimmed at the next owner's start. Each run on it is trimmed the same way at
    a later run's start when that run began after this one was last seen.
    """
    grace = f"INTERVAL {max(0, int(grace_minutes))} MINUTES"
    owner_order = "PARTITION BY workspace_id, node_ip ORDER BY first_seen, cluster_id"
    tenures = (
        sightings_df.groupBy("workspace_id", "cluster_id", "node_ip")
        .agg(
            sql_expr("MIN(observed_start) AS earliest_start"),
            sql_expr("MIN(observed_end) AS first_seen"),
            sql_expr("MAX(observed_end) AS last_seen"),
            sql_expr("MAX(node_role) AS node_role"),
            sql_expr("MAX(CASE WHEN job_id IS NULL THEN job_name END) AS cluster_name"),
            sql_expr("MAX(source) AS source"),
        )
        .selectExpr(
            "*",
            f"LAG(last_seen) OVER ({owner_order}) AS previous_owner_last_seen",
        )
        .selectExpr(
            "*",
            "LEAST(GREATEST(earliest_start, COALESCE(previous_owner_last_seen, earliest_start)), "
            "first_seen) AS tenure_start",
        )
        .selectExpr(
            "*",
            f"LEAD(tenure_start) OVER ({owner_order}) AS next_owner_start",
        )
        .selectExpr(
            "workspace_id",
            "cluster_id",
            "node_ip",
            "node_role",
            "cluster_name",
            "source",
            "tenure_start",
            f"CASE WHEN next_owner_start IS NULL THEN last_seen + {grace} "
            f"ELSE LEAST(last_seen + {grace}, GREATEST(last_seen, next_owner_start)) "
            "END AS tenure_end",
        )
    )
    runs = (
        sightings_df.where("job_id IS NOT NULL")
        .groupBy("workspace_id", "cluster_id", "node_ip", "run_id", "job_id")
        .agg(
            sql_expr("MIN(observed_start) AS run_start"),
            sql_expr("MAX(observed_end) AS run_last_seen"),
            sql_expr("MAX(task_run_id) AS task_run_id"),
            sql_expr("MAX(job_name) AS job_name"),
        )
        .selectExpr(
            "*",
            "LEAD(run_start) OVER (PARTITION BY workspace_id, cluster_id, node_ip "
            "ORDER BY run_start, run_id) AS next_run_start",
        )
    )
    tenure_rows = tenures.selectExpr(
        "workspace_id",
        "cluster_id",
        "node_ip",
        "CAST(0 AS BIGINT) AS run_id",
        "node_role",
        "CAST(NULL AS BIGINT) AS job_id",
        "CAST(NULL AS BIGINT) AS task_run_id",
        "COALESCE(cluster_name, CONCAT('cluster-', cluster_id)) AS job_name",
        "tenure_start AS observed_start",
        "tenure_end AS observed_end",
        "source",
    )
    run_rows = (
        runs.alias("r")
        .join(tenures.alias("t"), on=["workspace_id", "cluster_id", "node_ip"], how="inner")
        .selectExpr(
            "workspace_id",
            "cluster_id",
            "node_ip",
            "r.run_id AS run_id",
            "t.node_role AS node_role",
            "r.job_id AS job_id",
            "r.task_run_id AS task_run_id",
            "r.job_name AS job_name",
            "GREATEST(r.run_start, t.tenure_start) AS observed_start",
            f"LEAST(r.run_last_seen + {grace}, t.tenure_end, "
            "CASE WHEN r.next_run_start > r.run_last_seen THEN r.next_run_start END) "
            "AS observed_end",
            "t.source AS source",
        )
    )
    return tenure_rows.unionByName(run_rows)


def build_cluster_node_runs_df(
    spark_session: Any,
    *,
    catalog: str,
    schema: str,
    is_int_test: bool = False,
    lookback_hours: int = 24,
) -> Any:
    """Build the SDP @dlt.table('cluster_node_runs') target from persisted node sightings.

    Reads the sightings snapshot_cluster_nodes appended before the refresh (or the int-test
    synthetic rows) that can still own flow events in the lookback window, and resolves them
    into tenure and run windows. It makes no API calls and has no fallbacks: the source table
    exists before every refresh, so a failed read is a real error and fails the update.
    """
    source_table = (
        f"{catalog}.{schema}.synthetic_cluster_node_runs"
        if is_int_test
        else f"{catalog}.{schema}.live_cluster_node_snapshots"
    )
    default_source = "SYNTHETIC" if is_int_test else "LIVE_API"
    # One extra hour keeps sightings whose post-sighting grace still reaches into the window.
    sightings_df = (
        spark_session.read.table(source_table)
        .where(f"observed_end >= {lookback_cutoff_sql(lookback_hours + 1)}")
        .selectExpr(
            "CAST(workspace_id AS STRING) AS workspace_id",
            "CAST(cluster_id AS STRING) AS cluster_id",
            "CAST(node_ip AS STRING) AS node_ip",
            "CAST(COALESCE(run_id, 0) AS BIGINT) AS run_id",
            "CAST(COALESCE(node_role, 'WORKER') AS STRING) AS node_role",
            "CAST(job_id AS BIGINT) AS job_id",
            "CAST(task_run_id AS BIGINT) AS task_run_id",
            "CAST(job_name AS STRING) AS job_name",
            "CAST(observed_start AS TIMESTAMP) AS observed_start",
            "CAST(observed_end AS TIMESTAMP) AS observed_end",
            f"CAST(COALESCE(source, '{default_source}') AS STRING) AS source",
        )
    )
    return resolve_cluster_node_runs_df(sightings_df)
