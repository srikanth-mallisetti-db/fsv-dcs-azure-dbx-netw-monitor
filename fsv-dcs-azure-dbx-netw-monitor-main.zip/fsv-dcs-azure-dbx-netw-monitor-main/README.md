# Azure Databricks Network Bandwidth Monitor (DAB + Serverless SDP)

Near-real-time network bandwidth monitoring, job attribution, conversational analytics, and threshold alerting for Azure Databricks classic compute—packaged as a **Databricks Asset Bundle (DAB)** using **Lakeflow Spark Declarative Pipelines (SDP)** on **Serverless compute**.

## Overview

When a classic compute job in an injected Azure VNet consumes excessive network bandwidth—whether reading/writing against internal ADLS Gen2 Private Endpoints or external 3rd-party data sources—it can saturate shared network appliances or storage limits and cause concurrent Lakeflow jobs to fail.

This bundle deploys:

1. **Serverless Lakeflow Spark Declarative Pipeline (`network_monitor_sdp`):**
   - Reads Azure Network Watcher **VNet Flow Logs (Schema v4)** from Unity Catalog storage via Serverless Network Connectivity Configurations (NCC), imposing **zero network load** on the monitored customer VNet.
   - Filters out **intra-cluster Spark shuffle** (`Driver <-> Worker` and `Worker <-> Worker` traffic inside the configured classic compute subnets) while retaining traffic to/from internal Private Endpoints (e.g., ADLS Gen2) and external endpoints.
   - Automatically creates and manages the 4 core pipeline tables: `flow_events_clean` (via **SDP Auto CDC SCD Type 1** to deduplicate hourly `PT1H.json` append/overwrite blobs), `flow_event_deltas` (removing the counters a re-created flow's next report repeats, so no byte is counted twice), `cluster_node_runs` (resolving the Clusters and Jobs API sightings of `host_private_ip` & container `private_ip` persisted in `live_cluster_node_snapshots` into node tenure and job-run windows), and `job_bandwidth_5m` (attributing 5-minute directional bandwidth `bytes_sent`, `bytes_received`, and `avg_mbps` to active clusters and Lakeflow jobs over a rolling `lookback_hours` window).
2. **Lakeflow Orchestration Job (`network_monitor_job`):**
   - Scheduled every 5 minutes (`0 */5 * * * ?` UTC, controlled by `schedule_pause_status`). Each run first snapshots every active classic compute node through the Clusters and Jobs APIs (running as a workspace admin), prepares the `job_exceptions` and `live_cluster_node_snapshots` tables, and applies retention. It then triggers the SDP pipeline (`network_monitor_sdp`), publishes the Unity Catalog Metric View (`job_bandwidth_metrics_v`), records newly detected breaches in `breach_notifications`, and evaluates the SQL Alert through a job alert task so **each new breach is emailed once**. A failed run emails the same recipients.
   - Includes a self-contained **`int-test` bundle target** (`is_int_test = "true"`) that populates synthetic VNet Flow Log v4 files into a managed Unity Catalog Volume so the entire pipeline can be tested end-to-end without Azure network dependencies.
3. **Native DAB Genie Space, AI/BI Lakeview Dashboard & Databricks SQL Alert:**
   - Declaratively provisions a **Databricks Genie Space** (`resources.genie_spaces`), a 4-panel **AI/BI Lakeview Dashboard** (`resources.dashboards`), and a **Databricks SQL Alert** (`resources.alerts`) that `network_monitor_job` evaluates after every refresh to email each newly detected non-exempt breach to the configured recipients (`alert_email_recipients` / `alert_notification_destination_ids`).

## Documentation Index

Follow these guides in order:

| Document | Purpose |
| :--- | :--- |
| [1. Azure VNet Flow Logs Prerequisite](docs/vnet-flow-logs-prerequisite.md) | Why VNet Flow Logs (Schema v4) are required and how Serverless SDP + NCC consumes them with zero VNet overhead |
| [2. Architecture & System Design](docs/architecture.md) | Subnet boundary rules, directional byte normalization, Auto CDC ingestion, and workflow orchestration |
| [3. Data Model, Semantic Layer, Dashboard & Alert](docs/data-model.md) | Schemas for `flow_events_clean`, `flow_event_deltas`, `cluster_node_runs`, `live_cluster_node_snapshots`, `job_exceptions`, `job_bandwidth_5m`, UC Metric View (`job_bandwidth_metrics_v`), Genie Space, Lakeview Dashboard, and SQL Alert |
| [4. Local Setup & One-Shot Deployment Guide (Windows & macOS)](docs/setup-and-deployment.md) | The standard 4-step workflow (**Windows PowerShell** and **macOS / POSIX**): `venv` setup, static analysis, `pytest` with coverage, and one-shot JSON deployment (`scripts/deploy.py`) |
| [5. Testing & Validation Guide (`int-test` & Live Target)](docs/testing.md) | Offline `pytest` with coverage, self-contained `int-test` synthetic UC Volume target, and live VNet Flow Log validation |

Code layout, conventions, and change rules for developers and AI coding agents are in [AGENTS.md](AGENTS.md).

## Standard 4-Step Developer & Deployment Workflow

Every developer or automation agent only needs to execute four steps from the repository root:

### Windows PowerShell

```powershell
# 1. Create venv & install dependencies (pip.local.ini: set index-url to your approved package index)
Copy-Item pip.ini.example pip.local.ini
notepad pip.local.ini
$env:PIP_CONFIG_FILE = Join-Path (Get-Location) 'pip.local.ini'
$env:PYTHONUTF8 = '1'
py -3.14 -m venv .venv
$FsvPython = Join-Path (Get-Location) '.venv\Scripts\python.exe'
& $FsvPython -m pip install --no-user --upgrade pip
& $FsvPython -m pip install --no-user -r requirements-dev.txt
& $FsvPython -m pip check

# 2. Run type checking & Ruff linting/formatting (tests excluded)
& $FsvPython -m mypy src scripts
& $FsvPython -m ruff check src scripts
& $FsvPython -m ruff format --check src scripts

# 3. Run unit & contract tests with coverage
& $FsvPython -m pytest

# 4. Copy a deployment JSON template (int-test, dev, or prod) and run one-shot deploy
Copy-Item configs\deploy.int-test.example.json configs\deploy.int-test.local.json
# Edit configs\deploy.int-test.local.json with your profile, catalog, warehouse_id, and alert_email_recipients
# (set "deploy_genie_space": false for a Databricks CLI older than v1.3.0; v1.19.0 or later deploys everything)
& $FsvPython scripts\deploy.py --config configs\deploy.int-test.local.json
# Optional: remove everything the deployment created (see the setup guide, Section 4.4)
# & $FsvPython scripts\deploy.py --config configs\deploy.int-test.local.json --destroy
```

### macOS / Linux (`zsh` / `bash`)

```bash
# 1. Create venv & install dependencies (pip.local.ini: set index-url to your approved package index)
cp pip.ini.example pip.local.ini
export PIP_CONFIG_FILE="$PWD/pip.local.ini"
export PYTHONUTF8=1
python3.14 -m venv .venv
.venv/bin/python -m pip install --no-user --upgrade pip
.venv/bin/python -m pip install --no-user -r requirements-dev.txt
.venv/bin/python -m pip check

# 2. Run type checking & Ruff linting/formatting (tests excluded)
.venv/bin/mypy src scripts
.venv/bin/ruff check src scripts
.venv/bin/ruff format --check src scripts

# 3. Run unit & contract tests with coverage
.venv/bin/pytest

# 4. Copy a deployment JSON template (int-test, dev, or prod) and run one-shot deploy
cp configs/deploy.int-test.example.json configs/deploy.int-test.local.json
# Edit configs/deploy.int-test.local.json with your profile, catalog, warehouse_id, and alert_email_recipients
# (set "deploy_genie_space": false for a Databricks CLI older than v1.3.0; v1.19.0 or later deploys everything)
.venv/bin/python scripts/deploy.py --config configs/deploy.int-test.local.json
# Optional: remove everything the deployment created (see the setup guide, Section 4.4)
# .venv/bin/python scripts/deploy.py --config configs/deploy.int-test.local.json --destroy
```
