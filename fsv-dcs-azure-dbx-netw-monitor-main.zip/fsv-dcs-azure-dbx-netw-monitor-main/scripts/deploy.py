"""CLI entrypoint for one-shot JSON-driven deployment of the Databricks Asset Bundle.

Usage:
    python scripts/deploy.py --config configs/deploy.dev.local.json
    python scripts/deploy.py --config configs/deploy.int-test.local.json
    python scripts/deploy.py --config configs/deploy.prod.local.json --validate-only
    python scripts/deploy.py --config configs/deploy.int-test.local.json --destroy
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from network_monitor.deployer import execute_deployment, load_deployment_config  # noqa: E402


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "One-shot JSON-driven validator and deployer for the Azure Databricks "
            "Network Bandwidth Monitor bundle (supports dev, prod, and int-test targets)."
        )
    )
    parser.add_argument(
        "--config",
        required=True,
        type=Path,
        help="Path to the deployment parameters JSON file.",
    )
    parser.add_argument(
        "--profile",
        default=None,
        help="Optional override for the Databricks CLI profile name.",
    )
    parser.add_argument(
        "--target",
        choices=("dev", "prod", "int-test"),
        default=None,
        help="Optional override for the bundle target (dev, prod, or int-test).",
    )
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--validate-only",
        action="store_true",
        help=(
            "Run 'databricks bundle validate' only, without changing the workspace (no schema "
            "creation or deployment)."
        ),
    )
    mode.add_argument(
        "--destroy",
        action="store_true",
        help=(
            "Remove everything the bundle deployed for the target ('databricks bundle destroy "
            "--auto-approve' with this config's variables); for int-test this includes its "
            "schema and data."
        ),
    )
    parser.add_argument(
        "--skip-job-run",
        action="store_true",
        help="Skip running 'network_monitor_job' after deploying.",
    )
    parser.add_argument(
        "--full-refresh",
        action="store_true",
        help=(
            "Reset and recompute the pipeline tables after deploying (re-ingests every flow log "
            "still in storage, from flow_log_start_after when set); needed after changing the "
            "subnet CIDRs or flow-log targets."
        ),
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print the resolved configuration and CLI commands without executing them.",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        cfg = load_deployment_config(
            args.config,
            profile_override=args.profile,
            target_override=args.target,
            skip_job_run=args.skip_job_run,
            full_refresh_override=True if args.full_refresh else None,
        )
        result = execute_deployment(
            cfg,
            validate_only=args.validate_only,
            destroy=args.destroy,
            dry_run=args.dry_run,
            bundle_root=ROOT,
        )
    except (OSError, RuntimeError, ValueError) as exc:
        # Configuration and deployment errors are for operators: print the message, not a
        # Python traceback
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    # Warnings (such as breach alerting left out for an older CLI) also go to stderr, so they are
    # seen even when the JSON result is captured
    for warning in result.get("warnings", []):
        print(f"WARNING: {warning}", file=sys.stderr)
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
