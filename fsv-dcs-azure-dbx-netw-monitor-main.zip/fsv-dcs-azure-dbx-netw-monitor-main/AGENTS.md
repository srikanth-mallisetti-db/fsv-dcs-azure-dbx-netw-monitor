# AGENTS.md

Instructions for AI coding agents and developers working in this repository. Read this before changing code, configuration, or documentation.

## What This Repository Is

A Databricks Asset Bundle that measures Azure Databricks classic compute network bandwidth from Azure VNet Flow Logs (schema v4) and attributes it to clusters and Lakeflow job runs. Start with `README.md`, then `docs/architecture.md` and `docs/data-model.md`.

| Path | Contents |
| :--- | :--- |
| `databricks.yml` | Bundle definition: variables and the `dev`, `int-test`, and `prod` targets |
| `resources/*.yml` | Pipeline, job, Genie space, dashboard, and alert resources |
| `src/network_monitor/flow_utils.py` | Flow-tuple parsing, CIDR classification, Spark SQL expression builders, and a pure-Python reference model of the ownership-window and attribution logic |
| `src/network_monitor/ownership.py` | Cluster and job ownership from Clusters and Jobs API sightings, resolved into non-overlapping windows in Spark |
| `src/network_monitor/node_snapshots.py` | Per-cycle task that prepares the monitor tables, applies retention, and records live API sightings (the only place the APIs are polled) |
| `src/network_monitor/pipeline/flow_ingestion_sdp.py` | Lakeflow Spark Declarative Pipeline definition |
| `src/network_monitor/breach_notifications.py` | Records each new breach and marks it notified around the job's SQL alert task |
| `src/network_monitor/semantic_layer.py`, `src/network_monitor/tasks/` | Job task entry points (node snapshots, metric view, exemptions table, breach notifications, `int-test` data) |
| `src/network_monitor/synthetic.py` | Synthetic flow logs and ownership rows for the `int-test` target |
| `src/network_monitor/deployer.py`, `scripts/deploy.py` | One-shot JSON-driven deployment |
| `src/network_monitor/dashboard/` | AI/BI dashboard definition (`.lvdash.json`) |
| `configs/*.example.json` | Deployment config templates; real configs are `*.local.json` and git-ignored |
| `requirements-dev.txt`, `pip.ini.example` | Pinned local development dependencies, and the template for the git-ignored `pip.local.ini` (package index; no `--user` installs) |
| `tests/` | Offline unit and contract tests |

## Verify Every Change

Run from the repository root. All checks must pass before you hand work back. Environment setup is Step 1 of `docs/setup-and-deployment.md`.

**macOS / Linux:**

```bash
.venv/bin/mypy src scripts
.venv/bin/ruff check src scripts
.venv/bin/ruff format --check src scripts
.venv/bin/pytest
```

**Windows PowerShell:**

```powershell
$FsvPython = Join-Path (Get-Location) '.venv\Scripts\python.exe'
& $FsvPython -m mypy src scripts
& $FsvPython -m ruff check src scripts
& $FsvPython -m ruff format --check src scripts
& $FsvPython -m pytest
```

## Conventions

- Develop with Python 3.14 (3.12 also works). `mypy --strict` and ruff (line length 100) apply to `src/` and `scripts/` and check against Python 3.11, the job tasks' runtime (serverless environment version 2): use `from __future__ import annotations`, complete type hints, and nothing newer than Python 3.11.
- Use frozen, slotted dataclasses for value objects. Pin development dependencies in `requirements-dev.txt`. Code that runs in the job or the pipeline can import only packages preinstalled on serverless compute, so prefer the standard library and `databricks-sdk`.
- Spark logic uses Spark SQL expressions and the DataFrame API, not Python UDFs. When you change attribution or classification logic, change the Spark/SQL code and the pure-Python reference model in `flow_utils.py` together, and cover both in tests.
- Validate every catalog, schema, or other identifier interpolated into SQL (see `validate_uc_identifier` in `semantic_layer.py`).
- Tests run fully offline: no Spark, network, or Databricks credentials; use the fakes in `tests/`. They must pass on Windows and macOS/Linux from a plain copy of the source with no git metadata, so use `pathlib`, compare paths with `as_posix()`, read and write text as UTF-8, and do not shell out to `git`.
- New configuration: declare the variable in `databricks.yml`, wire it through `deployer.py` (scalar values via `BUNDLE_VAR_KEYS`; lists and objects as complex variables written to `variable-overrides.json`), and update `configs/*.example.json`, `docs/setup-and-deployment.md`, and the tests.
- Update the docs in the same change as the behavior they describe.

## Guardrails

- Never commit `*.local.json`, `.databricks/`, credentials or tokens, workspace URLs or IDs, or real email addresses.
- Do not run `scripts/deploy.py` or `databricks bundle deploy`, `run`, or `destroy` against a workspace unless the user explicitly asks. Use `--dry-run` or `--validate-only` to check changes.
- `job_exceptions` holds operator-approved exemptions. Only the `int-test` target may write to it; never truncate or overwrite it anywhere else.
- Call out any change to the `prod` target, its schedules, or alert behavior explicitly.
- The breach alert is evaluated only by `network_monitor_job` (`notify_new_breaches`). Keep the alert's own schedule `PAUSED`; a second evaluator would email the same breaches twice.
- Keep the breach-alerting tasks between the `# BEGIN breach alerting` and `# END breach alerting` markers in `resources/network_monitor_job.yml`. For a Databricks CLI that cannot deploy `alert_task`, `scripts/deploy.py` deploys a staged copy of the bundle without them and without `resources/network_monitor_alert.yml`. It also leaves out `resources/network_monitor_genie.yml` when `deploy_genie_space` is `false` or the CLI cannot deploy Genie spaces.
