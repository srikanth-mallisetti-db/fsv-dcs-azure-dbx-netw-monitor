"""Unit tests for breach notification bookkeeping (record, alert, mark-notified)."""

from __future__ import annotations

import pytest

from network_monitor.breach_notifications import (
    ALERT_EMAIL_MAX_BREACHES,
    PENDING_BREACH_REPORT_ORDER,
    UNATTRIBUTED_BREACH_HOLD_MINUTES,
    build_breach_notifications_ddl,
    build_mark_breaches_notified_sql,
    build_record_new_breaches_sql,
)
from network_monitor.tasks.track_breach_notifications import main as run_breach_task_cli


def test_breach_notification_sql_builders() -> None:
    ddl = build_breach_notifications_ddl("main", "network_monitor")
    assert ddl.startswith("CREATE TABLE IF NOT EXISTS main.network_monitor.breach_notifications")
    for column in (
        "window_start TIMESTAMP",
        "workspace_id STRING",
        "cluster_id STRING",
        "run_id BIGINT",
        "avg_mbps DOUBLE",
        "detected_at TIMESTAMP",
        "notified_at TIMESTAMP",
    ):
        assert column in ddl
    assert "USING DELTA" in ddl

    merge = build_record_new_breaches_sql("main", "network_monitor", lookback_hours=6)
    assert merge.startswith("MERGE INTO main.network_monitor.breach_notifications AS t")
    assert "FROM main.network_monitor.job_bandwidth_5m" in merge
    assert "WHERE is_breach = true" in merge
    assert "INTERVAL 6 HOURS" in merge
    # One notification per (window, workspace, cluster, run); NULL runs match null-safely
    assert "t.window_start = s.window_start" in merge
    assert "t.workspace_id = s.workspace_id" in merge
    assert "t.cluster_id = s.cluster_id" in merge
    assert "t.run_id <=> s.run_id" in merge
    # Already-recorded breaches are never updated or re-queued
    assert "WHEN NOT MATCHED THEN INSERT" in merge
    assert "WHEN MATCHED" not in merge
    assert "CAST(NULL AS TIMESTAMP)" in merge
    assert "INTERVAL 1 HOURS" in build_record_new_breaches_sql("main", "nm", lookback_hours=0)
    # UNATTRIBUTED breaches wait until a starting cluster's first sighting can claim the window,
    # so they are emailed once, as the job run's breach; attributed breaches are never held
    hold_clause = (
        "AND (\n"
        "      attribution_category <> 'UNATTRIBUTED'\n"
        "      OR window_end <= current_timestamp() - INTERVAL {} MINUTES\n"
        "    )"
    )
    assert hold_clause.format(UNATTRIBUTED_BREACH_HOLD_MINUTES) in merge
    assert UNATTRIBUTED_BREACH_HOLD_MINUTES == 15
    assert hold_clause.format(0) in build_record_new_breaches_sql(
        "main", "nm", unattributed_hold_minutes=-5
    )

    mark = build_mark_breaches_notified_sql("main", "network_monitor")
    assert mark.startswith("MERGE INTO main.network_monitor.breach_notifications AS t")
    # Marks exactly the page of pending breaches the alert reported: same order, same limit,
    # over a total order of the breach key, so the rest stay pending for the next run
    assert "WHERE notified_at IS NULL" in mark
    assert f"ORDER BY {PENDING_BREACH_REPORT_ORDER}\n  LIMIT {ALERT_EMAIL_MAX_BREACHES}\n" in mark
    for key in ("window_start", "workspace_id", "cluster_id", "run_id"):
        assert key in PENDING_BREACH_REPORT_ORDER
    assert "t.run_id <=> s.run_id" in mark
    assert mark.endswith("WHEN MATCHED THEN UPDATE SET notified_at = current_timestamp()")

    with pytest.raises(ValueError, match="Invalid Unity Catalog"):
        build_record_new_breaches_sql("main; DROP TABLE x", "network_monitor")
    with pytest.raises(ValueError, match="Invalid Unity Catalog"):
        build_mark_breaches_notified_sql("main", "network monitor")


def test_track_breach_notifications_task_cli() -> None:
    executed: list[str] = []

    class FakeSpark:
        @staticmethod
        def sql(query: str) -> None:
            executed.append(query)

    recorded = run_breach_task_cli(
        ["--catalog", "main", "--schema", "nm", "--action", "record"],
        spark_session=FakeSpark(),
    )
    assert recorded == {"action": "record", "table": "main.nm.breach_notifications"}
    assert executed[0].startswith("CREATE TABLE IF NOT EXISTS main.nm.breach_notifications")
    assert executed[1].startswith("MERGE INTO main.nm.breach_notifications")
    assert "INTERVAL 24 HOURS" in executed[1]

    executed.clear()
    marked = run_breach_task_cli(
        ["--catalog", "main", "--schema", "nm", "--action", "mark-notified"],
        spark_session=FakeSpark(),
    )
    assert marked == {"action": "mark-notified", "table": "main.nm.breach_notifications"}
    assert executed[-1].startswith("MERGE INTO main.nm.breach_notifications AS t")

    with pytest.raises(SystemExit):
        run_breach_task_cli(
            ["--catalog", "main", "--schema", "nm", "--action", "purge"],
            spark_session=FakeSpark(),
        )
