"""Unit tests for live Databricks REST API + UC System Table compute ownership resolution."""

from __future__ import annotations

import sys
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from network_monitor.flow_utils import (
    CleanFlowEvent,
    JobExceptionRule,
    NodeOwnershipWindow,
    attribute_window_records,
    resolve_ownership_windows,
)
from network_monitor.ownership import (
    build_cluster_node_runs_df,
    collect_live_cluster_node_runs,
    resolve_cluster_node_runs_df,
)


def at(hour: int, minute: int, second: int = 0) -> datetime:
    return datetime(2026, 10, 22, hour, minute, second, tzinfo=UTC)


def epoch_ms(ts: datetime) -> int:
    return int(ts.timestamp() * 1000)


def flow_event(event_id: str, event_time: datetime, node_ip: str, nbytes: int) -> CleanFlowEvent:
    return CleanFlowEvent(
        event_id=event_id,
        event_time=event_time,
        local_node_ip=node_ip,
        remote_peer_ip="20.60.194.131",
        local_port=50000,
        remote_port=443,
        protocol=6,
        flow_direction="O",
        flow_state="C",
        traffic_scope="EXTERNAL",
        bytes_sent=0,
        bytes_received=nbytes,
        source_file="memory://PT1H.json",
        state_priority=1,
        file_mod_time=event_time,
    )


class LineageFrame:
    """Records every DataFrame operation so tests can inspect the Spark plan offline."""

    def __init__(self, label: str, op: str = "", parents: tuple[LineageFrame, ...] = ()) -> None:
        self.label = label
        self.op = op
        self.parents = parents

    def _derive(self, op: str, *others: LineageFrame) -> LineageFrame:
        return LineageFrame(self.label, op, (self, *others))

    def selectExpr(self, *exprs: str) -> LineageFrame:
        return self._derive("selectExpr: " + " | ".join(exprs))

    def where(self, condition: str) -> LineageFrame:
        return self._derive(f"where: {condition}")

    def groupBy(self, *cols: str) -> LineageFrame:
        return self._derive("groupBy: " + ",".join(cols))

    def agg(self, *exprs: Any) -> LineageFrame:
        return self._derive("agg: " + " | ".join(str(expr) for expr in exprs))

    def alias(self, name: str) -> LineageFrame:
        return self._derive(f"alias: {name}")

    def join(self, other: LineageFrame, *, on: Any, how: str) -> LineageFrame:
        return self._derive(f"join: {on} {how}", other)

    def unionByName(self, other: LineageFrame) -> LineageFrame:
        return self._derive("unionByName", other)

    def lineage(self) -> list[LineageFrame]:
        seen: set[int] = set()
        stack: list[LineageFrame] = [self]
        frames: list[LineageFrame] = []
        while stack:
            frame = stack.pop()
            if id(frame) not in seen:
                seen.add(id(frame))
                frames.append(frame)
                stack.extend(frame.parents)
        return frames

    def sources(self) -> set[str]:
        return {frame.label for frame in self.lineage() if not frame.parents}

    def plan(self) -> str:
        return "\n".join(frame.op for frame in self.lineage())


@dataclass
class FakeNode:
    private_ip: str | None = None
    host_private_ip: str | None = None
    start_timestamp: int | None = None


@dataclass
class FakeCluster:
    cluster_id: str
    cluster_name: str
    state: str
    driver: FakeNode | None
    executors: list[FakeNode]
    start_time: int | None = None


@dataclass
class FakeClusterInstance:
    cluster_id: str | None = None


@dataclass
class FakeRunTask:
    run_id: int
    cluster_instance: FakeClusterInstance | None = None
    existing_cluster_id: str | None = None
    start_time: int | None = None


@dataclass
class FakeRun:
    job_id: int
    run_id: int
    run_name: str
    start_time: int | None = None
    cluster_instance: FakeClusterInstance | None = None
    tasks: list[FakeRunTask] | None = None


class FakeClustersApi:
    def __init__(self, clusters: list[FakeCluster]) -> None:
        self._clusters = clusters
        self.filter_by: Any = None

    def list(self, *, filter_by: Any = None) -> list[FakeCluster]:
        # Returns every cluster regardless of the filter, so the client-side state check is
        # still exercised.
        self.filter_by = filter_by
        return self._clusters


@dataclass
class FakeGroup:
    display: str


@dataclass
class FakeMe:
    user_name: str
    groups: list[FakeGroup]


class FakeCurrentUserApi:
    def __init__(self, groups: list[str]) -> None:
        self._groups = groups

    def me(self) -> FakeMe:
        return FakeMe(user_name="monitor-sp", groups=[FakeGroup(g) for g in self._groups])


class FakeJobsApi:
    def __init__(self, runs: list[FakeRun]) -> None:
        self._runs = runs

    def list_runs(self, *, active_only: bool = False, expand_tasks: bool = False) -> list[FakeRun]:
        assert active_only is True
        assert expand_tasks is True
        return self._runs


class FakeWorkspaceClient:
    def __init__(
        self,
        clusters: list[FakeCluster],
        runs: list[FakeRun],
        groups: tuple[str, ...] = ("admins", "users"),
    ) -> None:
        self.clusters = FakeClustersApi(clusters)
        self.jobs = FakeJobsApi(runs)
        self.current_user = FakeCurrentUserApi(list(groups))

    @staticmethod
    def get_workspace_id() -> int:
        return 1234567890123456


def test_collect_live_cluster_node_runs_extracts_dual_ips_and_task_bindings() -> None:
    snap_time = datetime(2026, 10, 21, 12, 10, 0, tzinfo=UTC)
    start_ms = int(datetime(2026, 10, 21, 12, 0, 0, tzinfo=UTC).timestamp() * 1000)

    clusters = [
        FakeCluster(
            cluster_id="0101-jobcluster",
            cluster_name="job-101-cluster",
            state="RUNNING",
            driver=FakeNode(
                host_private_ip="10.0.1.4",
                private_ip="10.0.65.4",
                start_timestamp=start_ms,
            ),
            executors=[
                FakeNode(
                    host_private_ip="10.0.1.5",
                    private_ip="10.0.65.5",
                    start_timestamp=start_ms,
                ),
            ],
            start_time=start_ms,
        ),
        FakeCluster(
            cluster_id="0202-interactive",
            cluster_name="interactive-analytics",
            state="RUNNING",
            driver=FakeNode(
                host_private_ip="10.0.2.10",
                private_ip="10.0.2.10",
                start_timestamp=start_ms,
            ),
            executors=[],
            start_time=start_ms,
        ),
    ]

    runs = [
        FakeRun(
            job_id=101,
            run_id=1001,
            run_name="settlement-ingest",
            start_time=start_ms,
            tasks=[
                FakeRunTask(
                    run_id=9001,
                    cluster_instance=FakeClusterInstance(cluster_id="0101-jobcluster"),
                    start_time=start_ms,
                )
            ],
        )
    ]

    client = FakeWorkspaceClient(clusters=clusters, runs=runs)
    records = collect_live_cluster_node_runs(client, snapshot_time=snap_time)

    # Every node IP gets a cluster-level tenure row (job_id None); the 4 job-cluster IPs also get
    # a run row, so 5 tenure rows + 4 run rows
    assert len(records) == 9
    tenure_keys = {(r.cluster_id, r.node_ip) for r in records if r.job_id is None}
    assert tenure_keys == {
        ("0101-jobcluster", "10.0.1.4"),
        ("0101-jobcluster", "10.0.65.4"),
        ("0101-jobcluster", "10.0.1.5"),
        ("0101-jobcluster", "10.0.65.5"),
        ("0202-interactive", "10.0.2.10"),
    }

    job_ips = {r.node_ip: r for r in records if r.job_id is not None}
    assert set(job_ips.keys()) == {"10.0.1.4", "10.0.65.4", "10.0.1.5", "10.0.65.5"}
    assert job_ips["10.0.1.4"].node_role == "DRIVER"
    assert job_ips["10.0.65.4"].node_role == "DRIVER"
    assert job_ips["10.0.1.5"].node_role == "WORKER"
    assert job_ips["10.0.1.4"].job_id == 101
    assert job_ips["10.0.1.4"].run_id == 1001
    assert job_ips["10.0.1.4"].task_run_id == 9001
    assert job_ips["10.0.1.4"].workspace_id == "1234567890123456"
    assert job_ips["10.0.1.4"].source == "LIVE_API"

    # Sightings are exact: [node or run start, snapshot time], never padded
    assert all(r.observed_start == datetime(2026, 10, 21, 12, 0, tzinfo=UTC) for r in records)
    assert all(r.observed_end == snap_time for r in records)

    interactive_rows = [r for r in records if r.cluster_id == "0202-interactive"]
    assert len(interactive_rows) == 1
    assert interactive_rows[0].node_ip == "10.0.2.10"
    assert interactive_rows[0].job_id is None
    assert interactive_rows[0].run_id == 0


def test_collect_live_cluster_node_runs_uses_exact_starts_and_skips_terminated_clusters() -> None:
    snap_time = at(12, 10)
    clusters = [
        # Node started 2 minutes before the snapshot: its window must not reach back further
        FakeCluster(
            cluster_id="0303-fresh",
            cluster_name="fresh-cluster",
            state="RUNNING",
            driver=FakeNode(host_private_ip="10.0.3.4", start_timestamp=epoch_ms(at(12, 8))),
            executors=[],
        ),
        # Worker added by autoscaling after its run started: the run window starts at the node
        FakeCluster(
            cluster_id="0404-autoscaled",
            cluster_name="autoscaled-cluster",
            state="RESIZING",
            driver=None,
            executors=[FakeNode(host_private_ip="10.0.4.9", start_timestamp=epoch_ms(at(12, 5)))],
        ),
        # Terminated cluster still listing a stale IP (now reused by 0303-fresh): not sighted
        FakeCluster(
            cluster_id="0505-terminated",
            cluster_name="terminated-cluster",
            state="TERMINATED",
            driver=FakeNode(host_private_ip="10.0.3.4", start_timestamp=epoch_ms(at(11, 0))),
            executors=[],
        ),
    ]
    runs = [
        FakeRun(
            job_id=404,
            run_id=4004,
            run_name="autoscaled-job",
            start_time=epoch_ms(at(11, 30)),
            cluster_instance=FakeClusterInstance(cluster_id="0404-autoscaled"),
        )
    ]
    records = collect_live_cluster_node_runs(
        FakeWorkspaceClient(clusters=clusters, runs=runs), snapshot_time=snap_time
    )
    by_key = {(r.cluster_id, r.job_id): r for r in records}

    assert {r.cluster_id for r in records} == {"0303-fresh", "0404-autoscaled"}
    assert by_key[("0303-fresh", None)].observed_start == at(12, 8)
    assert by_key[("0404-autoscaled", None)].observed_start == at(12, 5)
    assert by_key[("0404-autoscaled", 404)].observed_start == at(12, 5)
    assert all(r.observed_end == snap_time for r in records)


def test_resolved_windows_stop_ip_reuse_double_counting_and_false_shared() -> None:
    def sighting(
        snapshot: datetime,
        cluster_id: str,
        node_ip: str,
        node_start: datetime,
        runs: list[tuple[int, int, datetime]],
    ) -> list[NodeOwnershipWindow]:
        cluster = FakeCluster(
            cluster_id=cluster_id,
            cluster_name=cluster_id,
            state="RUNNING",
            driver=FakeNode(host_private_ip=node_ip, start_timestamp=epoch_ms(node_start)),
            executors=[],
        )
        fake_runs = [
            FakeRun(
                job_id=job_id,
                run_id=run_id,
                run_name=f"job-{job_id}",
                start_time=epoch_ms(run_start),
                cluster_instance=FakeClusterInstance(cluster_id=cluster_id),
            )
            for job_id, run_id, run_start in runs
        ]
        return collect_live_cluster_node_runs(
            FakeWorkspaceClient(clusters=[cluster], runs=fake_runs), snapshot_time=snapshot
        )

    # 1. Job cluster A holds 10.0.0.4 until ~10:16; job cluster B reuses it from 10:22
    reuse_rows = [
        *sighting(at(10, 5), "cluster-A", "10.0.0.4", at(10, 0), [(111, 1, at(10, 0))]),
        *sighting(at(10, 10), "cluster-A", "10.0.0.4", at(10, 0), [(111, 1, at(10, 0))]),
        *sighting(at(10, 15), "cluster-A", "10.0.0.4", at(10, 0), [(111, 1, at(10, 0))]),
        *sighting(at(10, 25), "cluster-B", "10.0.0.4", at(10, 22), [(222, 2, at(10, 22))]),
    ]
    resolved = resolve_ownership_windows(reuse_rows)
    tenures = {r.cluster_id: r for r in resolved if r.job_id is None}
    assert (tenures["cluster-A"].observed_start, tenures["cluster-A"].observed_end) == (
        at(10, 0),
        at(10, 20),
    )
    assert tenures["cluster-B"].observed_start == at(10, 22)

    events = [
        flow_event("a-1", at(10, 12), "10.0.0.4", 1_500_000_000),
        flow_event("b-1", at(10, 24), "10.0.0.4", 1_500_000_000),
    ]
    windows = attribute_window_records(events, resolved, threshold_mbps=100.0)
    assert [(w.window_start, w.cluster_id, w.job_id) for w in windows] == [
        (at(10, 10), "cluster-A", 111),
        (at(10, 20), "cluster-B", 222),
    ]
    assert sum(w.total_bytes for w in windows) == 3_000_000_000

    # A reuse inside cluster A's grace period trims A's window at B's start
    tight_rows = [
        *reuse_rows[:6],
        *sighting(at(10, 20), "cluster-B", "10.0.0.4", at(10, 17), [(222, 2, at(10, 17))]),
    ]
    tight = resolve_ownership_windows(tight_rows)
    assert {r.cluster_id: r.observed_end for r in tight if r.job_id is None}["cluster-A"] == at(
        10, 17
    )
    tight_windows = attribute_window_records(
        [flow_event("b-2", at(10, 18), "10.0.0.4", 30_000_000)], tight, threshold_mbps=100.0
    )
    assert [(w.cluster_id, w.job_id) for w in tight_windows] == [("cluster-B", 222)]

    # 2. All-purpose cluster runs exempt job 300 until ~10:10, then job 400 from 10:11
    sequential_rows = [
        *sighting(at(10, 0), "allpurpose-1", "10.0.0.9", at(9, 0), [(300, 30, at(9, 30))]),
        *sighting(at(10, 5), "allpurpose-1", "10.0.0.9", at(9, 0), [(300, 30, at(9, 30))]),
        *sighting(at(10, 12), "allpurpose-1", "10.0.0.9", at(9, 0), [(400, 40, at(10, 11))]),
    ]
    exempt = [JobExceptionRule("1234567890123456", 300, "exempt-job", "approved", "ops", at(0, 0))]
    sequential = attribute_window_records(
        [
            flow_event("e-1", at(10, 7), "10.0.0.9", 4_500_000_000),
            flow_event("e-2", at(10, 10, 30), "10.0.0.9", 10_000_000),
        ],
        resolve_ownership_windows(sequential_rows),
        exempt,
        threshold_mbps=100.0,
    )
    by_window = {w.window_start: w for w in sequential}
    assert by_window[at(10, 5)].attribution_category == "EXEMPT"
    assert by_window[at(10, 5)].candidate_job_ids == (300,)
    assert by_window[at(10, 5)].is_breach is False
    # Traffic between the two runs stays attributed to the cluster rather than a job
    assert by_window[at(10, 10)].cluster_id == "allpurpose-1"
    assert by_window[at(10, 10)].attribution_category == "UNATTRIBUTED"

    # 3. Runs observed together on one cluster are still SHARED
    concurrent_rows = [
        *sighting(
            at(10, 0), "shared-1", "10.0.0.7", at(9, 0), [(501, 51, at(9, 30)), (502, 52, at(9, 45))]
        ),
        *sighting(
            at(10, 5), "shared-1", "10.0.0.7", at(9, 0), [(501, 51, at(9, 30)), (502, 52, at(9, 45))]
        ),
    ]
    shared = attribute_window_records(
        [flow_event("s-1", at(10, 3), "10.0.0.7", 30_000_000)],
        resolve_ownership_windows(concurrent_rows),
        threshold_mbps=100.0,
    )
    assert [(w.attribution_category, w.candidate_job_ids) for w in shared] == [
        ("SHARED", (501, 502))
    ]


def test_boot_traffic_counts_toward_the_job_without_claiming_a_reused_ip() -> None:
    def job_cluster_sighting(
        snapshot: datetime,
        cluster_id: str,
        node_ip: str,
        *,
        cluster_start: datetime,
        node_start: datetime,
        job_id: int,
        run_id: int,
    ) -> list[NodeOwnershipWindow]:
        cluster = FakeCluster(
            cluster_id=cluster_id,
            cluster_name=cluster_id,
            state="RUNNING",
            driver=FakeNode(host_private_ip=node_ip, start_timestamp=epoch_ms(node_start)),
            executors=[],
            start_time=epoch_ms(cluster_start),
        )
        run = FakeRun(
            job_id=job_id,
            run_id=run_id,
            run_name=f"job-{job_id}",
            start_time=epoch_ms(cluster_start),
            cluster_instance=FakeClusterInstance(cluster_id=cluster_id),
        )
        return collect_live_cluster_node_runs(
            FakeWorkspaceClient(clusters=[cluster], runs=[run]), snapshot_time=snapshot
        )

    # As in the live validation: the job cluster was created at 13:48:58, its VM downloaded the
    # runtime from 13:50:38, and the API reported the node started at 13:51:55
    first = job_cluster_sighting(
        at(13, 59, 31),
        "job-cluster-1",
        "10.0.0.5",
        cluster_start=at(13, 48, 58),
        node_start=at(13, 51, 55),
        job_id=101,
        run_id=1001,
    )
    assert {r.observed_start for r in first} == {at(13, 48, 58)}
    boot = attribute_window_records(
        [flow_event("boot", at(13, 50, 38), "10.0.0.5", 4_000_000_000)],
        resolve_ownership_windows(first),
        threshold_mbps=100.0,
    )
    assert [(w.attribution_category, w.job_id, w.run_id) for w in boot] == [
        ("MONITORED", 101, 1001)
    ]

    # The allowance is bounded: a node added two hours later reaches back only 5 minutes
    added = job_cluster_sighting(
        at(16, 0),
        "job-cluster-1",
        "10.0.0.9",
        cluster_start=at(13, 48, 58),
        node_start=at(15, 50),
        job_id=101,
        run_id=1001,
    )
    assert {r.observed_start for r in added} == {at(15, 45)}

    # On a reused IP the allowance stops at the previous owner's last sighting (15:47): traffic
    # before it stays with the previous owner, traffic after it is the new node's boot. The
    # previous owner's own allowance stops at its cluster's start (15:00)
    previous = job_cluster_sighting(
        at(15, 47),
        "job-cluster-0",
        "10.0.0.9",
        cluster_start=at(15, 0),
        node_start=at(15, 2),
        job_id=100,
        run_id=1000,
    )
    resolved = resolve_ownership_windows([*previous, *added])
    tenures = {r.cluster_id: r for r in resolved if r.job_id is None}
    assert (tenures["job-cluster-0"].observed_start, tenures["job-cluster-0"].observed_end) == (
        at(15, 0),
        at(15, 47),
    )
    assert tenures["job-cluster-1"].observed_start == at(15, 47)
    handover = attribute_window_records(
        [
            flow_event("tail", at(15, 46), "10.0.0.9", 30_000_000),
            flow_event("boot-2", at(15, 48), "10.0.0.9", 30_000_000),
        ],
        resolved,
        threshold_mbps=100.0,
    )
    assert [(w.window_start, w.job_id) for w in handover] == [(at(15, 45), 100), (at(15, 45), 101)]


def test_resolve_cluster_node_runs_df_trims_grace_at_next_owner_and_next_run() -> None:
    plan = resolve_cluster_node_runs_df(LineageFrame("sightings"), grace_minutes=5).plan()

    assert "groupBy: workspace_id,cluster_id,node_ip" in plan
    assert "groupBy: workspace_id,cluster_id,node_ip,run_id,job_id" in plan
    # Owners of an IP are ordered by first sighting, and a (boot-allowance) start never reaches
    # before the previous owner's last sighting
    owner_order = "PARTITION BY workspace_id, node_ip ORDER BY first_seen, cluster_id"
    assert f"LAG(last_seen) OVER ({owner_order}) AS previous_owner_last_seen" in plan
    assert (
        "LEAST(GREATEST(earliest_start, COALESCE(previous_owner_last_seen, earliest_start)), "
        "first_seen) AS tenure_start"
    ) in plan
    assert f"LEAD(tenure_start) OVER ({owner_order}) AS next_owner_start" in plan
    assert (
        "LEAD(run_start) OVER (PARTITION BY workspace_id, cluster_id, node_ip "
        "ORDER BY run_start, run_id) AS next_run_start"
    ) in plan
    assert (
        "LEAST(last_seen + INTERVAL 5 MINUTES, GREATEST(last_seen, next_owner_start))"
    ) in plan
    assert "CASE WHEN r.next_run_start > r.run_last_seen THEN r.next_run_start END" in plan
    assert "GREATEST(r.run_start, t.tenure_start) AS observed_start" in plan
    assert "join: ['workspace_id', 'cluster_id', 'node_ip'] inner" in plan
    assert "INTERVAL 0 MINUTES" in resolve_cluster_node_runs_df(
        LineageFrame("sightings"), grace_minutes=-3
    ).plan()


def test_build_cluster_node_runs_df_reads_bounded_persisted_sightings_only() -> None:
    class FakeRead:
        @staticmethod
        def table(name: str) -> LineageFrame:
            return LineageFrame(label=f"table:{name}")

    class FakeSpark:
        # No createDataFrame or sql: the pipeline must not poll APIs or query system tables
        read = FakeRead()

    # Both modes return resolved windows (tenure rows unioned with run rows), not raw sightings
    int_test_df = build_cluster_node_runs_df(
        FakeSpark(),
        catalog="main",
        schema="network_monitor_int_test",
        is_int_test=True,
    )
    assert int_test_df.sources() == {"table:main.network_monitor_int_test.synthetic_cluster_node_runs"}
    assert int_test_df.op == "unionByName"
    assert "next_owner_start" in int_test_df.plan()

    live_df = build_cluster_node_runs_df(
        FakeSpark(),
        catalog="main",
        schema="network_monitor",
        is_int_test=False,
        lookback_hours=24,
    )
    assert live_df.sources() == {"table:main.network_monitor.live_cluster_node_snapshots"}
    assert live_df.op == "unionByName"
    plan = live_df.plan()
    assert "next_run_start" in plan
    # Only sightings that can still own events in the lookback window (plus a 1-hour margin)
    assert (
        "where: observed_end >= date_trunc('HOUR', current_timestamp()) - INTERVAL 25 HOURS"
    ) in plan
    assert "COALESCE(source, 'LIVE_API')" in plan


def test_collect_live_cluster_node_runs_filters_active_clusters_server_side(
    monkeypatch: Any,
) -> None:
    from databricks.sdk.service.compute import State

    client = FakeWorkspaceClient(clusters=[], runs=[])
    collect_live_cluster_node_runs(client, snapshot_time=at(12, 0))
    assert client.clusters.filter_by is not None
    assert set(client.clusters.filter_by.cluster_states) == {
        State.PENDING,
        State.RESIZING,
        State.RESTARTING,
        State.RUNNING,
        State.TERMINATING,
    }

    # SDKs without the server-side filter fall back to the full list
    monkeypatch.setitem(sys.modules, "databricks.sdk.service.compute", None)
    legacy_client = FakeWorkspaceClient(clusters=[], runs=[])
    collect_live_cluster_node_runs(legacy_client, snapshot_time=at(12, 0))
    assert legacy_client.clusters.filter_by is None
