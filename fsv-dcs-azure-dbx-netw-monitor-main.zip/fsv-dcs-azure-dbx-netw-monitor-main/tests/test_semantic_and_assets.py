"""Unit and contract tests for Phase 4 Semantic Layer, Genie Space, Dashboard, and SQL Alert."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

import pytest

from network_monitor.breach_notifications import (
    ALERT_EMAIL_MAX_BREACHES,
    PENDING_BREACH_REPORT_ORDER,
)
from network_monitor.flow_utils import parse_flow_log_start_after
from network_monitor.semantic_layer import (
    METRIC_VIEW_DIMENSIONS,
    METRIC_VIEW_MEASURES,
    build_job_exceptions_ddl,
    build_metric_view_ddl,
    build_metric_view_yaml,
    publish_semantic_layer,
)
from network_monitor.synthetic import SYNTHETIC_VNET_RESOURCE_ID
from network_monitor.tasks.publish_semantic_layer import main as run_semantic_cli

ROOT = Path(__file__).resolve().parents[1]
WIDGET_NAME_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def test_semantic_layer_ddl_and_cli_execution() -> None:
    ex_ddl = build_job_exceptions_ddl("main", "network_monitor")
    assert "CREATE TABLE IF NOT EXISTS main.network_monitor.job_exceptions" in ex_ddl
    assert "USING DELTA" in ex_ddl

    mv_yaml = build_metric_view_yaml("main", "network_monitor")
    assert "version: 0.1" in mv_yaml
    assert "source: main.network_monitor.job_bandwidth_5m" in mv_yaml
    for dim in METRIC_VIEW_DIMENSIONS:
        assert f"- name: {dim}" in mv_yaml
    for measure in METRIC_VIEW_MEASURES:
        assert f"- name: {measure}" in mv_yaml
    # Volumes are decimal, like the Mbps rates and the threshold
    assert "- name: total_megabytes\n    expr: SUM(total_bytes) / 1000000.0\n" in mv_yaml
    assert "- name: total_gigabytes\n    expr: SUM(total_bytes) / 1000000000.0\n" in mv_yaml

    mv_ddl = build_metric_view_ddl("main", "network_monitor")
    assert "CREATE OR REPLACE VIEW main.network_monitor.job_bandwidth_metrics_v" in mv_ddl
    assert "WITH METRICS" in mv_ddl
    assert "LANGUAGE YAML" in mv_ddl

    with pytest.raises(ValueError, match="Invalid Unity Catalog"):
        build_job_exceptions_ddl("main; DROP TABLE", "network_monitor")

    executed_queries: list[str] = []

    class FakeSpark:
        @staticmethod
        def sql(query: str) -> None:
            executed_queries.append(query)

    summary = publish_semantic_layer(
        FakeSpark(),
        catalog="main",
        schema="network_monitor_int_test",
    )
    assert summary == {
        "catalog": "main",
        "schema": "network_monitor_int_test",
        "exceptions_table": "main.network_monitor_int_test.job_exceptions",
        "metric_view": "main.network_monitor_int_test.job_bandwidth_metrics_v",
    }
    # Snapshots are the snapshot_cluster_nodes task's job, not the semantic layer's
    assert len(executed_queries) == 3
    assert not any("live_cluster_node_snapshots" in q for q in executed_queries)

    cli_summary = run_semantic_cli(
        ["--catalog", "main", "--schema", "network_monitor_int_test"],
        spark_session=FakeSpark(),
    )
    assert cli_summary["metric_view"] == "main.network_monitor_int_test.job_bandwidth_metrics_v"


def test_lakeview_dashboard_json_contract() -> None:
    dash_path = ROOT / "src/network_monitor/dashboard/network_monitor.lvdash.json"
    assert dash_path.is_file()
    dash = json.loads(dash_path.read_text(encoding="utf-8"))

    datasets: dict[str, str] = {}
    for ds in dash["datasets"]:
        name = ds["name"]
        lines: list[str] = ds["queryLines"]
        assert lines, f"Dataset {name} has empty queryLines"
        # Every non-final line must end with whitespace so concatenation never merges SQL tokens
        for idx, line in enumerate(lines[:-1]):
            assert line.endswith(" ") or line.endswith("\n"), (
                f"Dataset {name} line {idx} must end with space/newline: {line!r}"
            )
        joined_sql = "".join(lines)
        assert ";" not in joined_sql
        datasets[name] = joined_sql

    assert set(datasets.keys()) == {
        "ds_kpi_summary",
        "ds_bandwidth_windows",
        "ds_peer_breakdown",
    }
    # Every panel covers the last 24 hours, so KPIs stay meaningful as history accumulates
    for name, sql in datasets.items():
        assert "current_timestamp() - INTERVAL 24 HOURS" in sql, f"{name} is not time-bounded"
        assert "1024" not in sql, f"{name} computes binary units"
    # Peer totals come from flow_event_deltas, so re-created flows' repeated counters are excluded
    assert "FROM flow_event_deltas " in datasets["ds_peer_breakdown"]
    # MB columns are decimal megabytes, like the Mbps rates
    mb_lines = [
        line
        for ds in dash["datasets"]
        for line in ds["queryLines"]
        if re.search(r"\bAS \w+_mb\b", line)
    ]
    assert len(mb_lines) == 10
    for line in mb_lines:
        assert "/ 1000000.0" in line, f"Not decimal megabytes: {line.strip()!r}"

    pages = dash["pages"]
    assert len(pages) == 1
    page = pages[0]
    assert page["pageType"] == "PAGE_TYPE_CANVAS"

    # Verify 6-column grid layout with zero gaps per row band
    row_widths: dict[int, int] = {}
    expected_versions = {
        "counter": 2,
        "table": 2,
        "area": 3,
        "bar": 3,
    }

    for item in page["layout"]:
        widget: dict[str, Any] = item["widget"]
        pos: dict[str, int] = item["position"]
        w_name = widget["name"]
        assert WIDGET_NAME_RE.match(w_name), f"Invalid widget name: {w_name}"

        for r in range(pos["y"], pos["y"] + pos["height"]):
            row_widths[r] = row_widths.get(r, 0) + pos["width"]

        if "multilineTextboxSpec" in widget:
            assert "spec" not in widget
            assert len(widget["multilineTextboxSpec"]["lines"]) == 1
            continue

        spec = widget["spec"]
        w_type = spec["widgetType"]
        assert spec["version"] == expected_versions[w_type]

        queries = widget["queries"]
        assert len(queries) == 1
        q_obj = queries[0]
        assert q_obj["name"] == "main_query"
        ds_name = q_obj["query"]["datasetName"]
        assert ds_name in datasets

        query_field_names = {f["name"] for f in q_obj["query"]["fields"]}
        encodings = spec["encodings"]

        if w_type == "counter":
            assert encodings["value"]["fieldName"] in query_field_names
        elif w_type == "table":
            for col in encodings["columns"]:
                assert col["fieldName"] in query_field_names
                assert set(col.keys()) == {"fieldName", "displayName"}
        else:
            for axis in ("x", "y", "color"):
                if axis in encodings:
                    assert encodings[axis]["fieldName"] in query_field_names

    # Every occupied row from y=0 to y=17 must span exactly 6 columns
    assert set(row_widths.keys()) == set(range(18))
    for r, total_w in row_widths.items():
        assert total_w == 6, f"Row y={r} has total width {total_w}, expected 6"


def test_genie_and_alert_bundle_resources() -> None:
    genie_yml = (ROOT / "resources/network_monitor_genie.yml").read_text(encoding="utf-8")
    assert "genie_spaces:" in genie_yml
    assert "version: 2" in genie_yml

    # Extract table identifiers from genie_spaces YAML and verify ascending sort order
    identifiers = [
        line.split("identifier:", 1)[1].strip()
        for line in genie_yml.splitlines()
        if "identifier:" in line
    ]
    assert len(identifiers) == 6
    assert identifiers == sorted(identifiers)
    assert "${var.catalog}.${var.schema}.breach_notifications" in identifiers
    # Flow-level byte sums come from flow_event_deltas, where re-created flows' repeated
    # counters are removed
    assert "${var.catalog}.${var.schema}.flow_event_deltas" in identifiers
    top_peers_source = "FROM ${var.catalog}.${var.schema}.flow_event_deltas GROUP BY remote_peer_ip"
    assert top_peers_source in genie_yml
    assert "Sum flow-level bytes from flow_event_deltas" in genie_yml
    # Benchmark answers honor the time range their questions ask for
    assert "WHERE is_breach = true AND window_start >= current_date()" in genie_yml
    assert "WHERE window_start >= current_timestamp() - INTERVAL 24 HOURS" in genie_yml
    assert "AND e.effective_from <= b.window_start" in genie_yml
    # Genie answers in the same decimal units as the dashboard and the metric view
    assert "1024" not in genie_yml
    assert "SUM(private_endpoint_bytes) / 1000000.0 AS private_endpoint_mb" in genie_yml
    assert "1 MB = 1,000,000 bytes" in genie_yml

    alert_yml = (ROOT / "resources/network_monitor_alert.yml").read_text(encoding="utf-8")
    assert "alerts:" in alert_yml
    # The alert reports only breaches the job recorded but has not notified yet
    assert "FROM ${var.catalog}.${var.schema}.breach_notifications" in alert_yml
    assert "WHERE notified_at IS NULL" in alert_yml
    # The email lists the pending breaches: no alert-level aggregation collapses them to one
    # value, and the page is the one mark_breaches_notified marks (same order and limit)
    evaluation = alert_yml.split("\n      evaluation:\n", 1)[1]
    assert re.search(r"^\s+aggregation:", evaluation, re.MULTILINE) is None
    # A display label breaks first-row evaluation: the job's alert task then evaluates OK with
    # breaches pending, and no email is ever sent
    source = evaluation.split("\n        source:\n", 1)[1].split("\n        threshold:\n", 1)[0]
    assert source.strip() == "name: avg_mbps"
    assert (
        f"ORDER BY {PENDING_BREACH_REPORT_ORDER}\n          LIMIT {ALERT_EMAIL_MAX_BREACHES}\n"
        in alert_yml
    )
    assert "retrigger_seconds: 1" in alert_yml
    # Breach emails go to the deployment-configured recipients and list the breaching rows
    assert "subscriptions: ${var.alert_subscriptions}" in alert_yml
    assert "{{QUERY_RESULT_TABLE}}" in alert_yml
    # The job is the alert's only evaluator: its own schedule stays PAUSED for every target
    schedule_block = alert_yml.split("\n      schedule:\n", 1)[1]
    assert 'quartz_cron_schedule: "0 */5 * * * ?"' in schedule_block
    assert "pause_status: PAUSED" in schedule_block
    assert "schedule_pause_status" not in alert_yml

    job_yml = (ROOT / "resources/network_monitor_job.yml").read_text(encoding="utf-8")
    tasks = {
        block.split("\n", 1)[0].strip(): block
        for block in job_yml.split("\n        - task_key: ")[1:]
    }
    assert list(tasks) == [
        "snapshot_cluster_nodes",
        "refresh_flow_pipeline",
        "publish_semantic_layer",
        "record_new_breaches",
        "notify_new_breaches",
        "mark_breaches_notified",
    ]
    # Live APIs are polled once per cycle, before the pipeline, which keeps running (ALL_DONE) if
    # the snapshot fails so ingestion and alerting continue while the failed run is reported
    snapshot_task = tasks["snapshot_cluster_nodes"]
    assert "depends_on" not in snapshot_task
    for parameter in ("${var.is_int_test}", "${var.lookback_hours}", "${var.retention_days}"):
        assert f'- "{parameter}"' in snapshot_task
    assert "- task_key: snapshot_cluster_nodes" in tasks["refresh_flow_pipeline"]
    assert "run_if: ALL_DONE" in tasks["refresh_flow_pipeline"]
    assert "- task_key: refresh_flow_pipeline" in tasks["record_new_breaches"]
    assert '- "record"' in tasks["record_new_breaches"]
    notify_task = tasks["notify_new_breaches"]
    assert "- task_key: record_new_breaches" in notify_task
    assert "alert_id: ${resources.alerts.network_monitor_breach_alert.id}" in notify_task
    assert "warehouse_id: ${var.warehouse_id}" in notify_task
    assert "subscribers: ${var.alert_task_subscribers}" in notify_task
    assert "- task_key: notify_new_breaches" in tasks["mark_breaches_notified"]
    assert '- "mark-notified"' in tasks["mark_breaches_notified"]

    # Failed runs (degraded attribution or alerting) notify the alert recipients
    job_settings = job_yml.split("\n      tasks:\n", 1)[0]
    assert "on_failure: ${var.job_failure_emails}" in job_settings
    assert "on_failure: ${var.job_failure_destinations}" in job_settings
    assert "no_alert_for_skipped_runs: true" in job_settings
    # An overrunning run skips the next trigger rather than queueing a backlog of runs
    assert "max_concurrent_runs: 1\n" in job_settings
    assert "\n      queue:\n        enabled: false\n" in job_settings
    assert "no_alert_for_canceled_runs: true" in job_settings

    bundle_yml = (ROOT / "databricks.yml").read_text(encoding="utf-8")
    for var_name in (
        "alert_subscriptions",
        "alert_task_subscribers",
        "job_failure_emails",
        "job_failure_destinations",
    ):
        var_block = re.search(rf"\n  {var_name}:\n((?:    .*\n)+)", bundle_yml)
        assert var_block is not None, f"Missing bundle variable {var_name}"
        assert "type: complex" in var_block.group(1)
        assert "default: []" in var_block.group(1)
    # int-test scopes ingestion to the synthetic VNet so the target filter runs end to end
    int_test_target = re.search(r'\n      flow_log_target_resource_ids: "([^"]+)"', bundle_yml)
    assert int_test_target is not None
    assert int_test_target.group(1).lower() == SYNTHETIC_VNET_RESOURCE_ID.lower()
    pipeline_yml = (ROOT / "resources/network_monitor_pipeline.yml").read_text(encoding="utf-8")
    assert (
        "network_monitor.flow_log_target_resource_ids: ${var.flow_log_target_resource_ids}"
        in pipeline_yml
    )
    # The optional flow-log start reaches Auto Loader, and int-test exercises it end to end
    assert "network_monitor.flow_log_start_after: ${var.flow_log_start_after}" in pipeline_yml
    start_after_var = re.search(r"\n  flow_log_start_after:\n((?:    .*\n)+)", bundle_yml)
    assert start_after_var is not None
    assert 'default: ""' in start_after_var.group(1)
    int_test_start = re.search(r'\n      flow_log_start_after: "([^"]+)"', bundle_yml)
    assert int_test_start is not None
    assert parse_flow_log_start_after(int_test_start.group(1)) == "2000-01-01 00:00:00.000000 UTC+0"
    retention_var = re.search(r"\n  retention_days:\n((?:    .*\n)+)", bundle_yml)
    assert retention_var is not None
    assert 'default: "30"' in retention_var.group(1)
    # int-test generates synthetic data only after the snapshot task has prepared the tables
    int_test_generate = bundle_yml.split("- task_key: generate_synthetic_telemetry", 1)[1]
    assert int_test_generate.split("environment_key", 1)[0].strip() == (
        "depends_on:\n                - task_key: snapshot_cluster_nodes"
    )
