"""Unit tests for VNet Flow Log v4 parsing, CIDR compilation, Auto CDC keys, and attribution."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

import pytest

from network_monitor.flow_utils import (
    JobExceptionRule,
    NodeOwnershipWindow,
    attribute_window_records,
    build_flow_event_deltas_sql,
    build_job_bandwidth_5m_sql,
    build_raw_flow_tuples_sql_projections,
    calculate_avg_mbps,
    compute_event_id,
    correct_recreated_flow_counters,
    deduplicate_flow_events_scd1,
    extract_flow_events_from_document,
    flow_tuple_key,
    ip_in_cidr_ranges_sql,
    ip_in_ranges,
    is_recreated_tuple_sql,
    matches_target_resource,
    parse_cidr_ranges,
    parse_flow_log_start_after,
    parse_flow_tuple,
    parse_target_resource_ids,
    recreation_keys_sql,
    resolve_private_endpoint_ranges,
    target_resource_filter_sql,
)


def test_cidr_compilation_and_optional_private_endpoint_fallback() -> None:
    compute_ranges = parse_cidr_ranges("10.0.0.0/18, 10.0.64.0/18")
    assert len(compute_ranges) == 2
    assert ip_in_ranges("10.0.1.4", compute_ranges) is True
    assert ip_in_ranges("10.0.65.10", compute_ranges) is True
    assert ip_in_ranges("10.0.130.15", compute_ranges) is False
    assert ip_in_ranges("20.50.1.10", compute_ranges) is False

    # When private_endpoint_cidrs is omitted or empty, fall back to RFC 1918 private ranges
    default_pe_ranges = resolve_private_endpoint_ranges("")
    assert len(default_pe_ranges) == 3
    assert ip_in_ranges("10.0.130.15", default_pe_ranges) is True
    assert ip_in_ranges("172.20.5.10", default_pe_ranges) is True
    assert ip_in_ranges("192.168.10.25", default_pe_ranges) is True
    assert ip_in_ranges("20.50.1.10", default_pe_ranges) is False

    # When explicit private_endpoint_cidrs is provided, honor only those CIDRs
    explicit_pe_ranges = resolve_private_endpoint_ranges("10.0.128.0/18")
    assert len(explicit_pe_ranges) == 1
    assert ip_in_ranges("10.0.130.15", explicit_pe_ranges) is True
    assert ip_in_ranges("192.168.10.25", explicit_pe_ranges) is False

    sql_pred = ip_in_cidr_ranges_sql("src_ip", explicit_pe_ranges)
    assert "TRY_CAST(SPLIT_PART(src_ip, '.', 1) AS BIGINT) * 16777216" in sql_pred
    assert "BETWEEN" in sql_pred


def test_parse_flow_tuple_excludes_beginning_and_intra_cluster_shuffle() -> None:
    compute_ranges = parse_cidr_ranges("10.0.0.0/18,10.0.64.0/18")

    # 1. Beginning ('B') state carries no byte deltas -> excluded
    b_tuple = "1729500000,10.0.1.4,20.50.1.10,51234,443,6,O,B,0,0,0,0,0"
    assert (
        parse_flow_tuple(
            b_tuple,
            flow_log_guid="guid-1",
            mac_address="00-0D-3A-11-22-33",
            compute_ranges=compute_ranges,
        )
        is None
    )

    # 2. Intra-cluster Spark shuffle (Host 10.0.1.4 <-> Container 10.0.65.10) -> excluded
    shuffle_tuple = (
        "1729500060,10.0.1.4,10.0.65.10,41000,42000,6,O,C,0,5000,800000000,5000,800000000"
    )
    assert (
        parse_flow_tuple(
            shuffle_tuple,
            flow_log_guid="guid-1",
            mac_address="00-0D-3A-11-22-33",
            compute_ranges=compute_ranges,
        )
        is None
    )

    # 3. Neither endpoint in compute subnets -> excluded
    unrelated_tuple = "1729500060,10.0.130.10,20.50.1.10,50000,443,6,O,C,0,10,1000,10,1000"
    assert (
        parse_flow_tuple(
            unrelated_tuple,
            flow_log_guid="guid-1",
            mac_address="00-0D-3A-11-22-33",
            compute_ranges=compute_ranges,
        )
        is None
    )


def test_parse_flow_tuple_normalizes_direction_and_epoch_formats() -> None:
    compute_ranges = parse_cidr_ranges("10.0.0.0/18,10.0.64.0/18")
    pe_ranges = resolve_private_endpoint_ranges("")

    # Outbound-initiated download from external IP (10-digit second epoch)
    # Cluster node 10.0.1.4 sends 2,048 request bytes and receives 50,000,000 response bytes
    ext_download_tuple = (
        "1729500060,10.0.1.4,20.50.1.10,54321,443,6,O,C,0,20,2048,35000,50000000"
    )
    ev_ext = parse_flow_tuple(
        ext_download_tuple,
        flow_log_guid="guid-ext",
        mac_address="00:0d:3a:aa:bb:cc",
        compute_ranges=compute_ranges,
        private_endpoint_ranges=pe_ranges,
    )
    assert ev_ext is not None
    assert ev_ext.local_node_ip == "10.0.1.4"
    assert ev_ext.remote_peer_ip == "20.50.1.10"
    assert ev_ext.local_port == 54321
    assert ev_ext.remote_port == 443
    assert ev_ext.bytes_sent == 2048
    assert ev_ext.bytes_received == 50_000_000
    assert ev_ext.traffic_scope == "EXTERNAL"
    assert ev_ext.state_priority == 1

    # Tuple recorded with ADLS Private Endpoint (10.0.130.15) as src_ip and cluster node as dest_ip
    # (13-digit millisecond epoch)
    pe_tuple = "1729500120500,10.0.130.15,10.0.1.4,443,54322,6,I,E,0,60000,90000000,100,8192"
    ev_pe = parse_flow_tuple(
        pe_tuple,
        flow_log_guid="guid-pe",
        mac_address="00-0D-3A-AA-BB-CC",
        compute_ranges=compute_ranges,
        private_endpoint_ranges=pe_ranges,
    )
    assert ev_pe is not None
    assert ev_pe.local_node_ip == "10.0.1.4"
    assert ev_pe.remote_peer_ip == "10.0.130.15"
    assert ev_pe.local_port == 54322
    assert ev_pe.remote_port == 443
    assert ev_pe.bytes_sent == 8192
    assert ev_pe.bytes_received == 90_000_000
    assert ev_pe.traffic_scope == "PRIVATE_ENDPOINT"
    assert ev_pe.state_priority == 2


def test_auto_cdc_scd1_deduplication_and_c_to_e_revision() -> None:
    compute_ranges = parse_cidr_ranges("10.0.0.0/18")
    t1 = datetime(2026, 10, 21, 12, 1, 0, tzinfo=UTC)
    t2 = datetime(2026, 10, 21, 12, 2, 0, tzinfo=UTC)

    c_tuple = "1729512060000,10.0.1.5,20.60.1.1,55000,443,6,O,C,0,100,10000,2000,25000000"
    e_tuple = "1729512060000,10.0.1.5,20.60.1.1,55000,443,6,O,E,0,150,15000,3000,40000000"

    ev_c_rev1 = parse_flow_tuple(
        c_tuple,
        flow_log_guid="guid-cdc",
        mac_address="000D3A112233",
        compute_ranges=compute_ranges,
        file_mod_time=t1,
    )
    ev_c_rev2 = parse_flow_tuple(
        c_tuple,
        flow_log_guid="guid-cdc",
        mac_address="000D3A112233",
        compute_ranges=compute_ranges,
        file_mod_time=t2,
    )
    ev_e_rev2 = parse_flow_tuple(
        e_tuple,
        flow_log_guid="guid-cdc",
        mac_address="000D3A112233",
        compute_ranges=compute_ranges,
        file_mod_time=t2,
    )

    assert ev_c_rev1 is not None and ev_c_rev2 is not None and ev_e_rev2 is not None
    assert ev_c_rev1.event_id == ev_e_rev2.event_id == compute_event_id(
        "guid-cdc", "00-0d-3a-11-22-33", 1729512060000, "10.0.1.5", "20.60.1.1", 55000, 443, 6, "O"
    )

    deduped = deduplicate_flow_events_scd1([ev_c_rev1, ev_c_rev2, ev_e_rev2])
    assert len(deduped) == 1
    assert deduped[0].flow_state == "E"
    assert deduped[0].bytes_received == 40_000_000
    assert deduped[0].bytes_sent == 15_000


def test_same_millisecond_b_e_resets_and_all_four_attribution_categories() -> None:
    compute_ranges = parse_cidr_ranges("10.0.0.0/18,10.0.64.0/18")
    pe_ranges = resolve_private_endpoint_ranges("10.0.128.0/18")

    # 5-minute window: 2026-10-21 12:00:00Z -> 12:05:00Z (epoch_ms: 1792584000000)
    win_start = datetime(2026, 10, 21, 12, 0, 0, tzinfo=UTC)
    win_end = datetime(2026, 10, 21, 12, 5, 0, tzinfo=UTC)
    base_ms = int(win_start.timestamp() * 1000)

    flow_tuples = [
        # 1. MONITORED job (node 10.0.1.10) with same-ms B/E reset:
        # 4.5 GB total -> 120.0 Mbps (> 100 Mbps threshold -> BREACH)
        f"{base_ms + 10000},10.0.1.10,20.50.1.99,50001,443,6,O,B,0,0,0,0,0",
        (
            f"{base_ms + 10000},10.0.1.10,20.50.1.99,50001,443,6,O,E,0,"
            "1000,500000000,8000,4000000000"
        ),
        # 2. EXEMPT job (node 10.0.1.20 -> ADLS PE 10.0.130.5):
        # 6.0 GB total -> 160.0 Mbps, but EXEMPT -> is_breach=False
        (
            f"{base_ms + 20000},10.0.1.20,10.0.130.5,50002,443,6,O,C,0,"
            "100,0,12000,6000000000"
        ),
        # 3. SHARED cluster (node 10.0.1.30 running jobs 301 & 302):
        # 4.5 GB total -> 120.0 Mbps -> SHARED, is_breach=True (counted once!)
        (
            f"{base_ms + 30000},10.0.1.30,20.60.2.10,50003,443,6,O,C,0,"
            "100,500000000,8000,4000000000"
        ),
        # 4. UNATTRIBUTED node (10.0.1.99):
        # 300 MB total -> 8.0 Mbps -> UNATTRIBUTED, is_breach=False
        (
            f"{base_ms + 40000},10.0.1.99,20.70.3.10,50004,443,6,O,E,0,"
            "50,100000000,100,200000000"
        ),
        # 5. Intra-cluster Spark shuffle (10.0.1.10 <-> 10.0.65.11): excluded!
        (
            f"{base_ms + 50000},10.0.1.10,10.0.65.11,40000,40001,6,O,C,0,"
            "99999,99000000000,99999,99000000000"
        ),
    ]

    document = {
        "records": [
            {
                "flowLogGUID": "flow-guid-1",
                "macAddress": "00-0D-3A-00-01-02",
                "flowRecords": {
                    "flows": [
                        {
                            "aclID": "acl-1",
                            "flowGroups": [
                                {
                                    "rule": "UserRule_Allow",
                                    "flowTuples": flow_tuples,
                                }
                            ],
                        }
                    ]
                },
            }
        ]
    }

    events = extract_flow_events_from_document(
        document,
        compute_ranges=compute_ranges,
        private_endpoint_ranges=pe_ranges,
    )
    assert len(events) == 4
    # The GUID comes from Azure's flowLogGUID key into the Auto CDC key
    assert events[0].event_id == compute_event_id(
        "flow-guid-1",
        "00-0D-3A-00-01-02",
        base_ms + 10000,
        "10.0.1.10",
        "20.50.1.99",
        50001,
        443,
        6,
        "O",
    )
    # The same-millisecond B/E is a re-created flow; its E is counted, and only a later report
    # of the same flow, which would repeat its counters, is corrected
    assert events[0].is_recreated is True
    assert not any(e.is_recreated for e in events[1:])

    ownership_rows = [
        NodeOwnershipWindow(
            workspace_id="ws-1",
            cluster_id="cluster-monitored",
            node_ip="10.0.1.10",
            run_id=1001,
            job_id=101,
            job_name="daily-customer-extract",
            observed_start=win_start,
            observed_end=win_end,
        ),
        NodeOwnershipWindow(
            workspace_id="ws-1",
            cluster_id="cluster-exempt",
            node_ip="10.0.1.20",
            run_id=2002,
            job_id=202,
            job_name="approved-partner-replication",
            observed_start=win_start,
            observed_end=win_end,
        ),
        NodeOwnershipWindow(
            workspace_id="ws-1",
            cluster_id="cluster-shared",
            node_ip="10.0.1.30",
            run_id=3001,
            job_id=301,
            job_name="shared-etl-a",
            observed_start=win_start,
            observed_end=win_end,
        ),
        NodeOwnershipWindow(
            workspace_id="ws-1",
            cluster_id="cluster-shared",
            node_ip="10.0.1.30",
            run_id=3002,
            job_id=302,
            job_name="shared-etl-b",
            observed_start=win_start,
            observed_end=win_end,
        ),
    ]

    exceptions = [
        JobExceptionRule(
            workspace_id="ws-1",
            job_id=202,
            job_name="approved-partner-replication",
            reason="Approved nightly bulk sync",
            approved_by="netops@example.com",
            effective_from=datetime(2026, 10, 1, 0, 0, 0, tzinfo=UTC),
            effective_to=None,
        )
    ]

    windows = attribute_window_records(
        events,
        ownership_rows,
        exceptions,
        threshold_mbps=100.0,
        default_workspace_id="ws-1",
    )
    by_cluster = {w.cluster_id: w for w in windows}
    assert set(by_cluster.keys()) == {
        "cluster-monitored",
        "cluster-exempt",
        "cluster-shared",
        "UNATTRIBUTED",
    }

    mon = by_cluster["cluster-monitored"]
    assert mon.attribution_category == "MONITORED"
    assert mon.job_id == 101
    assert mon.run_id == 1001
    assert mon.total_bytes == 4_500_000_000
    assert mon.external_bytes == 4_500_000_000
    assert mon.private_endpoint_bytes == 0
    assert mon.avg_mbps == pytest.approx(120.0)
    assert mon.is_breach is True

    ex = by_cluster["cluster-exempt"]
    assert ex.attribution_category == "EXEMPT"
    assert ex.job_id == 202
    assert ex.total_bytes == 6_000_000_000
    assert ex.private_endpoint_bytes == 6_000_000_000
    assert ex.avg_mbps == pytest.approx(160.0)
    assert ex.is_breach is False

    shared = by_cluster["cluster-shared"]
    assert shared.attribution_category == "SHARED"
    assert shared.job_id is None
    assert shared.run_id is None
    assert shared.candidate_job_ids == (301, 302)
    assert shared.job_name == "SHARED (301,302)"
    # Verify no Cartesian double-counting across the 2 concurrent jobs on cluster-shared
    assert shared.total_bytes == 4_500_000_000
    assert shared.avg_mbps == pytest.approx(120.0)
    assert shared.is_breach is True

    unattr = by_cluster["UNATTRIBUTED"]
    assert unattr.attribution_category == "UNATTRIBUTED"
    assert unattr.job_id is None
    assert unattr.total_bytes == 300_000_000
    assert unattr.avg_mbps == pytest.approx(calculate_avg_mbps(300_000_000))
    assert unattr.is_breach is False


def test_flows_are_counted_once_at_the_compute_node_nic() -> None:
    compute = parse_cidr_ranges("10.0.0.0/18,10.0.64.0/18")
    common = {"flow_log_guid": "guid", "mac_address": "00-0D-3A-00-00-01", "compute_ranges": compute}
    # The node's own NIC: outbound from the node, or inbound to the node, is counted
    outbound = parse_flow_tuple("1729500060,10.0.1.4,10.0.130.20,50000,443,6,O,C,0,10,4096,20,8192", **common)
    inbound = parse_flow_tuple("1729500060,10.0.130.20,10.0.1.4,443,50000,6,I,C,0,20,8192,10,4096", **common)
    assert outbound is not None and outbound.bytes_sent == 4096
    assert inbound is not None and inbound.bytes_received == 8192
    # The same flows recorded at the peer VM's NIC (inbound there, or outbound towards the node)
    # are the second copy of the flow and are dropped instead of double counted
    assert (
        parse_flow_tuple("1729500060,10.0.1.4,10.0.130.20,50000,443,6,I,C,0,10,4096,20,8192", **common)
        is None
    )
    assert (
        parse_flow_tuple("1729500060,10.0.130.20,10.0.1.4,443,50000,6,O,C,0,20,8192,10,4096", **common)
        is None
    )


def test_flow_log_target_resource_filtering() -> None:
    vnet = "/subscriptions/1111/resourceGroups/RG-Net/providers/Microsoft.Network/virtualNetworks/vnet-dbx"
    target_ids = parse_target_resource_ids(f" {vnet}/ ,{vnet.upper()},")
    assert target_ids == (vnet.lower(),)
    assert parse_target_resource_ids("") == ()
    with pytest.raises(ValueError, match="Invalid Azure resource ID"):
        parse_target_resource_ids("/subscriptions/1111/x' OR '1'='1")

    # Resource IDs are case-insensitive; subnets of a configured VNet count too
    assert matches_target_resource(vnet.upper(), target_ids)
    assert matches_target_resource(f"{vnet.upper()}/SUBNETS/SNET-HOST", target_ids)
    assert not matches_target_resource(f"{vnet.upper()}-OTHER", target_ids)
    assert not matches_target_resource(None, target_ids)
    assert matches_target_resource("/subscriptions/2222/anything", ())

    sql = target_resource_filter_sql("rec.targetResourceID", target_ids)
    assert sql == (
        f"((LOWER(TRIM(TRAILING '/' FROM TRIM(rec.targetResourceID))) = '{vnet.lower()}' "
        f"OR STARTSWITH(LOWER(TRIM(TRAILING '/' FROM TRIM(rec.targetResourceID))), '{vnet.lower()}/')))"
    )
    assert target_resource_filter_sql("rec.targetResourceID", ()) == "TRUE"

    document = {
        "records": [
            {
                "flowLogGuid": "guid",
                "macAddress": "000D3A000001",
                "targetResourceID": target.upper(),
                "flowRecords": {
                    "flows": [
                        {
                            "flowGroups": [
                                {
                                    "flowTuples": [
                                        "1729500060,10.0.1.4,20.50.1.10,50000,443,6,O,C,0,10,4096,20,8192"
                                    ]
                                }
                            ]
                        }
                    ]
                },
            }
            for target in (vnet, "/subscriptions/3333/resourcegroups/rg/providers/x/vnet-unrelated")
        ]
    }
    compute = parse_cidr_ranges("10.0.0.0/18")
    assert len(extract_flow_events_from_document(document, compute_ranges=compute)) == 2
    scoped = extract_flow_events_from_document(
        document, compute_ranges=compute, target_resource_ids=target_ids
    )
    assert len(scoped) == 1


def test_flow_log_start_after_is_converted_to_auto_loader_utc_format() -> None:
    assert parse_flow_log_start_after(None) is None
    assert parse_flow_log_start_after("  ") is None
    # Dates and date-times without an offset are UTC; offsets are converted to UTC
    assert parse_flow_log_start_after("2026-11-01") == "2026-11-01 00:00:00.000000 UTC+0"
    assert parse_flow_log_start_after(" 2026-11-01T08:30:00Z ") == (
        "2026-11-01 08:30:00.000000 UTC+0"
    )
    assert parse_flow_log_start_after("2026-10-31T19:00:00-05:00") == (
        "2026-11-01 00:00:00.000000 UTC+0"
    )
    for invalid in ("11/01/2026", "yesterday"):
        with pytest.raises(ValueError, match="Invalid flow-log start time"):
            parse_flow_log_start_after(invalid)


def test_sql_projection_and_gold_query_builders() -> None:
    proj = build_raw_flow_tuples_sql_projections("10.0.0.0/18,10.0.64.0/18", "")
    assert "src_in_compute" in proj["non_shuffle_filter_sql"]
    # Counted once, at the compute node's NIC
    assert "src_in_compute AND NOT dest_in_compute AND flow_direction = 'O'" in (
        proj["non_shuffle_filter_sql"]
    )
    assert "dest_in_compute AND NOT src_in_compute AND flow_direction = 'I'" in (
        proj["non_shuffle_filter_sql"]
    )
    assert "PRIVATE_ENDPOINT" in proj["traffic_scope_sql"]

    sql = build_job_bandwidth_5m_sql(
        flow_events_view="flow_event_deltas",
        cluster_runs_view="cluster_node_runs",
        exceptions_view="job_exceptions",
        threshold_mbps=100.0,
    )
    assert "matched_events" in sql
    assert "PRIVATE_ENDPOINT" in sql
    assert "300.0 * 1000000.0" in sql


def test_recreated_flows_count_their_repeated_counters_once() -> None:
    compute = parse_cidr_ranges("10.0.0.0/18")
    t0 = 1792584000000
    peer = "20.50.1.10"
    # Real tuples carry a non-numeric encryption field ("NX")
    tuples = [
        # Azure ends and restarts a flow in one millisecond (E + B)...
        f"{t0},10.0.1.5,{peer},43606,443,6,O,E,NX,464982,1000000,1669715,2400000000",
        f"{t0},10.0.1.5,{peer},43606,443,6,O,B,NX,0,0,0,0",
        # ...and the flow's next report repeats those counters plus 2 packets each way
        f"{t0 + 15800},10.0.1.5,{peer},43606,443,6,O,E,NX,464984,1000132,1669717,2400000256",
        # Reports of a flow that was not re-created are true deltas, C after C included
        f"{t0 + 1000},10.0.1.6,{peer},39514,443,6,O,C,NX,10,1000,4670,4635144",
        f"{t0 + 61000},10.0.1.6,{peer},39514,443,6,O,C,NX,5,500,1322,269832",
        # Chained re-creations: each report repeats the previous report's raw counters
        f"{t0 + 2000},10.0.1.7,{peer},52114,443,6,O,E,NX,258,40000,2733,3968932",
        f"{t0 + 2000},10.0.1.7,{peer},52114,443,6,O,B,NX,0,0,0,0",
        f"{t0 + 302000},10.0.1.7,{peer},52114,443,6,O,E,NX,260,40100,2740,3970000",
        f"{t0 + 302000},10.0.1.7,{peer},52114,443,6,O,B,NX,0,0,0,0",
        f"{t0 + 602000},10.0.1.7,{peer},52114,443,6,O,C,NX,261,40150,2741,3970500",
        # A next report below the re-created counters is a fresh delta and stays as it is
        f"{t0 + 3000},10.0.1.8,{peer},51000,443,6,O,E,NX,10,5000,10,9000000",
        f"{t0 + 3000},10.0.1.8,{peer},51000,443,6,O,B,NX,0,0,0,0",
        f"{t0 + 33000},10.0.1.8,{peer},51000,443,6,O,C,NX,2,700,2,400000",
    ]
    record: dict[str, Any] = {
        "flowLogGUID": "guid-1",
        "macAddress": "000D3A000001",
        "flowRecords": {"flows": [{"flowGroups": [{"flowTuples": tuples}]}]},
    }
    events = extract_flow_events_from_document({"records": [record]}, compute_ranges=compute)
    assert len(events) == 9

    corrected = {
        (e.local_node_ip, int(e.event_time.timestamp() * 1000) - t0): (
            e.bytes_sent,
            e.bytes_received,
            e.is_recreated,
        )
        for e in correct_recreated_flow_counters(events)
    }
    assert corrected == {
        ("10.0.1.5", 0): (1_000_000, 2_400_000_000, True),
        ("10.0.1.5", 15800): (132, 256, False),
        ("10.0.1.6", 1000): (1000, 4_635_144, False),
        ("10.0.1.6", 61000): (500, 269_832, False),
        ("10.0.1.7", 2000): (40_000, 3_968_932, True),
        ("10.0.1.7", 302000): (100, 1068, True),
        ("10.0.1.7", 602000): (50, 500, False),
        ("10.0.1.8", 3000): (5000, 9_000_000, True),
        ("10.0.1.8", 33000): (700, 400_000, False),
    }

    # Older documents with flowLogGuid still key events by their GUID
    legacy = {k: v for k, v in record.items() if k != "flowLogGUID"}
    legacy["flowLogGuid"] = "guid-legacy"
    legacy_events = extract_flow_events_from_document({"records": [legacy]}, compute_ranges=compute)
    legacy_event = legacy_events[0]
    assert legacy_event.event_id == compute_event_id(
        "guid-legacy", "000D3A000001", t0, "10.0.1.5", peer, 43606, 443, 6, "O"
    )

    # Spark twins of the key, the B-key array, the flag, and the correction
    assert flow_tuple_key(f"{t0}, 10.0.1.5 ,{peer},43606,443,6,o,E,NX,1,2,3,4") == (
        f"{t0},10.0.1.5,{peer},43606,443,6,O"
    )
    keys_sql = recreation_keys_sql("flow_group.flowTuples")
    assert keys_sql.startswith("TRANSFORM(FILTER(flow_group.flowTuples, b -> ")
    assert "SPLIT_PART(b, ',', 8))) = 'B'" in keys_sql
    flag_sql = is_recreated_tuple_sql("raw_tuple", "recreation_keys")
    assert "SPLIT_PART(raw_tuple, ',', 8))) = 'E'" in flag_sql
    assert "ARRAY_CONTAINS(recreation_keys, ARRAY_JOIN(SLICE(TRANSFORM(SPLIT(raw_tuple" in flag_sql
    deltas_sql = build_flow_event_deltas_sql("flow_events_clean", lookback_hours=24)
    assert (
        "OVER (PARTITION BY local_node_ip, remote_peer_ip, local_port, remote_port, protocol, "
        "flow_direction ORDER BY event_time, event_id)"
    ) in deltas_sql
    # Reads an hour before the lookback so a window's first report has its predecessor
    assert "date_trunc('HOUR', current_timestamp()) - INTERVAL 25 HOURS" in deltas_sql
    assert deltas_sql.endswith("date_trunc('HOUR', current_timestamp()) - INTERVAL 24 HOURS")
    assert (
        "CASE WHEN COALESCE(prev_is_recreated, FALSE) AND bytes_sent >= prev_bytes_sent "
        "AND bytes_received >= prev_bytes_received THEN bytes_sent - prev_bytes_sent "
        "ELSE bytes_sent END AS corrected_bytes_sent"
    ) in deltas_sql
    assert "bytes_sent AS raw_bytes_sent" in deltas_sql
    assert "corrected_bytes_received AS bytes_received" in deltas_sql
