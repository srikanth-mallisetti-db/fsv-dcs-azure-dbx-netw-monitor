"""Unit tests for the Phase 6 one-shot JSON deployment orchestrator (src/network_monitor/deployer.py)."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
from collections.abc import Mapping, Sequence
from pathlib import Path

import pytest

from network_monitor.deployer import (
    CommandRunner,
    bundle_resource_path,
    execute_deployment,
    genie_space_failed,
    load_deployment_config,
    remove_breach_alerting_tasks,
)
from scripts.deploy import main as run_deploy_cli


def test_load_deployment_config_supports_dev_prod_and_int_test(tmp_path: Path) -> None:
    # 1. int-test target automatically sets defaults and is_int_test="true"
    int_test_json = tmp_path / "int-test.json"
    int_test_json.write_text(
        json.dumps(
            {
                "profile": "test-profile",
                "target": "int-test",
                "bundle_vars": {
                    "catalog": "test_cat",
                    "warehouse_id": "wh_123",
                    "alert_email_recipients": ["owner@example.com"],
                },
            }
        ),
        encoding="utf-8",
    )
    cfg_int = load_deployment_config(int_test_json)
    assert cfg_int.profile == "test-profile"
    # Configs saved by Windows editors or PowerShell can start with a UTF-8 byte-order mark
    bom_json = tmp_path / "int-test-bom.json"
    bom_json.write_bytes(b"\xef\xbb\xbf" + int_test_json.read_bytes())
    assert load_deployment_config(bom_json) == cfg_int
    assert cfg_int.target == "int-test"
    assert cfg_int.ensure_schema is False
    assert cfg_int.run_initial_job is True
    assert cfg_int.bundle_vars["is_int_test"] == "true"
    assert cfg_int.bundle_vars["compute_subnet_cidrs"] == "10.0.0.0/18,10.0.64.0/18"
    assert cfg_int.bundle_vars["private_endpoint_cidrs"] == "10.0.128.0/18"
    assert cfg_int.bundle_vars["bandwidth_threshold_mbps"] == "1.0"

    env_map = cfg_int.build_subprocess_env(base_env={"PATH": "/usr/bin"})
    assert env_map["BUNDLE_VAR_catalog"] == "test_cat"
    assert env_map["BUNDLE_VAR_warehouse_id"] == "wh_123"
    assert env_map["BUNDLE_VAR_compute_subnet_cidrs"] == "10.0.0.0/18,10.0.64.0/18"

    # 2. dev target with flat top-level keys
    cfg_dev = load_deployment_config(
        {
            "profile": "dev-profile",
            "target": "dev",
            "catalog": "dev_cat",
            "schema": "network_monitor",
            "warehouse_id": "wh_dev",
            "compute_subnet_cidrs": "10.10.0.0/18,10.10.64.0/18",
            "flow_log_source_path": "abfss://insights-logs-flowlogflowevent@storage.dfs.core.windows.net/",
            "alert_email_recipients": "a@example.com, b@example.com",
        }
    )
    assert cfg_dev.target == "dev"
    assert cfg_dev.ensure_schema is True
    assert cfg_dev.bundle_vars["is_int_test"] == "false"
    assert cfg_dev.bundle_vars["schedule_pause_status"] == "PAUSED"
    assert cfg_dev.alert_subscriptions == (
        {"user_email": "a@example.com"},
        {"user_email": "b@example.com"},
    )

    # 3. prod target defaults schedule_pause_status to UNPAUSED
    cfg_prod = load_deployment_config(
        {
            "profile": "prod-profile",
            "target": "prod",
            "bundle_vars": {
                "catalog": "prod_cat",
                "warehouse_id": "wh_prod",
                "compute_subnet_cidrs": "10.20.0.0/18,10.20.64.0/18",
                "flow_log_source_path": "abfss://insights-logs-flowlogflowevent@prod.dfs.core.windows.net/",
                "alert_notification_destination_ids": ["0f1e2d3c-aaaa-bbbb-cccc-123456789abc"],
            },
        }
    )
    assert cfg_prod.target == "prod"
    assert cfg_prod.bundle_vars["schedule_pause_status"] == "UNPAUSED"
    assert cfg_prod.alert_subscriptions == (
        {"destination_id": "0f1e2d3c-aaaa-bbbb-cccc-123456789abc"},
    )


def test_load_deployment_config_validation_errors() -> None:
    with pytest.raises(ValueError, match="profile"):
        load_deployment_config({"target": "dev", "catalog": "c", "warehouse_id": "w"})

    with pytest.raises(ValueError, match="Unsupported bundle target"):
        load_deployment_config(
            {"profile": "p", "target": "staging", "catalog": "c", "warehouse_id": "w"}
        )

    with pytest.raises(ValueError, match="compute_subnet_cidrs"):
        load_deployment_config(
            {
                "profile": "p",
                "target": "dev",
                "catalog": "c",
                "warehouse_id": "w",
                "flow_log_source_path": "/Volumes/c/s/v",
            }
        )

    with pytest.raises(ValueError, match="flow_log_source_path"):
        load_deployment_config(
            {
                "profile": "p",
                "target": "dev",
                "catalog": "c",
                "warehouse_id": "w",
                "compute_subnet_cidrs": "10.0.0.0/18",
            }
        )


def test_execute_deployment_handles_cold_genie_bootstrap_and_cli(tmp_path: Path) -> None:
    cfg = load_deployment_config(
        {
            "profile": "test-prof",
            "target": "dev",
            "catalog": "cat_a",
            "schema": "net_mon",
            "warehouse_id": "wh_a",
            "compute_subnet_cidrs": "10.0.0.0/18,10.0.64.0/18",
            "flow_log_source_path": "/Volumes/cat_a/net_mon/logs",
            "alert_email_recipients": ["netops@example.com"],
        }
    )

    deploy_attempts = 0
    overrides_file = tmp_path / ".databricks" / "bundle" / "dev" / "variable-overrides.json"

    def fake_runner(
        cmd: Sequence[str],
        env: Mapping[str, str],
    ) -> subprocess.CompletedProcess[str]:
        nonlocal deploy_attempts
        assert env["BUNDLE_VAR_catalog"] == "cat_a"
        if cmd[:3] == ["databricks", "bundle", "validate"]:
            # Complex variables must be on disk before the CLI resolves the bundle
            assert overrides_file.is_file()
        if cmd[:3] == ["databricks", "bundle", "deploy"]:
            deploy_attempts += 1
            if deploy_attempts == 1:
                # A cold schema as Databricks CLI 1.20 reports it: the Genie API answers 403
                # PERMISSION_DENIED for tables that do not exist yet
                return subprocess.CompletedProcess(
                    list(cmd),
                    1,
                    stdout="",
                    stderr=(
                        "Error: cannot create resources.genie_spaces.network_monitor_genie: "
                        "An error occurred accessing the schema. Failed to fetch tables for the "
                        "agent. Please resolve these errors to continue: Table "
                        "'cat_a.net_mon.breach_notifications' does not exist\n"
                        "Endpoint: POST https://<workspace-host>/api/2.0/genie/spaces\n"
                        "HTTP Status: 403 Forbidden\n"
                        "API error_code: PERMISSION_DENIED\n"
                    ),
                )
        return subprocess.CompletedProcess(list(cmd), 0, stdout="OK", stderr="")

    result = execute_deployment(cfg, runner=fake_runner, bundle_root=tmp_path)
    assert result["status"] == "deployed"
    assert result["cold_genie_bootstrapped"] is True
    assert result["job_ran"] is True
    assert deploy_attempts == 2
    assert result["alert_subscriptions"] == [{"user_email": "netops@example.com"}]
    assert json.loads(overrides_file.read_text(encoding="utf-8")) == {
        "alert_subscriptions": [{"user_email": "netops@example.com"}],
        "alert_task_subscribers": [{"user_name": "netops@example.com"}],
        "job_failure_emails": ["netops@example.com"],
        "job_failure_destinations": [],
    }

    # Verify CLI dry-run execution
    cfg_file = tmp_path / "deploy.local.json"
    cfg_file.write_text(
        json.dumps(
            {
                "profile": "cli-prof",
                "target": "int-test",
                "bundle_vars": {
                    "catalog": "cat_cli",
                    "warehouse_id": "wh_cli",
                    "alert_email_recipients": ["cli@example.com"],
                },
            }
        ),
        encoding="utf-8",
    )
    rc = run_deploy_cli(["--config", str(cfg_file), "--dry-run"])
    assert rc == 0


def test_alert_recipients_validation_and_variable_overrides(tmp_path: Path) -> None:
    base = {"profile": "p", "target": "int-test", "catalog": "c", "warehouse_id": "w"}

    with pytest.raises(ValueError, match="At least one breach alert recipient"):
        load_deployment_config(base)
    with pytest.raises(ValueError, match="Invalid alert recipient email"):
        load_deployment_config({**base, "alert_email_recipients": ["<workspace-user-email>"]})
    with pytest.raises(ValueError, match="Invalid alert notification destination ID"):
        load_deployment_config(
            {**base, "alert_notification_destination_ids": ["<email-notification-destination-id>"]}
        )
    with pytest.raises(ValueError, match="must be a JSON list"):
        load_deployment_config({**base, "alert_email_recipients": 42})
    for bad_window in ({"lookback_hours": "0"}, {"retention_days": "seven"}):
        with pytest.raises(ValueError, match="positive whole number"):
            load_deployment_config(
                {**base, **bad_window, "alert_email_recipients": ["ops@example.com"]}
            )
    with pytest.raises(ValueError, match="Invalid Azure resource ID"):
        load_deployment_config(
            {
                **base,
                "alert_email_recipients": ["ops@example.com"],
                "flow_log_target_resource_ids": "/subscriptions/<subscription-id>/x",
            }
        )

    cfg = load_deployment_config(
        {
            **base,
            "alert_email_recipients": ["ops@example.com", " ops@example.com ", "dev@example.com"],
            "alert_notification_destination_ids": "dest-1;dest-2",
        }
    )
    expected = [
        {"user_email": "ops@example.com"},
        {"user_email": "dev@example.com"},
        {"destination_id": "dest-1"},
        {"destination_id": "dest-2"},
    ]
    # The job's alert task names workspace users with user_name instead of user_email
    expected_task_subscribers = [
        {"user_name": "ops@example.com"},
        {"user_name": "dev@example.com"},
        {"destination_id": "dest-1"},
        {"destination_id": "dest-2"},
    ]
    # Failed job runs notify the same recipients: workspace users by email, destinations by id
    expected_failure_emails = ["ops@example.com", "dev@example.com"]
    expected_failure_destinations = [{"id": "dest-1"}, {"id": "dest-2"}]
    assert cfg.build_variable_overrides() == {
        "alert_subscriptions": expected,
        "alert_task_subscribers": expected_task_subscribers,
        "job_failure_emails": expected_failure_emails,
        "job_failure_destinations": expected_failure_destinations,
    }

    # Dry runs never touch disk; real runs merge into the target's variable-overrides.json
    overrides_file = tmp_path / ".databricks" / "bundle" / "int-test" / "variable-overrides.json"
    dry = execute_deployment(cfg, dry_run=True, bundle_root=tmp_path)
    assert dry["variable_overrides_path"] == str(overrides_file)
    assert not overrides_file.exists()

    def ok_runner(
        cmd: Sequence[str],
        env: Mapping[str, str],
    ) -> subprocess.CompletedProcess[str]:
        return subprocess.CompletedProcess(list(cmd), 0, stdout="OK", stderr="")

    overrides_file.parent.mkdir(parents=True)
    overrides_file.write_text(json.dumps({"other_var": {"keep": True}}), encoding="utf-8")
    execute_deployment(cfg, validate_only=True, runner=ok_runner, bundle_root=tmp_path)
    assert json.loads(overrides_file.read_text(encoding="utf-8")) == {
        "other_var": {"keep": True},
        "alert_subscriptions": expected,
        "alert_task_subscribers": expected_task_subscribers,
        "job_failure_emails": expected_failure_emails,
        "job_failure_destinations": expected_failure_destinations,
    }

    overrides_file.write_text("not json", encoding="utf-8")
    with pytest.raises(ValueError, match="not valid JSON"):
        execute_deployment(cfg, validate_only=True, runner=ok_runner, bundle_root=tmp_path)


def test_full_refresh_resets_the_pipeline_after_preparing_its_inputs(tmp_path: Path) -> None:
    executed: list[list[str]] = []

    def recording_runner(
        cmd: Sequence[str],
        env: Mapping[str, str],
    ) -> subprocess.CompletedProcess[str]:
        executed.append(list(cmd))
        return subprocess.CompletedProcess(list(cmd), 0, stdout="OK", stderr="")

    # Pipeline flags do not apply to job runs, so the pipeline itself gets --full-refresh-all,
    # after the job tasks that create the tables it reads strictly
    for target, prepare in (
        ("dev", "snapshot_cluster_nodes"),
        ("int-test", "+generate_synthetic_telemetry"),
    ):
        executed.clear()
        cfg = load_deployment_config(
            {
                "profile": "p",
                "target": target,
                "catalog": "c",
                "warehouse_id": "w",
                "compute_subnet_cidrs": "10.0.0.0/18",
                "flow_log_source_path": "/Volumes/c/s/v",
                "alert_email_recipients": ["ops@example.com"],
                "full_refresh": True,
            }
        )
        result = execute_deployment(cfg, runner=recording_runner, bundle_root=tmp_path)
        runs = [cmd for cmd in executed if cmd[:3] == ["databricks", "bundle", "run"]]
        base_cmd = ["-t", target, "--profile", "p"]
        assert runs == [
            ["databricks", "bundle", "run", "network_monitor_job", *base_cmd, "--only", prepare],
            ["databricks", "bundle", "run", "network_monitor_sdp", *base_cmd, "--full-refresh-all"],
            ["databricks", "bundle", "run", "network_monitor_job", *base_cmd],
        ]
        assert not any("--refresh-all" in cmd for cmd in executed)
        assert result["pipeline_full_refreshed"] is True


def _deploy_config(**overrides: object) -> dict[str, object]:
    return {
        "profile": "p",
        "target": "prod",
        "catalog": "c",
        "warehouse_id": "w",
        "compute_subnet_cidrs": "10.0.0.0/18",
        "flow_log_source_path": "/Volumes/c/s/v",
        "alert_email_recipients": ["ops@example.com"],
        **overrides,
    }


def test_validate_only_changes_nothing_and_dry_runs_report_it(tmp_path: Path) -> None:
    executed: list[list[str]] = []

    def recording_runner(
        cmd: Sequence[str],
        env: Mapping[str, str],
    ) -> subprocess.CompletedProcess[str]:
        executed.append(list(cmd))
        return subprocess.CompletedProcess(list(cmd), 0, stdout="OK", stderr="")

    cfg = load_deployment_config(_deploy_config())
    assert cfg.ensure_schema is True

    # --validate-only creates no schema: it only checks the CLI and authentication, and validates
    result = execute_deployment(
        cfg, validate_only=True, runner=recording_runner, bundle_root=tmp_path
    )
    assert result["status"] == "validated"
    assert [cmd[:3] for cmd in executed] == [
        ["databricks", "--version"],
        ["databricks", "current-user", "me"],
        ["databricks", "bundle", "validate"],
    ]

    # Dry runs say so, and never claim that the job ran or the pipeline was reset
    assert execute_deployment(cfg, validate_only=True, dry_run=True, bundle_root=tmp_path)[
        "status"
    ] == "dry_run"
    cfg_full = load_deployment_config(_deploy_config(full_refresh=True))
    dry = execute_deployment(cfg_full, dry_run=True, bundle_root=tmp_path)
    assert dry["status"] == "dry_run"
    assert dry["job_ran"] is False
    assert dry["pipeline_full_refreshed"] is False
    assert ["databricks", "bundle", "deploy", "-t", "prod", "--profile", "p"] in dry[
        "executed_commands"
    ]


def test_cold_genie_bootstrap_does_not_depend_on_the_cli_error_wording(tmp_path: Path) -> None:
    cfg = load_deployment_config(_deploy_config(run_initial_job=False))

    def run_with(
        first_deploy_error: str,
        redeploy_error: str = "",
    ) -> tuple[list[list[str]], dict[str, object] | RuntimeError]:
        executed: list[list[str]] = []

        def runner(
            cmd: Sequence[str],
            env: Mapping[str, str],
        ) -> subprocess.CompletedProcess[str]:
            executed.append(list(cmd))
            if cmd[:3] == ["databricks", "bundle", "deploy"]:
                deploys = sum(1 for done in executed if done[:3] == list(cmd[:3]))
                error = first_deploy_error if deploys == 1 else redeploy_error
                if error:
                    return subprocess.CompletedProcess(list(cmd), 1, stdout="", stderr=error)
            return subprocess.CompletedProcess(list(cmd), 0, stdout="OK", stderr="")

        try:
            return executed, execute_deployment(cfg, runner=runner, bundle_root=tmp_path)
        except RuntimeError as exc:
            return executed, exc

    def ran_job(executed: list[list[str]]) -> bool:
        job_run = ["databricks", "bundle", "run", "network_monitor_job"]
        return any(cmd[:4] == job_run for cmd in executed)

    # Other CLI versions and deployment engines word the missing tables differently
    terraform_engine_error = (
        "Error: terraform apply: exit status 1\n\n"
        "Error: cannot create genie space: [TABLE_OR_VIEW_NOT_FOUND] "
        "c.network_monitor.job_bandwidth_5m\n\n"
        "  with databricks_genie_space.network_monitor_genie,"
    )
    executed, result = run_with(terraform_engine_error)
    assert isinstance(result, dict)
    assert result["cold_genie_bootstrapped"] is True
    assert result["job_ran"] is True
    assert ran_job(executed)

    # Failures of other resources are reported at once, without running the job
    executed, result = run_with("Error: cannot create resources.pipelines.network_monitor_sdp")
    assert isinstance(result, RuntimeError)
    assert "Bundle deploy failed" in str(result)
    assert not ran_job(executed)

    # When the bootstrap does not fix it, the first deploy's error is still shown
    permission_error = (
        "Error: cannot create resources.genie_spaces.network_monitor_genie: PERMISSION_DENIED"
    )
    executed, result = run_with(permission_error, redeploy_error=permission_error)
    assert isinstance(result, RuntimeError)
    assert "cold-schema bootstrap" in str(result)
    assert str(result).count("PERMISSION_DENIED") == 2
    assert ran_job(executed)


def test_destroy_removes_the_deployment_with_the_configs_variables(tmp_path: Path) -> None:
    executed: list[tuple[list[str], dict[str, str]]] = []

    def recording_runner(
        cmd: Sequence[str],
        env: Mapping[str, str],
    ) -> subprocess.CompletedProcess[str]:
        executed.append((list(cmd), dict(env)))
        return subprocess.CompletedProcess(list(cmd), 0, stdout="OK", stderr="")

    cfg = load_deployment_config(_deploy_config())
    result = execute_deployment(cfg, destroy=True, runner=recording_runner, bundle_root=tmp_path)
    assert result["status"] == "destroyed"
    # No schema creation or deploy: the CLI and auth checks, the validation that decides what to
    # leave out, and the destroy
    assert [cmd for cmd, _ in executed] == [
        ["databricks", "--version"],
        ["databricks", "current-user", "me", "--profile", "p", "-o", "json"],
        ["databricks", "bundle", "validate", "-t", "prod", "--profile", "p", "-o", "json"],
        ["databricks", "bundle", "destroy", "-t", "prod", "--profile", "p", "--auto-approve"],
    ]
    # The CLI loads the bundle with this config's variables; a bare destroy fails without them
    assert executed[-1][1]["BUNDLE_VAR_warehouse_id"] == "w"
    dry = execute_deployment(cfg, destroy=True, dry_run=True, bundle_root=tmp_path)
    assert dry["status"] == "dry_run"
    with pytest.raises(ValueError, match="cannot be combined"):
        execute_deployment(cfg, destroy=True, validate_only=True, bundle_root=tmp_path)

    cfg_file = tmp_path / "deploy.local.json"
    cfg_file.write_text(json.dumps(_deploy_config()), encoding="utf-8")
    assert run_deploy_cli(["--config", str(cfg_file), "--destroy", "--dry-run"]) == 0
    with pytest.raises(SystemExit):
        run_deploy_cli(["--config", str(cfg_file), "--destroy", "--validate-only"])


def test_flow_log_start_after_is_validated_and_exported() -> None:
    with pytest.raises(ValueError, match="Invalid flow-log start time"):
        load_deployment_config(_deploy_config(flow_log_start_after="11/01/2026"))

    cfg = load_deployment_config(_deploy_config(flow_log_start_after=" 2026-11-01 "))
    assert cfg.build_subprocess_env(base_env={})["BUNDLE_VAR_flow_log_start_after"] == "2026-11-01"
    # Unset, the bundle variable keeps its empty default and every flow-log file is read
    unset = load_deployment_config(_deploy_config()).build_subprocess_env(base_env={})
    assert "BUNDLE_VAR_flow_log_start_after" not in unset


ROOT = Path(__file__).resolve().parents[1]
OLD_CLI_VALIDATE_WARNINGS = (
    "Warning: unknown field: genie_spaces\n"
    "  at resources\n"
    "  in resources/network_monitor_genie.yml:2:3\n\n"
    "Warning: unknown field: alert_task\n"
    "  at resources.jobs.network_monitor_job.tasks[4]\n"
    "Found 2 warnings\n"
)


def _bundle_copy(tmp_path: Path) -> Path:
    """Copy the real bundle definition, plus a tiny src tree with a bytecode cache, to tmp_path."""
    root = tmp_path / "bundle"
    shutil.copytree(ROOT / "resources", root / "resources")
    shutil.copy2(ROOT / "databricks.yml", root / "databricks.yml")
    shutil.copy2(ROOT / ".gitignore", root / ".gitignore")
    (root / "src" / "network_monitor" / "__pycache__").mkdir(parents=True)
    (root / "src" / "network_monitor" / "tasks.py").write_text("x = 1\n", encoding="utf-8")
    (root / "src" / "network_monitor" / "__pycache__" / "tasks.pyc").write_bytes(b"\0")
    return root


def _cli_runner(
    validate_output: str,
) -> tuple[list[tuple[list[str], dict[str, str]]], CommandRunner]:
    executed: list[tuple[list[str], dict[str, str]]] = []

    def runner(cmd: Sequence[str], env: Mapping[str, str]) -> subprocess.CompletedProcess[str]:
        executed.append((list(cmd), dict(env)))
        if list(cmd) == ["databricks", "--version"]:
            return subprocess.CompletedProcess(list(cmd), 0, stdout="Databricks CLI v0.289.2\n")
        stderr = validate_output if cmd[:3] == ["databricks", "bundle", "validate"] else ""
        return subprocess.CompletedProcess(list(cmd), 0, stdout="OK", stderr=stderr)

    return executed, runner


def test_older_cli_deploys_without_breach_alerting_and_genie(tmp_path: Path) -> None:
    root = _bundle_copy(tmp_path)
    executed, runner = _cli_runner(OLD_CLI_VALIDATE_WARNINGS)
    cfg = load_deployment_config(_deploy_config(target="int-test", deploy_genie_space=False))
    assert cfg.deploy_genie_space is False

    result = execute_deployment(cfg, runner=runner, bundle_root=root)
    staged = root / ".databricks" / "staged-bundle" / "int-test"
    assert result["status"] == "deployed"
    assert result["bundle_root"] == str(staged)
    assert result["genie_space_deployed"] is False
    assert result["breach_alerting_deployed"] is False
    assert result["cli_version"] == "v0.289.2"
    assert len(result["warnings"]) == 1
    assert "cannot deploy the breach-alert job task (alert_task)" in result["warnings"][0]
    assert "The installed Databricks CLI (v0.289.2)" in result["warnings"][0]

    # The staged copy leaves out the Genie Space, the alert, and the breach-alerting tasks;
    # the repo's own files are untouched
    assert not (staged / "resources" / "network_monitor_genie.yml").exists()
    assert not (staged / "resources" / "network_monitor_alert.yml").exists()
    job_yml = (staged / "resources" / "network_monitor_job.yml").read_text(encoding="utf-8")
    for task in ("record_new_breaches", "notify_new_breaches", "mark_breaches_notified"):
        assert task not in job_yml
    assert "alert_task:" not in job_yml
    assert "- task_key: publish_semantic_layer" in job_yml
    assert (root / "resources" / "network_monitor_genie.yml").exists()
    assert "alert_task:" in (root / "resources" / "network_monitor_job.yml").read_text("utf-8")
    assert (staged / "src" / "network_monitor" / "tasks.py").exists()
    assert not (staged / "src" / "network_monitor" / "__pycache__").exists()
    assert (staged / ".databricks" / "bundle" / "int-test" / "variable-overrides.json").exists()

    # Validation runs on the repo's bundle first, then every later command loads the staged copy
    commands = [cmd[:3] for cmd, _ in executed]
    assert commands == [
        ["databricks", "--version"],
        ["databricks", "current-user", "me"],
        ["databricks", "bundle", "validate"],
        ["databricks", "bundle", "validate"],
        ["databricks", "bundle", "deploy"],
        ["databricks", "bundle", "run"],
        ["databricks", "bundle", "summary"],
    ]
    roots = [env.get("DATABRICKS_BUNDLE_ROOT") for _, env in executed]
    assert roots[:3] == [None, None, None]
    assert roots[3:] == [str(staged)] * 4

    # A second run refreshes the staged copy and keeps the CLI's local cache
    cache = staged / ".databricks" / "cache.txt"
    cache.write_text("kept", encoding="utf-8")
    execute_deployment(cfg, runner=runner, bundle_root=root)
    assert cache.read_text(encoding="utf-8") == "kept"


def test_genie_on_a_cli_that_cannot_deploy_it_fails_before_deploying(tmp_path: Path) -> None:
    root = _bundle_copy(tmp_path)
    executed, runner = _cli_runner(OLD_CLI_VALIDATE_WARNINGS)
    cfg = load_deployment_config(_deploy_config(target="int-test"))
    assert cfg.deploy_genie_space is True
    with pytest.raises(RuntimeError, match='Set "deploy_genie_space": false'):
        execute_deployment(cfg, runner=runner, bundle_root=root)
    assert not any(cmd[:3] == ["databricks", "bundle", "deploy"] for cmd, _ in executed)

    # Destroying still works, from the copy the CLI can load
    executed.clear()
    destroyed = execute_deployment(cfg, destroy=True, runner=runner, bundle_root=root)
    assert destroyed["status"] == "destroyed"
    assert executed[-1][0][:3] == ["databricks", "bundle", "destroy"]
    assert executed[-1][1]["DATABRICKS_BUNDLE_ROOT"] == destroyed["bundle_root"]


def test_genie_turned_off_on_a_current_cli_keeps_breach_alerting(tmp_path: Path) -> None:
    root = _bundle_copy(tmp_path)
    executed, runner = _cli_runner("Validation OK!")
    cfg = load_deployment_config(_deploy_config(target="dev", deploy_genie_space="false"))
    result = execute_deployment(cfg, runner=runner, bundle_root=root)
    staged = Path(result["bundle_root"])
    assert (result["genie_space_deployed"], result["breach_alerting_deployed"]) == (False, True)
    assert result["warnings"] == []
    assert not (staged / "resources" / "network_monitor_genie.yml").exists()
    assert (staged / "resources" / "network_monitor_alert.yml").exists()
    staged_job = (staged / "resources" / "network_monitor_job.yml").read_text(encoding="utf-8")
    assert staged_job == (root / "resources" / "network_monitor_job.yml").read_text("utf-8")

    # With the Genie Space on, a current CLI deploys the repo's bundle as is
    executed.clear()
    full = execute_deployment(
        load_deployment_config(_deploy_config(target="dev")), runner=runner, bundle_root=root
    )
    assert (full["genie_space_deployed"], full["breach_alerting_deployed"]) == (True, True)
    assert full["bundle_root"] == str(root)
    assert all("DATABRICKS_BUNDLE_ROOT" not in env for _, env in executed)


def test_genie_failures_are_errors_not_warnings_and_tasks_come_out_by_marker() -> None:
    # The old CLI's warning about the unknown genie_spaces field is not a Genie failure
    old_cli_deploy = (
        OLD_CLI_VALIDATE_WARNINGS
        + "Error: terraform apply: exit status 1\n"
        + "Error: cannot create job: No task defined for notify_new_breaches\n"
    )
    assert genie_space_failed(old_cli_deploy) is False
    assert genie_space_failed("Error: cannot create resources.genie_spaces.x: missing") is True
    assert genie_space_failed("Error: cannot create genie space: TABLE_OR_VIEW_NOT_FOUND") is True

    job_yml = (ROOT / "resources" / "network_monitor_job.yml").read_text(encoding="utf-8")
    trimmed = remove_breach_alerting_tasks(job_yml)
    assert "alert_task:" not in trimmed
    assert "BEGIN breach alerting" not in trimmed and "END breach alerting" not in trimmed
    defined_tasks = re.findall(r"^        - task_key: (\w+)$", trimmed, re.MULTILINE)
    assert defined_tasks == [
        "snapshot_cluster_nodes",
        "refresh_flow_pipeline",
        "publish_semantic_layer",
    ]
    with pytest.raises(ValueError, match="exactly one"):
        remove_breach_alerting_tasks(trimmed)


def test_deploy_creates_the_dashboard_folder_first(tmp_path: Path) -> None:
    resource_path = "/Workspace/Users/ops@example.com/.bundle/monitor/dev/resources"
    validate_json = json.dumps({"workspace": {"resource_path": resource_path}})
    assert bundle_resource_path("Some CLI banner\n" + validate_json) == resource_path
    assert bundle_resource_path("[dry-run]") is None

    executed: list[list[str]] = []

    def runner(cmd: Sequence[str], env: Mapping[str, str]) -> subprocess.CompletedProcess[str]:
        executed.append(list(cmd))
        stdout = validate_json if cmd[:3] == ["databricks", "bundle", "validate"] else "OK"
        return subprocess.CompletedProcess(list(cmd), 0, stdout=stdout, stderr="")

    execute_deployment(
        load_deployment_config(_deploy_config(target="dev")), runner=runner, bundle_root=tmp_path
    )
    # CLIs older than v0.290.1 do not create it, and the dashboard deploy fails without it
    mkdirs = ["databricks", "workspace", "mkdirs", resource_path, "--profile", "p"]
    deploy = ["databricks", "bundle", "deploy"]
    deploy_index = next(i for i, cmd in enumerate(executed) if cmd[:3] == deploy)
    assert executed[deploy_index - 1] == mkdirs


def test_cli_prints_configuration_errors_without_a_traceback(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    bad = tmp_path / "bad.local.json"
    bad.write_text(json.dumps(_deploy_config(alert_email_recipients=["<x>"])), encoding="utf-8")
    assert run_deploy_cli(["--config", str(bad), "--dry-run"]) == 1
    assert run_deploy_cli(["--config", str(tmp_path / "missing.json"), "--dry-run"]) == 1
    errors = capsys.readouterr().err
    assert errors.count("ERROR: ") == 2
    assert "Invalid alert recipient email address" in errors
    assert "Traceback" not in errors

