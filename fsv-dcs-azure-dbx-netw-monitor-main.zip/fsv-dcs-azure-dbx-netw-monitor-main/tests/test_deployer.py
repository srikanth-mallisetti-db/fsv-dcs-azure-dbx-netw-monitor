"""Unit tests for the Phase 6 one-shot JSON deployment orchestrator (src/network_monitor/deployer.py)."""

from __future__ import annotations

import json
import subprocess
from collections.abc import Mapping, Sequence
from pathlib import Path

import pytest

from network_monitor.deployer import execute_deployment, load_deployment_config
from scripts.deploy import main as run_deploy_cli


def test_load_deployment_config_supports_dev_prod_and_int_test(tmp_path: Path) -> None:
    # 1. int-test target automatically sets defaults and is_int_test="true"
    int_test_json = tmp_path / "int-test.json"
    int_test_json.write_text(
        json.dumps(
            {
                "profile": "test-profile",
                "target": "int-test",
                "bundle_vars": {
                    "catalog": "test_cat",
                    "warehouse_id": "wh_123",
                    "alert_email_recipients": ["owner@example.com"],
                },
            }
        ),
        encoding="utf-8",
    )
    cfg_int = load_deployment_config(int_test_json)
    assert cfg_int.profile == "test-profile"
    # Configs saved by Windows editors or PowerShell can start with a UTF-8 byte-order mark
    bom_json = tmp_path / "int-test-bom.json"
    bom_json.write_bytes(b"\xef\xbb\xbf" + int_test_json.read_bytes())
    assert load_deployment_config(bom_json) == cfg_int
    assert cfg_int.target == "int-test"
    assert cfg_int.ensure_schema is False
    assert cfg_int.run_initial_job is True
    assert cfg_int.bundle_vars["is_int_test"] == "true"
    assert cfg_int.bundle_vars["compute_subnet_cidrs"] == "10.0.0.0/18,10.0.64.0/18"
    assert cfg_int.bundle_vars["private_endpoint_cidrs"] == "10.0.128.0/18"
    assert cfg_int.bundle_vars["bandwidth_threshold_mbps"] == "1.0"

    env_map = cfg_int.build_subprocess_env(base_env={"PATH": "/usr/bin"})
    assert env_map["BUNDLE_VAR_catalog"] == "test_cat"
    assert env_map["BUNDLE_VAR_warehouse_id"] == "wh_123"
    assert env_map["BUNDLE_VAR_compute_subnet_cidrs"] == "10.0.0.0/18,10.0.64.0/18"

    # 2. dev target with flat top-level keys
    cfg_dev = load_deployment_config(
        {
            "profile": "dev-profile",
            "target": "dev",
            "catalog": "dev_cat",
            "schema": "network_monitor",
            "warehouse_id": "wh_dev",
            "compute_subnet_cidrs": "10.10.0.0/18,10.10.64.0/18",
            "flow_log_source_path": "abfss://insights-logs-flowlogflowevent@storage.dfs.core.windows.net/",
            "alert_email_recipients": "a@example.com, b@example.com",
        }
    )
    assert cfg_dev.target == "dev"
    assert cfg_dev.ensure_schema is True
    assert cfg_dev.bundle_vars["is_int_test"] == "false"
    assert cfg_dev.bundle_vars["schedule_pause_status"] == "PAUSED"
    assert cfg_dev.alert_subscriptions == (
        {"user_email": "a@example.com"},
        {"user_email": "b@example.com"},
    )

    # 3. prod target defaults schedule_pause_status to UNPAUSED
    cfg_prod = load_deployment_config(
        {
            "profile": "prod-profile",
            "target": "prod",
            "bundle_vars": {
                "catalog": "prod_cat",
                "warehouse_id": "wh_prod",
                "compute_subnet_cidrs": "10.20.0.0/18,10.20.64.0/18",
                "flow_log_source_path": "abfss://insights-logs-flowlogflowevent@prod.dfs.core.windows.net/",
                "alert_notification_destination_ids": ["0f1e2d3c-aaaa-bbbb-cccc-123456789abc"],
            },
        }
    )
    assert cfg_prod.target == "prod"
    assert cfg_prod.bundle_vars["schedule_pause_status"] == "UNPAUSED"
    assert cfg_prod.alert_subscriptions == (
        {"destination_id": "0f1e2d3c-aaaa-bbbb-cccc-123456789abc"},
    )


def test_load_deployment_config_validation_errors() -> None:
    with pytest.raises(ValueError, match="profile"):
        load_deployment_config({"target": "dev", "catalog": "c", "warehouse_id": "w"})

    with pytest.raises(ValueError, match="Unsupported bundle target"):
        load_deployment_config(
            {"profile": "p", "target": "staging", "catalog": "c", "warehouse_id": "w"}
        )

    with pytest.raises(ValueError, match="compute_subnet_cidrs"):
        load_deployment_config(
            {
                "profile": "p",
                "target": "dev",
                "catalog": "c",
                "warehouse_id": "w",
                "flow_log_source_path": "/Volumes/c/s/v",
            }
        )

    with pytest.raises(ValueError, match="flow_log_source_path"):
        load_deployment_config(
            {
                "profile": "p",
                "target": "dev",
                "catalog": "c",
                "warehouse_id": "w",
                "compute_subnet_cidrs": "10.0.0.0/18",
            }
        )


def test_execute_deployment_handles_cold_genie_bootstrap_and_cli(tmp_path: Path) -> None:
    cfg = load_deployment_config(
        {
            "profile": "test-prof",
            "target": "dev",
            "catalog": "cat_a",
            "schema": "net_mon",
            "warehouse_id": "wh_a",
            "compute_subnet_cidrs": "10.0.0.0/18,10.0.64.0/18",
            "flow_log_source_path": "/Volumes/cat_a/net_mon/logs",
            "alert_email_recipients": ["netops@example.com"],
        }
    )

    deploy_attempts = 0
    overrides_file = tmp_path / ".databricks" / "bundle" / "dev" / "variable-overrides.json"

    def fake_runner(
        cmd: Sequence[str],
        env: Mapping[str, str],
    ) -> subprocess.CompletedProcess[str]:
        nonlocal deploy_attempts
        assert env["BUNDLE_VAR_catalog"] == "cat_a"
        if cmd[:3] == ["databricks", "bundle", "validate"]:
            # Complex variables must be on disk before the CLI resolves the bundle
            assert overrides_file.is_file()
        if cmd[:3] == ["databricks", "bundle", "deploy"]:
            deploy_attempts += 1
            if deploy_attempts == 1:
                # A cold schema as Databricks CLI 1.20 reports it: the Genie API answers 403
                # PERMISSION_DENIED for tables that do not exist yet
                return subprocess.CompletedProcess(
                    list(cmd),
                    1,
                    stdout="",
                    stderr=(
                        "Error: cannot create resources.genie_spaces.network_monitor_genie: "
                        "An error occurred accessing the schema. Failed to fetch tables for the "
                        "agent. Please resolve these errors to continue: Table "
                        "'cat_a.net_mon.breach_notifications' does not exist\n"
                        "Endpoint: POST https://<workspace-host>/api/2.0/genie/spaces\n"
                        "HTTP Status: 403 Forbidden\n"
                        "API error_code: PERMISSION_DENIED\n"
                    ),
                )
        return subprocess.CompletedProcess(list(cmd), 0, stdout="OK", stderr="")

    result = execute_deployment(cfg, runner=fake_runner, bundle_root=tmp_path)
    assert result["status"] == "deployed"
    assert result["cold_genie_bootstrapped"] is True
    assert result["job_ran"] is True
    assert deploy_attempts == 2
    assert result["alert_subscriptions"] == [{"user_email": "netops@example.com"}]
    assert json.loads(overrides_file.read_text(encoding="utf-8")) == {
        "alert_subscriptions": [{"user_email": "netops@example.com"}],
        "alert_task_subscribers": [{"user_name": "netops@example.com"}],
        "job_failure_emails": ["netops@example.com"],
        "job_failure_destinations": [],
    }

    # Verify CLI dry-run execution
    cfg_file = tmp_path / "deploy.local.json"
    cfg_file.write_text(
        json.dumps(
            {
                "profile": "cli-prof",
                "target": "int-test",
                "bundle_vars": {
                    "catalog": "cat_cli",
                    "warehouse_id": "wh_cli",
                    "alert_email_recipients": ["cli@example.com"],
                },
            }
        ),
        encoding="utf-8",
    )
    rc = run_deploy_cli(["--config", str(cfg_file), "--dry-run"])
    assert rc == 0


def test_alert_recipients_validation_and_variable_overrides(tmp_path: Path) -> None:
    base = {"profile": "p", "target": "int-test", "catalog": "c", "warehouse_id": "w"}

    with pytest.raises(ValueError, match="At least one breach alert recipient"):
        load_deployment_config(base)
    with pytest.raises(ValueError, match="Invalid alert recipient email"):
        load_deployment_config({**base, "alert_email_recipients": ["<workspace-user-email>"]})
    with pytest.raises(ValueError, match="Invalid alert notification destination ID"):
        load_deployment_config(
            {**base, "alert_notification_destination_ids": ["<email-notification-destination-id>"]}
        )
    with pytest.raises(ValueError, match="must be a JSON list"):
        load_deployment_config({**base, "alert_email_recipients": 42})
    for bad_window in ({"lookback_hours": "0"}, {"retention_days": "seven"}):
        with pytest.raises(ValueError, match="positive whole number"):
            load_deployment_config(
                {**base, **bad_window, "alert_email_recipients": ["ops@example.com"]}
            )
    with pytest.raises(ValueError, match="Invalid Azure resource ID"):
        load_deployment_config(
            {
                **base,
                "alert_email_recipients": ["ops@example.com"],
                "flow_log_target_resource_ids": "/subscriptions/<subscription-id>/x",
            }
        )

    cfg = load_deployment_config(
        {
            **base,
            "alert_email_recipients": ["ops@example.com", " ops@example.com ", "dev@example.com"],
            "alert_notification_destination_ids": "dest-1;dest-2",
        }
    )
    expected = [
        {"user_email": "ops@example.com"},
        {"user_email": "dev@example.com"},
        {"destination_id": "dest-1"},
        {"destination_id": "dest-2"},
    ]
    # The job's alert task names workspace users with user_name instead of user_email
    expected_task_subscribers = [
        {"user_name": "ops@example.com"},
        {"user_name": "dev@example.com"},
        {"destination_id": "dest-1"},
        {"destination_id": "dest-2"},
    ]
    # Failed job runs notify the same recipients: workspace users by email, destinations by id
    expected_failure_emails = ["ops@example.com", "dev@example.com"]
    expected_failure_destinations = [{"id": "dest-1"}, {"id": "dest-2"}]
    assert cfg.build_variable_overrides() == {
        "alert_subscriptions": expected,
        "alert_task_subscribers": expected_task_subscribers,
        "job_failure_emails": expected_failure_emails,
        "job_failure_destinations": expected_failure_destinations,
    }

    # Dry runs never touch disk; real runs merge into the target's variable-overrides.json
    overrides_file = tmp_path / ".databricks" / "bundle" / "int-test" / "variable-overrides.json"
    dry = execute_deployment(cfg, dry_run=True, bundle_root=tmp_path)
    assert dry["variable_overrides_path"] == str(overrides_file)
    assert not overrides_file.exists()

    def ok_runner(
        cmd: Sequence[str],
        env: Mapping[str, str],
    ) -> subprocess.CompletedProcess[str]:
        return subprocess.CompletedProcess(list(cmd), 0, stdout="OK", stderr="")

    overrides_file.parent.mkdir(parents=True)
    overrides_file.write_text(json.dumps({"other_var": {"keep": True}}), encoding="utf-8")
    execute_deployment(cfg, validate_only=True, runner=ok_runner, bundle_root=tmp_path)
    assert json.loads(overrides_file.read_text(encoding="utf-8")) == {
        "other_var": {"keep": True},
        "alert_subscriptions": expected,
        "alert_task_subscribers": expected_task_subscribers,
        "job_failure_emails": expected_failure_emails,
        "job_failure_destinations": expected_failure_destinations,
    }

    overrides_file.write_text("not json", encoding="utf-8")
    with pytest.raises(ValueError, match="not valid JSON"):
        execute_deployment(cfg, validate_only=True, runner=ok_runner, bundle_root=tmp_path)


def test_full_refresh_resets_the_pipeline_after_preparing_its_inputs(tmp_path: Path) -> None:
    executed: list[list[str]] = []

    def recording_runner(
        cmd: Sequence[str],
        env: Mapping[str, str],
    ) -> subprocess.CompletedProcess[str]:
        executed.append(list(cmd))
        return subprocess.CompletedProcess(list(cmd), 0, stdout="OK", stderr="")

    # Pipeline flags do not apply to job runs, so the pipeline itself gets --full-refresh-all,
    # after the job tasks that create the tables it reads strictly
    for target, prepare in (
        ("dev", "snapshot_cluster_nodes"),
        ("int-test", "+generate_synthetic_telemetry"),
    ):
        executed.clear()
        cfg = load_deployment_config(
            {
                "profile": "p",
                "target": target,
                "catalog": "c",
                "warehouse_id": "w",
                "compute_subnet_cidrs": "10.0.0.0/18",
                "flow_log_source_path": "/Volumes/c/s/v",
                "alert_email_recipients": ["ops@example.com"],
                "full_refresh": True,
            }
        )
        result = execute_deployment(cfg, runner=recording_runner, bundle_root=tmp_path)
        runs = [cmd for cmd in executed if cmd[:3] == ["databricks", "bundle", "run"]]
        base_cmd = ["-t", target, "--profile", "p"]
        assert runs == [
            ["databricks", "bundle", "run", "network_monitor_job", *base_cmd, "--only", prepare],
            ["databricks", "bundle", "run", "network_monitor_sdp", *base_cmd, "--full-refresh-all"],
            ["databricks", "bundle", "run", "network_monitor_job", *base_cmd],
        ]
        assert not any("--refresh-all" in cmd for cmd in executed)
        assert result["pipeline_full_refreshed"] is True


def _deploy_config(**overrides: object) -> dict[str, object]:
    return {
        "profile": "p",
        "target": "prod",
        "catalog": "c",
        "warehouse_id": "w",
        "compute_subnet_cidrs": "10.0.0.0/18",
        "flow_log_source_path": "/Volumes/c/s/v",
        "alert_email_recipients": ["ops@example.com"],
        **overrides,
    }


def test_validate_only_changes_nothing_and_dry_runs_report_it(tmp_path: Path) -> None:
    executed: list[list[str]] = []

    def recording_runner(
        cmd: Sequence[str],
        env: Mapping[str, str],
    ) -> subprocess.CompletedProcess[str]:
        executed.append(list(cmd))
        return subprocess.CompletedProcess(list(cmd), 0, stdout="OK", stderr="")

    cfg = load_deployment_config(_deploy_config())
    assert cfg.ensure_schema is True

    # --validate-only creates no schema: it only checks authentication and validates
    result = execute_deployment(
        cfg, validate_only=True, runner=recording_runner, bundle_root=tmp_path
    )
    assert result["status"] == "validated"
    assert [cmd[:3] for cmd in executed] == [
        ["databricks", "current-user", "me"],
        ["databricks", "bundle", "validate"],
    ]

    # Dry runs say so, and never claim that the job ran or the pipeline was reset
    assert execute_deployment(cfg, validate_only=True, dry_run=True, bundle_root=tmp_path)[
        "status"
    ] == "dry_run"
    cfg_full = load_deployment_config(_deploy_config(full_refresh=True))
    dry = execute_deployment(cfg_full, dry_run=True, bundle_root=tmp_path)
    assert dry["status"] == "dry_run"
    assert dry["job_ran"] is False
    assert dry["pipeline_full_refreshed"] is False
    assert ["databricks", "bundle", "deploy", "-t", "prod", "--profile", "p"] in dry[
        "executed_commands"
    ]


def test_cold_genie_bootstrap_does_not_depend_on_the_cli_error_wording(tmp_path: Path) -> None:
    cfg = load_deployment_config(_deploy_config(run_initial_job=False))

    def run_with(
        first_deploy_error: str,
        redeploy_error: str = "",
    ) -> tuple[list[list[str]], dict[str, object] | RuntimeError]:
        executed: list[list[str]] = []

        def runner(
            cmd: Sequence[str],
            env: Mapping[str, str],
        ) -> subprocess.CompletedProcess[str]:
            executed.append(list(cmd))
            if cmd[:3] == ["databricks", "bundle", "deploy"]:
                deploys = sum(1 for done in executed if done[:3] == list(cmd[:3]))
                error = first_deploy_error if deploys == 1 else redeploy_error
                if error:
                    return subprocess.CompletedProcess(list(cmd), 1, stdout="", stderr=error)
            return subprocess.CompletedProcess(list(cmd), 0, stdout="OK", stderr="")

        try:
            return executed, execute_deployment(cfg, runner=runner, bundle_root=tmp_path)
        except RuntimeError as exc:
            return executed, exc

    def ran_job(executed: list[list[str]]) -> bool:
        job_run = ["databricks", "bundle", "run", "network_monitor_job"]
        return any(cmd[:4] == job_run for cmd in executed)

    # Other CLI versions and deployment engines word the missing tables differently
    terraform_engine_error = (
        "Error: terraform apply: exit status 1\n\n"
        "Error: cannot create genie space: [TABLE_OR_VIEW_NOT_FOUND] "
        "c.network_monitor.job_bandwidth_5m\n\n"
        "  with databricks_genie_space.network_monitor_genie,"
    )
    executed, result = run_with(terraform_engine_error)
    assert isinstance(result, dict)
    assert result["cold_genie_bootstrapped"] is True
    assert result["job_ran"] is True
    assert ran_job(executed)

    # Failures of other resources are reported at once, without running the job
    executed, result = run_with("Error: cannot create resources.pipelines.network_monitor_sdp")
    assert isinstance(result, RuntimeError)
    assert "Bundle deploy failed" in str(result)
    assert not ran_job(executed)

    # When the bootstrap does not fix it, the first deploy's error is still shown
    permission_error = (
        "Error: cannot create resources.genie_spaces.network_monitor_genie: PERMISSION_DENIED"
    )
    executed, result = run_with(permission_error, redeploy_error=permission_error)
    assert isinstance(result, RuntimeError)
    assert "cold-schema bootstrap" in str(result)
    assert str(result).count("PERMISSION_DENIED") == 2
    assert ran_job(executed)


def test_destroy_removes_the_deployment_with_the_configs_variables(tmp_path: Path) -> None:
    executed: list[tuple[list[str], dict[str, str]]] = []

    def recording_runner(
        cmd: Sequence[str],
        env: Mapping[str, str],
    ) -> subprocess.CompletedProcess[str]:
        executed.append((list(cmd), dict(env)))
        return subprocess.CompletedProcess(list(cmd), 0, stdout="OK", stderr="")

    cfg = load_deployment_config(_deploy_config())
    result = execute_deployment(cfg, destroy=True, runner=recording_runner, bundle_root=tmp_path)
    assert result["status"] == "destroyed"
    # No schema creation, validation, or deploy: only the auth check and the destroy
    assert [cmd for cmd, _ in executed] == [
        ["databricks", "current-user", "me", "--profile", "p", "-o", "json"],
        ["databricks", "bundle", "destroy", "-t", "prod", "--profile", "p", "--auto-approve"],
    ]
    # The CLI loads the bundle with this config's variables; a bare destroy fails without them
    assert executed[-1][1]["BUNDLE_VAR_warehouse_id"] == "w"
    dry = execute_deployment(cfg, destroy=True, dry_run=True, bundle_root=tmp_path)
    assert dry["status"] == "dry_run"
    with pytest.raises(ValueError, match="cannot be combined"):
        execute_deployment(cfg, destroy=True, validate_only=True, bundle_root=tmp_path)

    cfg_file = tmp_path / "deploy.local.json"
    cfg_file.write_text(json.dumps(_deploy_config()), encoding="utf-8")
    assert run_deploy_cli(["--config", str(cfg_file), "--destroy", "--dry-run"]) == 0
    with pytest.raises(SystemExit):
        run_deploy_cli(["--config", str(cfg_file), "--destroy", "--validate-only"])


def test_flow_log_start_after_is_validated_and_exported() -> None:
    with pytest.raises(ValueError, match="Invalid flow-log start time"):
        load_deployment_config(_deploy_config(flow_log_start_after="11/01/2026"))

    cfg = load_deployment_config(_deploy_config(flow_log_start_after=" 2026-11-01 "))
    assert cfg.build_subprocess_env(base_env={})["BUNDLE_VAR_flow_log_start_after"] == "2026-11-01"
    # Unset, the bundle variable keeps its empty default and every flow-log file is read
    unset = load_deployment_config(_deploy_config()).build_subprocess_env(base_env={})
    assert "BUNDLE_VAR_flow_log_start_after" not in unset
