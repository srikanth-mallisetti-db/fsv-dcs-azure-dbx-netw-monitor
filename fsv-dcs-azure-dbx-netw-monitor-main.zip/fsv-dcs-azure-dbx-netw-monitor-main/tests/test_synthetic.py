"""Unit tests for the Phase 3 synthetic VNet Flow Log v4 generator and 7 int-test scenarios."""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import pytest

from network_monitor.flow_utils import (
    attribute_window_records,
    correct_recreated_flow_counters,
    deduplicate_flow_events_scd1,
    extract_flow_events_from_document,
    parse_cidr_ranges,
    parse_target_resource_ids,
    resolve_ownership_windows,
    resolve_private_endpoint_ranges,
)
from network_monitor.synthetic import (
    SYNTHETIC_COMPUTE_SUBNET_CIDRS,
    SYNTHETIC_PRIVATE_ENDPOINT_CIDRS,
    SYNTHETIC_THRESHOLD_MBPS,
    SYNTHETIC_VNET_RESOURCE_ID,
    build_synthetic_dataset,
    seed_synthetic_environment,
    write_synthetic_flow_log_files,
)
from network_monitor.tasks.generate_synthetic_telemetry import main as run_generator_cli


def test_synthetic_dataset_exercises_all_seven_scenarios_and_overwrite_dedup() -> None:
    ref_time = datetime(2026, 10, 21, 14, 12, 30, tzinfo=UTC)
    dataset = build_synthetic_dataset(reference_time=ref_time, workspace_id="SYNTHETIC_WS")

    assert dataset.window_start == datetime(2026, 10, 21, 14, 10, 0, tzinfo=UTC)
    assert dataset.window_end == datetime(2026, 10, 21, 14, 15, 0, tzinfo=UTC)

    compute_ranges = parse_cidr_ranges(SYNTHETIC_COMPUTE_SUBNET_CIDRS)
    pe_ranges = resolve_private_endpoint_ranges(SYNTHETIC_PRIVATE_ENDPOINT_CIDRS)

    t_rev1 = dataset.window_start + timedelta(minutes=1)
    t_rev2 = dataset.window_start + timedelta(minutes=2)

    rev1_events = extract_flow_events_from_document(
        dataset.pt1h_rev1_document,
        compute_ranges=compute_ranges,
        private_endpoint_ranges=pe_ranges,
        source_file="/Volumes/main/network_monitor_int_test/synthetic_flow_logs/PT1H.json",
        file_mod_time=t_rev1,
    )
    rev2_events = extract_flow_events_from_document(
        dataset.pt1h_rev2_document,
        compute_ranges=compute_ranges,
        private_endpoint_ranges=pe_ranges,
        source_file="/Volumes/main/network_monitor_int_test/synthetic_flow_logs/PT1H.json",
        file_mod_time=t_rev2,
    )

    # S3 (500 MB shuffle) and B anchor tuples are dropped immediately:
    # Rev 1 has 8 C/E tuples (S1, S2, S4, S5, S6a temporal miss, S6b unknown-IP miss, and S7's
    # two E reports); Rev 2 has 9 (including both C and E for S1)
    assert len(rev1_events) == 8
    assert len(rev2_events) == 9
    # S7's first E shares its millisecond with a B: the flow was re-created
    assert [e.is_recreated for e in rev2_events if e.local_node_ip == "10.0.0.8"] == [True, False]
    assert not any(e.is_recreated for e in rev2_events if e.local_node_ip != "10.0.0.8")
    # int-test scopes ingestion to the synthetic VNet, matched case-insensitively
    scoped_events = extract_flow_events_from_document(
        dataset.pt1h_rev2_document,
        compute_ranges=compute_ranges,
        private_endpoint_ranges=pe_ranges,
        target_resource_ids=parse_target_resource_ids(SYNTHETIC_VNET_RESOURCE_ID.lower()),
    )
    assert len(scoped_events) == 9

    # Combine Rev 1 + Rev 2 to simulate Auto Loader reading the initial PT1H.json and its overwrite
    deduped = deduplicate_flow_events_scd1([*rev1_events, *rev2_events])
    assert len(deduped) == 8

    # flow_event_deltas removes the counters S7's next report repeats; counted as raw deltas,
    # S7 would breach
    uncorrected = attribute_window_records(
        deduped,
        resolve_ownership_windows(dataset.ownership_rows),
        dataset.exception_rules,
        threshold_mbps=SYNTHETIC_THRESHOLD_MBPS,
        default_workspace_id="SYNTHETIC_WS",
    )
    s7_raw = next(w for w in uncorrected if w.cluster_id == "cluster-recreated-07")
    assert s7_raw.total_bytes == 41_000_256
    assert s7_raw.is_breach is True

    # cluster_node_runs resolves synthetic sightings exactly like live ones before attribution
    windows = attribute_window_records(
        correct_recreated_flow_counters(deduped),
        resolve_ownership_windows(dataset.ownership_rows),
        dataset.exception_rules,
        threshold_mbps=SYNTHETIC_THRESHOLD_MBPS,
        default_workspace_id="SYNTHETIC_WS",
    )
    by_cluster = {w.cluster_id: w for w in windows}
    assert set(by_cluster.keys()) == {
        "cluster-monitored-01",
        "cluster-pe-02",
        "cluster-exempt-03",
        "cluster-shared-04",
        "cluster-recreated-07",
        "UNATTRIBUTED",
    }
    # Expired cluster-expired-06 (job_id=1099) must NEVER appear as an attributed cluster
    assert "cluster-expired-06" not in by_cluster

    # S1: Dedicated Monitored Breach (revised from 100 MB 'C' to 120 MB 'E' without double counting)
    s1 = by_cluster["cluster-monitored-01"]
    assert s1.attribution_category == "MONITORED"
    assert s1.job_id == 1001
    assert s1.run_id == 501001
    assert s1.job_name == "fx-market-feed-ingest"
    assert s1.bytes_received == 120_000_000
    assert s1.bytes_sent == 0
    assert s1.total_bytes == 120_000_000
    assert s1.external_bytes == 120_000_000
    assert s1.private_endpoint_bytes == 0
    assert s1.avg_mbps == pytest.approx(3.20)
    assert s1.is_breach is True

    # S2: Internal ADLS Private Endpoint Read (180 MB -> 4.80 Mbps, PRIVATE_ENDPOINT)
    s2 = by_cluster["cluster-pe-02"]
    assert s2.attribution_category == "MONITORED"
    assert s2.job_id == 1002
    assert s2.run_id == 501002
    assert s2.total_bytes == 180_000_000
    assert s2.private_endpoint_bytes == 180_000_000
    assert s2.external_bytes == 0
    assert s2.avg_mbps == pytest.approx(4.80)
    assert s2.is_breach is True

    # S4: Approved Exempt Job (150 MB upload -> 4.00 Mbps, EXEMPT, is_breach=False)
    s4 = by_cluster["cluster-exempt-03"]
    assert s4.attribution_category == "EXEMPT"
    assert s4.job_id == 1003
    assert s4.total_bytes == 150_000_000
    assert s4.bytes_sent == 150_000_000
    assert s4.avg_mbps == pytest.approx(4.00)
    assert s4.is_breach is False

    # S5: Shared Cluster Concurrency (jobs 2001 & 2002, 90 MB -> 2.40 Mbps, SHARED, is_breach=True)
    s5 = by_cluster["cluster-shared-04"]
    assert s5.attribution_category == "SHARED"
    assert s5.job_id is None
    assert s5.run_id is None
    assert s5.candidate_job_ids == (2001, 2002)
    assert s5.total_bytes == 90_000_000
    assert s5.avg_mbps == pytest.approx(2.40)
    assert s5.is_breach is True

    # S6: Unattributed Traffic (10 MB temporal miss + 5 MB unknown-IP miss)
    s6 = by_cluster["UNATTRIBUTED"]
    assert s6.attribution_category == "UNATTRIBUTED"
    assert s6.job_id is None
    assert s6.bytes_sent == 5_000_000
    assert s6.bytes_received == 10_000_000
    assert s6.total_bytes == 15_000_000
    assert s6.avg_mbps == pytest.approx(0.40)
    assert s6.is_breach is False

    # S7: Re-created flow (20 MB re-creation E, then 1,000,256 new bytes -> 0.56 Mbps, no breach)
    s7 = by_cluster["cluster-recreated-07"]
    assert s7.attribution_category == "MONITORED"
    assert s7.job_id == 1007
    assert s7.bytes_sent == 1_000_256
    assert s7.bytes_received == 20_000_000
    assert s7.total_bytes == 21_000_256
    assert s7.avg_mbps == pytest.approx(0.56000683)
    assert s7.is_breach is False


def test_multi_window_hourly_pt1h_accumulation_and_cli_task(tmp_path: Path) -> None:
    t_win1 = datetime(2026, 10, 21, 15, 5, 0, tzinfo=UTC)
    t_win2 = datetime(2026, 10, 21, 15, 10, 0, tzinfo=UTC)

    ds1 = build_synthetic_dataset(reference_time=t_win1)
    ds2 = build_synthetic_dataset(reference_time=t_win2)

    path1 = write_synthetic_flow_log_files(ds1, tmp_path, overwrite_delay_seconds=0.0)
    path2 = write_synthetic_flow_log_files(ds2, tmp_path, overwrite_delay_seconds=0.0)

    # Both 5-minute windows belong to hour 15, so they accumulate in the exact same PT1H.json file
    assert path1 == path2
    assert "y=2026/m=10/d=21/h=15/m=00/macAddress=000D3A112233" in path2.as_posix()

    loaded = json.loads(path2.read_text(encoding="utf-8"))
    assert len(loaded["records"]) == 2

    # Re-running window 2 is idempotent (replaces only window 2's record, keeping count at 2)
    write_synthetic_flow_log_files(ds2, tmp_path, overwrite_delay_seconds=0.0)
    loaded_rerun = json.loads(path2.read_text(encoding="utf-8"))
    assert len(loaded_rerun["records"]) == 2

    compute_ranges = parse_cidr_ranges(SYNTHETIC_COMPUTE_SUBNET_CIDRS)
    pe_ranges = resolve_private_endpoint_ranges(SYNTHETIC_PRIVATE_ENDPOINT_CIDRS)
    combined_events = extract_flow_events_from_document(
        loaded_rerun,
        compute_ranges=compute_ranges,
        private_endpoint_ranges=pe_ranges,
    )
    deduped = deduplicate_flow_events_scd1(combined_events)
    # 8 distinct C/E events per 5-minute window x 2 windows = 16 events
    assert len(deduped) == 16

    combined_owners = resolve_ownership_windows((*ds1.ownership_rows, *ds2.ownership_rows))
    windows = attribute_window_records(
        correct_recreated_flow_counters(deduped),
        combined_owners,
        ds2.exception_rules,
        threshold_mbps=SYNTHETIC_THRESHOLD_MBPS,
        default_workspace_id="SYNTHETIC_WS",
    )
    # 6 cluster/unattributed buckets per 5-minute window x 2 windows = 12 windows
    assert len(windows) == 12
    # Each window's flows are corrected on their own: the same 5-tuples recur in the next window
    # without borrowing the previous window's counters
    for window in windows:
        if window.cluster_id == "cluster-recreated-07":
            assert window.total_bytes == 21_000_256
        if window.cluster_id == "cluster-monitored-01":
            assert window.total_bytes == 120_000_000

    executed_sql: list[str] = []
    saved_tables: dict[str, list[dict[str, Any]]] = {}

    class FakeWriter:
        def __init__(self, rows: list[dict[str, Any]]) -> None:
            self._rows = rows

        def format(self, fmt: str) -> FakeWriter:
            assert fmt == "delta"
            return self

        def mode(self, mode_name: str) -> FakeWriter:
            assert mode_name in {"append", "overwrite"}
            return self

        def option(self, key: str, value: str) -> FakeWriter:
            assert key and value
            return self

        def saveAsTable(self, table_name: str) -> None:
            saved_tables[table_name] = self._rows

    class FakeFrame:
        def __init__(self, rows: list[dict[str, Any]]) -> None:
            self.write = FakeWriter(rows)

    class FakeSpark:
        @staticmethod
        def sql(query: str) -> None:
            executed_sql.append(query.strip())

        @staticmethod
        def createDataFrame(rows: list[dict[str, Any]], schema: str) -> FakeFrame:
            assert schema
            return FakeFrame(rows)

    fake_spark = FakeSpark()
    summary = seed_synthetic_environment(
        fake_spark,
        catalog="main",
        schema="network_monitor_int_test",
        volume_path=str(tmp_path),
        workspace_id="SYNTHETIC_WS",
        reference_time=t_win1,
    )
    assert summary["ownership_row_count"] == 10
    assert summary["exception_rule_count"] == 1
    assert "main.network_monitor_int_test.synthetic_cluster_node_runs" in saved_tables
    assert "main.network_monitor_int_test.job_exceptions" in saved_tables
    assert any(
        "DELETE FROM main.network_monitor_int_test.synthetic_cluster_node_runs" in q
        for q in executed_sql
    )

    cli_summary = run_generator_cli(
        [
            "--catalog",
            "main",
            "--schema",
            "network_monitor_int_test",
            "--volume-path",
            str(tmp_path),
            "--workspace-id",
            "SYNTHETIC_WS",
        ],
        spark_session=fake_spark,
    )
    assert cli_summary["ownership_row_count"] == 10
