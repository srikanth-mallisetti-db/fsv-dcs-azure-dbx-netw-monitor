"""Validate the Databricks Asset Bundle scaffold and SDP pipeline registration."""

from __future__ import annotations

import configparser
import re
import tomllib
from pathlib import Path
from typing import Any

from network_monitor import __version__
from network_monitor.pipeline.flow_ingestion_sdp import (
    PIPELINE_TABLES,
    PIPELINE_VIEWS,
    register_pipeline,
)

ROOT = Path(__file__).resolve().parents[1]


def test_bundle_files_exist() -> None:
    assert __version__ == "0.2.0"
    assert (ROOT / "AGENTS.md").is_file()
    assert (ROOT / "databricks.yml").is_file()
    assert (ROOT / "resources/network_monitor_pipeline.yml").is_file()
    assert (ROOT / "resources/network_monitor_job.yml").is_file()
    assert (ROOT / "resources/network_monitor_genie.yml").is_file()
    assert (ROOT / "resources/network_monitor_dashboard.yml").is_file()
    assert (ROOT / "resources/network_monitor_alert.yml").is_file()
    assert (ROOT / "docs/vnet-flow-logs-prerequisite.md").is_file()
    assert (ROOT / "docs/architecture.md").is_file()
    assert (ROOT / "docs/data-model.md").is_file()
    assert (ROOT / "docs/testing.md").is_file()
    assert (ROOT / "docs/setup-and-deployment.md").is_file()
    assert (ROOT / "scripts/deploy.py").is_file()
    assert (ROOT / "configs/deploy.dev.example.json").is_file()
    assert (ROOT / "configs/deploy.prod.example.json").is_file()
    assert (ROOT / "configs/deploy.int-test.example.json").is_file()
    assert (ROOT / "src/network_monitor/breach_notifications.py").is_file()
    assert (ROOT / "src/network_monitor/deployer.py").is_file()
    assert (ROOT / "src/network_monitor/flow_utils.py").is_file()
    assert (ROOT / "src/network_monitor/ownership.py").is_file()
    assert (ROOT / "src/network_monitor/node_snapshots.py").is_file()
    assert (ROOT / "src/network_monitor/synthetic.py").is_file()
    assert (ROOT / "src/network_monitor/semantic_layer.py").is_file()
    assert (ROOT / "src/network_monitor/tasks/generate_synthetic_telemetry.py").is_file()
    assert (ROOT / "src/network_monitor/tasks/publish_semantic_layer.py").is_file()
    assert (ROOT / "src/network_monitor/tasks/snapshot_cluster_nodes.py").is_file()
    assert (ROOT / "src/network_monitor/tasks/track_breach_notifications.py").is_file()
    assert (ROOT / "src/network_monitor/dashboard/network_monitor.lvdash.json").is_file()
    assert (ROOT / "src/network_monitor/pipeline/flow_ingestion_sdp.py").is_file()


def test_local_setup_pins_tools_and_blocks_user_installs() -> None:
    # Every development dependency is pinned, so fresh installs run the same checks
    requirements = (ROOT / "requirements-dev.txt").read_text(encoding="utf-8")
    pins = dict(re.findall(r"^([A-Za-z0-9_.-]+)==(\S+)$", requirements, re.MULTILINE))
    assert {"databricks-sdk", "mypy", "pytest", "pytest-cov", "ruff"} <= set(pins)
    requirement_lines = [
        line for line in requirements.splitlines() if line.strip() and not line.startswith("#")
    ]
    assert len(requirement_lines) == len(pins)

    # The pip template stops a machine-level setting from forcing --user into the venv, and
    # carries only a placeholder index; the real copy stays local
    pip_ini = configparser.ConfigParser()
    pip_ini.read_string((ROOT / "pip.ini.example").read_text(encoding="utf-8"))
    assert pip_ini.get("install", "user") == "false"
    assert pip_ini.get("global", "index-url") == "https://REPLACE-ME.example.com/simple"
    assert "\npip.local.ini\n" in (ROOT / ".gitignore").read_text(encoding="utf-8")

    # Checks target the job tasks' runtime, Python 3.11 on serverless environment version 2
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    assert pyproject["tool"]["ruff"]["target-version"] == "py311"
    assert pyproject["tool"]["mypy"]["python_version"] == "3.11"
    job_yml = (ROOT / "resources/network_monitor_job.yml").read_text(encoding="utf-8")
    assert 'environment_version: "2"' in job_yml


def test_sdp_pipeline_registration() -> None:
    registered_views: dict[str, dict[str, Any]] = {}
    registered_tables: dict[str, dict[str, Any]] = {}
    streaming_tables: dict[str, dict[str, Any]] = {}
    auto_cdc_flows: list[dict[str, Any]] = []

    class FakeFrame:
        def __init__(self, source: str) -> None:
            self.source = source
            self.expressions: tuple[str, ...] = ()

        def selectExpr(self, *exprs: str) -> FakeFrame:
            self.expressions = exprs
            return self

        def where(self, condition: str) -> FakeFrame:
            assert condition
            return self

        def alias(self, name: str) -> FakeFrame:
            assert name
            return self

        def join(self, other: FakeFrame, *, on: Any, how: str = "inner") -> FakeFrame:
            assert other is not None and on is not None and how
            return self

        def groupBy(self, *cols: Any) -> FakeFrame:
            assert cols
            return self

        def agg(self, *exprs: Any) -> FakeFrame:
            assert exprs
            return self

        def distinct(self) -> FakeFrame:
            return self

        def unionByName(self, other: FakeFrame) -> FakeFrame:
            assert other is not None
            return self

    class FakeStreamReader:
        def __init__(self) -> None:
            self.options: dict[str, str] = {}

        def format(self, fmt: str) -> FakeStreamReader:
            assert fmt == "cloudFiles"
            return self

        def option(self, key: str, value: str) -> FakeStreamReader:
            assert key and value is not None
            self.options[key] = value
            return self

        def schema(self, ddl: str) -> FakeStreamReader:
            assert "flowRecords" in ddl
            return self

        @staticmethod
        def load(path: str) -> FakeFrame:
            return FakeFrame(source=f"stream:{path}")

    class FakeBatchReader:
        @staticmethod
        def table(name: str) -> FakeFrame:
            return FakeFrame(source=f"table:{name}")

    class FakeSpark:
        read = FakeBatchReader()

        def __init__(self, conf: dict[str, str]) -> None:
            self.conf = conf
            self.readStream = FakeStreamReader()

        @staticmethod
        def createDataFrame(rows: list[dict[str, Any]], schema: str) -> FakeFrame:
            assert schema
            return FakeFrame(source=f"df:{len(rows)}")

        @staticmethod
        def sql(query: str) -> FakeFrame:
            assert query
            return FakeFrame(source="sql")

    class FakeDlt:
        @staticmethod
        def view(*, name: str, comment: str) -> Any:
            def decorator(fn: Any) -> Any:
                registered_views[name] = {"comment": comment, "fn": fn}
                return fn

            return decorator

        @staticmethod
        def table(*, name: str, comment: str, cluster_by: list[str] | None = None) -> Any:
            def decorator(fn: Any) -> Any:
                registered_tables[name] = {"comment": comment, "fn": fn, "cluster_by": cluster_by}
                return fn

            return decorator

        @staticmethod
        def create_streaming_table(
            *, name: str, comment: str, cluster_by: list[str] | None = None
        ) -> None:
            streaming_tables[name] = {"comment": comment, "cluster_by": cluster_by}

        @staticmethod
        def create_auto_cdc_flow(
            *,
            target: str,
            source: str,
            keys: list[str],
            sequence_by: Any,
            stored_as_scd_type: int,
        ) -> None:
            auto_cdc_flows.append(
                {
                    "target": target,
                    "source": source,
                    "keys": keys,
                    "sequence_by": sequence_by,
                    "stored_as_scd_type": stored_as_scd_type,
                }
            )

        @staticmethod
        def read(name: str) -> FakeFrame:
            return FakeFrame(source=name)

    spark = FakeSpark(
        {
            "network_monitor.is_int_test": "true",
            "network_monitor.flow_log_start_after": "2026-11-01T05:30:00+05:30",
        }
    )
    register_pipeline(FakeDlt(), spark)

    assert tuple(registered_views) == PIPELINE_VIEWS
    # Merges key and cluster on event_time so each micro-batch only touches recent files
    assert streaming_tables["flow_events_clean"]["cluster_by"] == ["event_time"]
    assert len(auto_cdc_flows) == 1
    assert auto_cdc_flows[0] == {
        "target": "flow_events_clean",
        "source": "raw_flow_tuples_stream",
        "keys": ["event_time", "event_id"],
        "sequence_by": "sequence_key",
        "stored_as_scd_type": 1,
    }
    assert ("flow_events_clean", *tuple(registered_tables)) == PIPELINE_TABLES
    assert tuple(registered_tables) == (
        "flow_event_deltas",
        "cluster_node_runs",
        "job_bandwidth_5m",
    )
    assert registered_tables["job_bandwidth_5m"]["cluster_by"] == ["window_start"]

    raw_frame = registered_views["raw_flow_tuples_stream"]["fn"]()
    assert raw_frame.expressions
    # Re-created flows are flagged at ingestion and reach flow_events_clean
    assert "is_recreated" in raw_frame.expressions

    # Byte counters are summed from flow_event_deltas, where re-created flows' repeats are removed
    deltas_frame = registered_tables["flow_event_deltas"]["fn"]()
    assert "corrected_bytes_sent AS bytes_sent" in deltas_frame.expressions
    assert "bytes_received AS raw_bytes_received" in deltas_frame.expressions
    # Appended PT1H.json blobs are re-read, and the configured start reaches Auto Loader in UTC
    assert spark.readStream.options["cloudFiles.allowOverwrites"] == "true"
    assert spark.readStream.options["modifiedAfter"] == "2026-11-01 00:00:00.000000 UTC+0"

    for table_name in registered_tables:
        frame = registered_tables[table_name]["fn"]()
        assert frame.expressions

    # Without a configured start, every flow-log file is read
    unbounded = FakeSpark({"network_monitor.is_int_test": "true"})
    register_pipeline(FakeDlt(), unbounded)
    registered_views["raw_flow_tuples_stream"]["fn"]()
    assert "modifiedAfter" not in unbounded.readStream.options
