"""Unit tests for the per-cycle node snapshot task: tables, retention, admin check, sightings."""

from __future__ import annotations

from typing import Any

import pytest

from network_monitor.node_snapshots import (
    build_live_snapshots_ddl,
    build_retention_sql,
    snapshot_cluster_nodes,
)
from network_monitor.tasks.snapshot_cluster_nodes import main as run_snapshot_task_cli
from tests.test_ownership import (
    FakeCluster,
    FakeClusterInstance,
    FakeNode,
    FakeRun,
    FakeWorkspaceClient,
    at,
    epoch_ms,
)


class RecordingSpark:
    """Fake SparkSession recording SQL statements and appended rows."""

    def __init__(self, existing_tables: tuple[str, ...] = ()) -> None:
        self.executed: list[str] = []
        self.appended: dict[str, list[dict[str, Any]]] = {}
        self.catalog = RecordingCatalog(existing_tables)

    def sql(self, query: str) -> None:
        self.executed.append(query)

    def createDataFrame(self, rows: list[dict[str, Any]], schema: str) -> RecordingFrame:
        assert "observed_end TIMESTAMP" in schema
        return RecordingFrame(self, rows)


class RecordingCatalog:
    def __init__(self, existing_tables: tuple[str, ...]) -> None:
        self._existing = set(existing_tables)

    def tableExists(self, name: str) -> bool:
        return name in self._existing


class RecordingFrame:
    def __init__(self, spark: RecordingSpark, rows: list[dict[str, Any]]) -> None:
        self._spark = spark
        self._rows = rows
        self.write = self

    def format(self, fmt: str) -> RecordingFrame:
        assert fmt == "delta"
        return self

    def mode(self, mode_name: str) -> RecordingFrame:
        assert mode_name == "append"
        return self

    def saveAsTable(self, name: str) -> None:
        self._spark.appended[name] = self._rows


def running_job_cluster_client(groups: tuple[str, ...] = ("admins", "users")) -> FakeWorkspaceClient:
    cluster = FakeCluster(
        cluster_id="0101-jobcluster",
        cluster_name="job-101-cluster",
        state="RUNNING",
        driver=FakeNode(
            host_private_ip="10.0.1.4", private_ip="10.0.65.4", start_timestamp=epoch_ms(at(9, 0))
        ),
        executors=[],
    )
    run = FakeRun(
        job_id=101,
        run_id=1001,
        run_name="settlement-ingest",
        start_time=epoch_ms(at(9, 0)),
        cluster_instance=FakeClusterInstance(cluster_id="0101-jobcluster"),
    )
    return FakeWorkspaceClient(clusters=[cluster], runs=[run], groups=groups)


def test_snapshot_ddl_and_retention_statements() -> None:
    ddl = build_live_snapshots_ddl("main", "nm")
    assert ddl.startswith("CREATE TABLE IF NOT EXISTS main.nm.live_cluster_node_snapshots (")
    assert ddl.endswith("USING DELTA CLUSTER BY (observed_end)")

    cutoff = "date_trunc('HOUR', current_timestamp())"
    assert build_retention_sql("main", "nm", lookback_hours=24, retention_days=30) == [
        "DELETE FROM main.nm.live_cluster_node_snapshots "
        f"WHERE observed_end < {cutoff} - INTERVAL 48 HOURS",
        f"DELETE FROM main.nm.flow_events_clean WHERE event_time < {cutoff} - INTERVAL 30 DAYS",
    ]
    # Before the pipeline has created flow_events_clean only the sightings are trimmed
    assert build_retention_sql(
        "main", "nm", lookback_hours=6, include_flow_events=False
    ) == [f"DELETE FROM main.nm.live_cluster_node_snapshots WHERE observed_end < {cutoff} - INTERVAL 30 HOURS"]
    clamped = build_retention_sql("main", "nm", lookback_hours=0, retention_days=0)
    assert "INTERVAL 25 HOURS" in clamped[0]
    assert "INTERVAL 1 DAYS" in clamped[1]

    with pytest.raises(ValueError, match="Invalid Unity Catalog"):
        build_retention_sql("main", "nm; DROP TABLE x", lookback_hours=24)


def test_snapshot_cluster_nodes_prepares_tables_trims_and_appends_sightings() -> None:
    spark = RecordingSpark(existing_tables=("main.nm.flow_events_clean",))
    summary = snapshot_cluster_nodes(
        spark,
        catalog="main",
        schema="nm",
        lookback_hours=24,
        retention_days=30,
        workspace_client=running_job_cluster_client(),
    )

    assert spark.executed[0] == "CREATE SCHEMA IF NOT EXISTS main.nm"
    assert spark.executed[1].startswith("CREATE TABLE IF NOT EXISTS main.nm.job_exceptions")
    assert spark.executed[2].startswith(
        "CREATE TABLE IF NOT EXISTS main.nm.live_cluster_node_snapshots"
    )
    assert spark.executed[3].startswith("DELETE FROM main.nm.live_cluster_node_snapshots")
    assert spark.executed[4].startswith("DELETE FROM main.nm.flow_events_clean")
    # 2 IPs x (cluster tenure row + run row)
    appended = spark.appended["main.nm.live_cluster_node_snapshots"]
    assert len(appended) == 4
    assert {row["job_id"] for row in appended} == {None, 101}
    assert summary == {
        "table": "main.nm.live_cluster_node_snapshots",
        "run_as": "monitor-sp",
        "sightings": 4,
    }


def test_snapshot_cluster_nodes_refuses_non_admin_and_skips_apis_in_int_test() -> None:
    spark = RecordingSpark()
    with pytest.raises(PermissionError, match="not a workspace admin"):
        snapshot_cluster_nodes(
            spark,
            catalog="main",
            schema="nm",
            workspace_client=running_job_cluster_client(groups=("users",)),
        )
    assert spark.appended == {}

    # int-test attributes synthetic rows: tables and retention only, no API client is created
    int_test_spark = RecordingSpark()
    summary = snapshot_cluster_nodes(
        int_test_spark, catalog="main", schema="nm_int_test", is_int_test=True
    )
    assert summary == {
        "table": "main.nm_int_test.live_cluster_node_snapshots",
        "run_as": None,
        "sightings": 0,
    }
    assert len(int_test_spark.executed) == 4
    assert not any("flow_events_clean" in query for query in int_test_spark.executed)


def test_snapshot_task_cli() -> None:
    spark = RecordingSpark()
    summary = run_snapshot_task_cli(
        [
            "--catalog",
            "main",
            "--schema",
            "nm_int_test",
            "--is-int-test",
            "true",
            "--lookback-hours",
            "6",
            "--retention-days",
            "7",
        ],
        spark_session=spark,
    )
    assert summary["sightings"] == 0
    assert "INTERVAL 30 HOURS" in spark.executed[3]
